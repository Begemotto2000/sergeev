CREATE TABLE `upload_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`filename` varchar(255) NOT NULL,
	`fileType` varchar(10),
	`status` enum('pending','processing','completed','failed') NOT NULL DEFAULT 'pending',
	`stages` json,
	`startTime` timestamp NOT NULL DEFAULT (now()),
	`endTime` timestamp,
	`errorMessage` text,
	`totalTokens` int DEFAULT 0,
	`segmentCount` int DEFAULT 0,
	`chunkCount` int DEFAULT 0,
	`ipAddress` varchar(45),
	`userAgent` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `upload_logs_id` PRIMARY KEY(`id`)
);
