import { mysqlTable, varchar, text, timestamp, int } from 'drizzle-orm/mysql-core';

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable('users', {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int('id').primaryKey().autoincrement(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar('openId', { length: 64 }).notNull().unique(),
  name: text('name'),
  email: varchar('email', { length: 320 }),
  loginMethod: varchar('loginMethod', { length: 64 }),
  role: varchar('role', { length: 20 }).notNull().default('user'),
  createdAt: timestamp('createdAt').defaultNow().notNull(),
  updatedAt: timestamp('updatedAt').defaultNow().notNull(),
  lastSignedIn: timestamp('lastSignedIn').defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Transcription uploads table - tracks uploaded transcription files
 */
export const transcriptionUploads = mysqlTable('transcription_uploads', {
  id: int('id').primaryKey().autoincrement(),
  userId: int('userId').notNull(),
  filename: varchar('filename', { length: 255 }).notNull(),
  fileType: varchar('fileType', { length: 10 }).notNull(), // pdf, docx, txt, json, srt
  fileUrl: text('fileUrl'), // S3 URL
  fileKey: text('fileKey'), // S3 key for reference
  status: varchar('status', { length: 20 }).notNull().default('pending'),
  errorMessage: text('errorMessage'), // Error details if failed
  segmentCount: int('segmentCount').default(0),
  chunkCount: int('chunkCount').default(0),
  totalTokens: int('totalTokens').default(0),
  createdAt: timestamp('createdAt').defaultNow().notNull(),
  updatedAt: timestamp('updatedAt').defaultNow().notNull(),
});

export type TranscriptionUpload = typeof transcriptionUploads.$inferSelect;
export type InsertTranscriptionUpload = typeof transcriptionUploads.$inferInsert;

/**
 * Upload logs table - tracks upload processing history
 */
export const uploadLogs = mysqlTable('upload_logs', {
  id: int('id').primaryKey().autoincrement(),
  uploadId: int('uploadId').notNull(),
  status: varchar('status', { length: 20 }).notNull().default('pending'),
  message: text('message'),
  createdAt: timestamp('createdAt').defaultNow().notNull(),
});

export type UploadLog = typeof uploadLogs.$inferSelect;
export type InsertUploadLog = typeof uploadLogs.$inferInsert;

/**
 * FAQ items table
 */
export const faqItems = mysqlTable('faq_items', {
  id: int('id').primaryKey().autoincrement(),
  userId: int('userId').notNull(),
  question: text('question').notNull(),
  answer: text('answer'),
  createdFrom: varchar('createdFrom', { length: 50 }).notNull().default('manual'),
  status: varchar('status', { length: 20 }).notNull().default('draft'),
  sourceType: varchar('sourceType', { length: 50 }),
  sourceId: varchar('sourceId', { length: 255 }),
  views: int('views').default(0),
  helpful: int('helpful').default(0),
  notHelpful: int('notHelpful').default(0),
  createdAt: timestamp('createdAt').defaultNow().notNull(),
  updatedAt: timestamp('updatedAt').defaultNow().notNull(),
});

export type FAQItem = typeof faqItems.$inferSelect;
export type InsertFAQItem = typeof faqItems.$inferInsert;

/**
 * FAQ user questions table - for tracking user questions
 */
export const faqUserQuestions = mysqlTable('faq_user_questions', {
  id: int('id').primaryKey().autoincrement(),
  userId: int('userId').notNull(),
  question: text('question').notNull(),
  status: varchar('status', { length: 20 }).notNull().default('new'),
  linkedFaqId: int('linkedFaqId'),
  createdAt: timestamp('createdAt').defaultNow().notNull(),
  updatedAt: timestamp('updatedAt').defaultNow().notNull(),
});

export type FAQUserQuestion = typeof faqUserQuestions.$inferSelect;
export type InsertFAQUserQuestion = typeof faqUserQuestions.$inferInsert;


/**
 * Error reports table - tracks user-reported errors and issues
 */
export const errorReports = mysqlTable('error_reports', {
  id: int('id').primaryKey().autoincrement(),
  userId: int('userId').notNull(),
  title: varchar('title', { length: 255 }).notNull(),
  description: text('description').notNull(),
  email: varchar('email', { length: 320 }),
  screenshotUrl: text('screenshotUrl'), // S3 URL for screenshot
  screenshotKey: text('screenshotKey'), // S3 key for reference
  status: varchar('status', { length: 20 }).notNull().default('new'), // new, acknowledged, in-progress, resolved, closed
  priority: varchar('priority', { length: 20 }).notNull().default('medium'), // low, medium, high, critical
  assignedTo: int('assignedTo'), // Admin user ID
  resolution: text('resolution'), // How it was fixed
  resolvedAt: timestamp('resolvedAt'),
  createdAt: timestamp('createdAt').defaultNow().notNull(),
  updatedAt: timestamp('updatedAt').defaultNow().notNull(),
});

export type ErrorReport = typeof errorReports.$inferSelect;
export type InsertErrorReport = typeof errorReports.$inferInsert;
