CREATE TABLE `indexed_transcriptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`uploadId` int NOT NULL,
	`chunkId` varchar(255) NOT NULL,
	`startTime` varchar(20),
	`endTime` varchar(20),
	`text` text NOT NULL,
	`tokenCount` int DEFAULT 0,
	`embeddingModel` varchar(100) NOT NULL DEFAULT 'openai',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `indexed_transcriptions_id` PRIMARY KEY(`id`),
	CONSTRAINT `indexed_transcriptions_chunkId_unique` UNIQUE(`chunkId`)
);
--> statement-breakpoint
CREATE TABLE `transcription_uploads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`filename` varchar(255) NOT NULL,
	`fileType` varchar(10) NOT NULL,
	`fileUrl` text,
	`fileKey` text,
	`status` enum('pending','processing','indexed','failed') NOT NULL DEFAULT 'pending',
	`errorMessage` text,
	`segmentCount` int DEFAULT 0,
	`chunkCount` int DEFAULT 0,
	`totalTokens` int DEFAULT 0,
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `transcription_uploads_id` PRIMARY KEY(`id`)
);
