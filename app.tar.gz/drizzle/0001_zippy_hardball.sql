CREATE TABLE `export_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`searchResultId` int NOT NULL,
	`format` varchar(10) NOT NULL,
	`filename` varchar(255) NOT NULL,
	`fileUrl` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `export_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `search_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`mode` varchar(50) NOT NULL,
	`query` text NOT NULL,
	`resultCount` int DEFAULT 0,
	`executionTime` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `search_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `search_results` (
	`id` int AUTO_INCREMENT NOT NULL,
	`searchHistoryId` int NOT NULL,
	`mode` varchar(50) NOT NULL,
	`content` text NOT NULL,
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `search_results_id` PRIMARY KEY(`id`)
);
