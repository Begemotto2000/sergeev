CREATE TABLE `faq_analytics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`faqItemId` int NOT NULL,
	`faqId` varchar(50) NOT NULL,
	`viewsToday` int DEFAULT 0,
	`viewsWeek` int DEFAULT 0,
	`viewsMonth` int DEFAULT 0,
	`viewsTotal` int DEFAULT 0,
	`helpfulToday` int DEFAULT 0,
	`helpfulWeek` int DEFAULT 0,
	`helpfulMonth` int DEFAULT 0,
	`helpfulTotal` int DEFAULT 0,
	`avgRating` decimal(3,2) DEFAULT '0',
	`ratingCount` int DEFAULT 0,
	`searchImpressions` int DEFAULT 0,
	`searchClicks` int DEFAULT 0,
	`trendingScore` decimal(5,2) DEFAULT '0',
	`lastUpdated` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `faq_analytics_id` PRIMARY KEY(`id`),
	CONSTRAINT `faq_analytics_faqItemId_unique` UNIQUE(`faqItemId`)
);
--> statement-breakpoint
CREATE TABLE `faq_categories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`categoryId` int NOT NULL,
	`name` varchar(100) NOT NULL,
	`description` text,
	`icon` varchar(50),
	`color` varchar(20),
	`order` int DEFAULT 0,
	`itemCount` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `faq_categories_id` PRIMARY KEY(`id`),
	CONSTRAINT `faq_categories_categoryId_unique` UNIQUE(`categoryId`)
);
--> statement-breakpoint
CREATE TABLE `faq_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`faqId` varchar(50) NOT NULL,
	`categoryId` int NOT NULL,
	`questionNumber` int NOT NULL,
	`question` text NOT NULL,
	`answer` text NOT NULL,
	`shortTitle` varchar(100),
	`createdFrom` enum('ai_extraction','manual','user_question') NOT NULL DEFAULT 'manual',
	`extractedFrom` varchar(255),
	`tags` json,
	`relatedQuestions` json,
	`views` int DEFAULT 0,
	`helpful` int DEFAULT 0,
	`notHelpful` int DEFAULT 0,
	`rating` decimal(3,2) DEFAULT '0',
	`version` int DEFAULT 1,
	`previousVersions` json,
	`status` enum('published','draft','archived') NOT NULL DEFAULT 'published',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `faq_items_id` PRIMARY KEY(`id`),
	CONSTRAINT `faq_items_faqId_unique` UNIQUE(`faqId`)
);
--> statement-breakpoint
CREATE TABLE `faq_sources` (
	`id` int AUTO_INCREMENT NOT NULL,
	`faqItemId` int NOT NULL,
	`sourceType` enum('video','chat','разбор','созвон','документ') NOT NULL,
	`title` varchar(255) NOT NULL,
	`url` text,
	`timestamp` varchar(20),
	`date` date,
	`time` time,
	`archiveId` varchar(100),
	`duration` varchar(20),
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `faq_sources_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `faq_user_questions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`question` text NOT NULL,
	`matchedFAQId` varchar(50),
	`matchConfidence` decimal(3,2) DEFAULT '0',
	`isAnswered` boolean DEFAULT false,
	`wasHelpful` boolean,
	`feedback` text,
	`status` enum('new','reviewed','converted_to_faq','archived') NOT NULL DEFAULT 'new',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `faq_user_questions_id` PRIMARY KEY(`id`)
);
