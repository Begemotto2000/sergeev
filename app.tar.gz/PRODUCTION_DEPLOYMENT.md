# Sergeyev Digitization System - Production Deployment Guide v2.0

## 📋 Обзор

Полностью автономная система для обработки архивов с контентом обучения, разбиения на чанки, генерирования семантических embeddings и индексирования в Qdrant.

**Сервер:** 46.8.255.137  
**Основной порт:** 4000 (production-server.mjs)  
**Версия:** 2.0.0  
**Статус:** Production Ready ✅

## 🆕 Что нового в v2.0

| Функция | v1.0 | v2.0 |
|---------|------|------|
| Embeddings | Hash-based (детерминированные) | OpenAI text-embedding-3-small |
| Аутентификация | Нет | API Key (X-API-Key header) |
| HTTPS/SSL | Нет | Nginx + Let's Encrypt |
| Размер embeddings | 384 | 1536 |
| Поиск | Детерминированный | Семантический (косинусное сходство) |

## 🏗️ Архитектура

```
Internet (HTTPS 443)
    ↓
Nginx (reverse proxy, SSL termination)
    ↓
Production Server (HTTP 4000)
├── OpenAI API (embeddings)
├── PostgreSQL (метаданные)
├── Redis (кэширование)
└── Qdrant (векторный индекс)
```

## 🚀 Быстрая установка

### Вариант 1: Прямой запуск Node.js

```bash
ssh root@46.8.255.137
cd /opt/sergeev/app

# Установить переменные окружения
export OPENAI_API_KEY="sk-proj-..."
export API_KEY_REQUIRED="true"
export PORT=4000

# Запустить production server
nohup node production-server.mjs > /tmp/prod-server.log 2>&1 &
```

### Вариант 2: Docker контейнеры

```bash
cd /opt/sergeev/app
docker compose -f docker-compose-https.yml up -d
```

## 🔐 Аутентификация

### API Key требования

- **Обязательно:** X-API-Key header или api_key query параметр
- **Минимальная длина:** 10 символов
- **Формат:** Любой строковый ключ (в production: хранить в БД)

### Примеры

#### Header аутентификация

```bash
curl -X POST \
  -H "X-API-Key: your-api-key-12345" \
  -H "X-Filename: lessons.zip" \
  --data-binary @lessons.zip \
  http://localhost:4000/api/upload
```

#### Query параметр аутентификация

```bash
curl -X POST \
  -H "X-Filename: lessons.zip" \
  --data-binary @lessons.zip \
  "http://localhost:4000/api/upload?api_key=your-api-key-12345"
```

#### Ошибка без ключа

```bash
curl -X POST \
  -H "X-Filename: lessons.zip" \
  --data-binary @lessons.zip \
  http://localhost:4000/api/upload

# Ответ:
# {
#   "error": "Missing API key",
#   "message": "Please provide X-API-Key header or api_key query parameter"
# }
```

## 📡 API Endpoints

### 1. Загрузка архива (требует аутентификацию)

```bash
POST /api/upload
X-API-Key: your-api-key
X-Filename: lessons.zip

# Тело: бинарные данные архива

# Ответ:
{
  "jobId": "uuid",
  "status": "processing",
  "message": "Archive uploaded successfully"
}
```

### 2. Список всех задач

```bash
GET /api/jobs

# Ответ:
[
  {
    "id": "uuid",
    "filename": "lessons.zip",
    "status": "completed",
    "progress": 100,
    "created_at": "2026-05-13T18:00:00Z",
    "completed_at": "2026-05-13T18:05:00Z"
  }
]
```

### 3. Детали задачи

```bash
GET /api/job/:id

# Ответ:
{
  "id": "uuid",
  "filename": "lessons.zip",
  "status": "completed",
  "progress": 100,
  "logs": [
    {
      "timestamp": "2026-05-13T18:00:00Z",
      "message": "✅ Archive received",
      "level": "success"
    }
  ],
  "result": {
    "success": true,
    "lessons_processed": 5,
    "chunks_created": 150,
    "indexed_in_qdrant": true,
    "embedding_model": "text-embedding-3-small",
    "errors": []
  }
}
```

### 4. Семантический поиск

```bash
GET /api/search?q=Python&limit=10

# Ответ:
{
  "query": "Python",
  "results": [
    {
      "id": "chunk-1",
      "lesson": "Python Basics",
      "module": "Module 1",
      "text": "Introduction to Python...",
      "score": 0.9523,
      "metadata": { "lesson_id": "lesson-1" }
    }
  ],
  "total": 1,
  "limit": 10,
  "embedding_model": "text-embedding-3-small"
}
```

### 5. Статус системы

```bash
GET /api/status

# Ответ:
{
  "status": "healthy",
  "timestamp": "2026-05-13T18:02:43Z",
  "mode": "production",
  "version": "2.0.0",
  "features": {
    "openai_embeddings": true,
    "api_key_auth": true,
    "https": false
  },
  "jobs": {
    "total": 5,
    "completed": 3,
    "processing": 1,
    "failed": 1
  },
  "services": {
    "qdrant": "connected",
    "postgresql": "connected",
    "redis": "connected",
    "openai": "connected"
  },
  "uptime": 124.13
}
```

### 6. Dashboard

```
GET /dashboard
```

Веб-интерфейс для мониторинга статуса системы.

## 🤖 OpenAI Embeddings

### Модель

- **Model:** text-embedding-3-small
- **Dimensions:** 1536
- **Similarity:** Cosine (косинусное сходство)

### Конфигурация

```bash
export OPENAI_API_KEY="sk-proj-..."
```

### Fallback механизм

Если OpenAI API недоступен, система автоматически использует hash-based embeddings для обеспечения отказоустойчивости.

## 📦 Формат архива

### Поддерживаемые форматы

- **TXT** - простой текст (UTF-8)
- **SRT** - субтитры (SubRip)
- **JSON** - структурированные данные
- **CSV** - табличные данные
- **ZIP, TAR, GZ** - сжатые архивы

### Структура архива (пример)

```
lessons.zip
├── lesson-1.txt
├── lesson-2.srt
├── lesson-3.json
└── module-1/
    ├── chapter-1.txt
    └── chapter-2.srt
```

## 🔄 Обработка данных

### Этапы обработки

1. **Загрузка** - получение архива (требует API ключ)
2. **Извлечение** - распаковка архива
3. **Парсинг** - чтение содержимого файлов
4. **Разбиение на чанки** - разбиение на части (50 слов / 300 символов)
5. **Векторизация** - генерирование OpenAI embeddings (1536 dimensions)
6. **Индексирование** - добавление в Qdrant с косинусным сходством
7. **Завершение** - сохранение метаданных

### Логирование

Каждый этап логируется с временной меткой:

```
[2026-05-13T18:00:00Z] ✅ Archive received: lessons.zip (2.45MB)
[2026-05-13T18:00:00Z] 🔑 Authenticated with API key: your-api...
[2026-05-13T18:00:00Z] 🔍 Generated embedding (1536 dimensions)
[2026-05-13T18:00:01Z] 📂 Extracting archive...
[2026-05-13T18:00:02Z] 📄 Parsing files...
[2026-05-13T18:00:03Z] ✂️ Chunking content...
[2026-05-13T18:00:05Z] 🔍 Vectorizing and indexing...
[2026-05-13T18:00:10Z] ✅ Processing completed successfully!
```

## 🔒 Безопасность

### Текущая реализация

- ✅ API Key аутентификация (X-API-Key header)
- ✅ OpenAI API ключ в переменной окружения
- ✅ Минимальная валидация ключа (10+ символов)
- ⚠️ Нет HTTPS (настроить через Nginx)
- ⚠️ Нет ограничения размера файла (500MB)

### Рекомендации для production

1. **API Key Management:**
   - Хранить ключи в PostgreSQL с хешированием (bcrypt)
   - Реализовать ротацию ключей
   - Логировать использование ключей

2. **HTTPS/SSL:**
   - Установить Nginx с Let's Encrypt
   - Настроить автообновление сертификатов
   - Добавить HSTS заголовок

3. **Rate Limiting:**
   - Ограничить запросы по API ключу
   - Защитить от DDoS атак

4. **Firewall:**
   - Открыть только необходимые порты (80, 443, 4000)
   - Ограничить доступ к PostgreSQL/Redis/Qdrant

## 📊 Мониторинг

### Проверка статуса

```bash
curl http://localhost:4000/api/status
```

### Логи приложения

```bash
tail -f /tmp/prod-server.log
```

### Проверить слушающие порты

```bash
netstat -tlnp | grep -E ':(80|443|4000)'
```

## 🛠️ Troubleshooting

### Проблема: "Port already in use"

```bash
lsof -i :4000
kill -9 <PID>
```

### Проблема: "OpenAI API error"

```bash
# Проверить API ключ
node test-openai.mjs

# Проверить интернет соединение
curl https://api.openai.com/v1/models
```

### Проблема: "Invalid API key"

```bash
# Проверить длину ключа (минимум 10 символов)
echo -n "your-key" | wc -c

# Проверить формат header
curl -H "X-API-Key: your-api-key-12345" http://localhost:4000/api/status
```

## 📈 Масштабирование

### Для обработки больших объёмов

1. Увеличить лимит памяти Node.js:
   ```bash
   NODE_OPTIONS="--max-old-space-size=4096" node production-server.mjs
   ```

2. Использовать Redis для кэширования результатов

3. Добавить очередь обработки (Bull, RabbitMQ)

4. Распределить обработку на несколько воркеров

## 🔗 Интеграция

### Python пример

```python
import requests

# Загрузка архива
with open('lessons.zip', 'rb') as f:
    response = requests.post(
        'http://localhost:4000/api/upload',
        headers={'X-API-Key': 'your-api-key-12345'},
        data=f
    )
    job_id = response.json()['jobId']

# Поиск
response = requests.get(
    'http://localhost:4000/api/search',
    params={'q': 'Python', 'limit': 10}
)
results = response.json()['results']
```

### JavaScript пример

```javascript
// Загрузка архива
const response = await fetch('http://localhost:4000/api/upload', {
  method: 'POST',
  headers: {
    'X-API-Key': 'your-api-key-12345',
    'X-Filename': 'lessons.zip'
  },
  body: fileData
});

// Поиск
const search = await fetch(
  'http://localhost:4000/api/search?q=Python&limit=10'
);
const results = await search.json();
```

## 📝 Версия

- **Версия:** 2.0.0
- **Дата:** 2026-05-13
- **Статус:** Production Ready
- **Тесты:** 
  - ✅ OpenAI embeddings: PASSED
  - ✅ API Key auth: 5/5 PASSED
  - ✅ E2E embeddings: PASSED

## 🎯 Следующие шаги

1. ✅ Настроить OpenAI embeddings
2. ✅ Добавить API key аутентификацию
3. ⏳ Настроить HTTPS на production сервере
4. ⏳ Реализовать управление API ключами в БД
5. ⏳ Добавить rate limiting
6. ⏳ Настроить мониторинг и алерты
