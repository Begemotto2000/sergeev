/**
 * Upload Handler Module
 * Handles file uploads, archive processing, and job management
 * Uses native Node.js streams for multipart/form-data parsing
 */

import { Express, Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { randomUUID } from 'crypto';

// Lazy import archiveProcessor to avoid loading pdf-parse at startup
let processArchive: any = null;
async function getProcessArchive() {
  if (!processArchive) {
    const mod = await import('./archiveProcessor');
    processArchive = mod.processArchive;
  }
  return processArchive;
}

// Job status tracking
interface JobLog {
  timestamp: string;
  message: string;
  level: 'info' | 'success' | 'error' | 'warning';
}

interface Job {
  id: string;
  filename: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress: number;
  logs: JobLog[];
  result?: {
    success: boolean;
    lessons_processed: number;
    lessons_deduplicated: number;
    lessons_new: number;
    errors: string[];
  };
  created_at: string;
  started_at?: string;
  completed_at?: string;
}

// In-memory job storage (in production, use database)
const jobs = new Map<string, Job>();

// Upload directory
const uploadDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

/**
 * Add log entry to job
 */
function addJobLog(jobId: string, message: string, level: JobLog['level'] = 'info'): void {
  const job = jobs.get(jobId);
  if (job) {
    job.logs.push({
      timestamp: new Date().toISOString(),
      message,
      level,
    });
  }
}

/**
 * Update job progress
 */
function updateJobProgress(jobId: string, progress: number): void {
  const job = jobs.get(jobId);
  if (job) {
    job.progress = Math.min(100, Math.max(0, progress));
  }
}

/**
 * Parse multipart form data using native Node.js
 */
async function parseUploadRequest(req: Request): Promise<{ filename: string; filepath: string } | null> {
  return new Promise((resolve, reject) => {
    const contentType = req.headers['content-type'] || '';
    const boundaryMatch = contentType.match(/boundary=([^;]+)/);
    
    if (!boundaryMatch) {
      reject(new Error('Invalid content-type header'));
      return;
    }

    const boundary = boundaryMatch[1].replace(/"/g, '');
    const boundaryBuffer = Buffer.from(`--${boundary}`);
    const endBoundaryBuffer = Buffer.from(`--${boundary}--`);
    
    let buffer = Buffer.alloc(0);
    let fileInfo: { filename: string; filepath: string } | null = null;
    let writeStream: fs.WriteStream | null = null;
    let isInFile = false;
    let headersParsed = false;

    req.on('data', (chunk: Buffer) => {
      buffer = Buffer.concat([buffer, chunk]);

      // Look for boundary
      let boundaryIndex = buffer.indexOf(boundaryBuffer);
      
      while (boundaryIndex !== -1) {
        if (isInFile && writeStream) {
          // Write data before boundary to file
          const dataBeforeBoundary = buffer.slice(0, boundaryIndex - 2); // -2 for \r\n
          writeStream.write(dataBeforeBoundary);
          isInFile = false;
        }

        buffer = buffer.slice(boundaryIndex + boundaryBuffer.length);

        // Check for end boundary
        if (buffer.toString('utf8', 0, 2) === '--') {
          resolve(fileInfo);
          return;
        }

        // Skip to next line
        const lineEnd = buffer.indexOf('\n');
        if (lineEnd === -1) break;

        buffer = buffer.slice(lineEnd + 1);

        // Parse headers
        if (!headersParsed) {
          let headersEnd = buffer.indexOf('\r\n\r\n');
          if (headersEnd === -1) headersEnd = buffer.indexOf('\n\n');
          
          if (headersEnd !== -1) {
            const headersStr = buffer.slice(0, headersEnd).toString('utf8');
            const filenameMatch = headersStr.match(/filename="([^"]+)"/);
            
            if (filenameMatch) {
              const filename = filenameMatch[1];
              
              if (!filename.endsWith('.zip')) {
                reject(new Error('Only ZIP files are allowed'));
                return;
              }

              const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
              const filepath = path.join(uploadDir, `file-${uniqueSuffix}-${filename}`);
              
              fileInfo = { filename, filepath };
              writeStream = fs.createWriteStream(filepath);
              isInFile = true;
              headersParsed = true;

              writeStream.on('error', (err) => {
                reject(err);
              });

              buffer = buffer.slice(headersEnd + 4);
            }
          }
        } else {
          isInFile = true;
        }

        boundaryIndex = buffer.indexOf(boundaryBuffer);
      }

      // Write remaining data to file if in file mode
      if (isInFile && writeStream && buffer.length > 100) {
        const toWrite = buffer.slice(0, -100);
        writeStream.write(toWrite);
        buffer = buffer.slice(-100);
      }
    });

    req.on('end', () => {
      if (writeStream) {
        writeStream.end();
      }
      if (!fileInfo) {
        reject(new Error('No file uploaded'));
      }
    });

    req.on('error', (err) => {
      if (writeStream) writeStream.destroy();
      reject(err);
    });
  });
}

/**
 * Process job asynchronously
 */
async function processJobAsync(jobId: string, filePath: string): Promise<void> {
  const job = jobs.get(jobId);
  if (!job) return;

  try {
    job.status = 'processing';
    job.started_at = new Date().toISOString();
    addJobLog(jobId, '🔄 Starting archive processing...', 'info');

    // Get the processArchive function (lazy loaded)
    const processArchiveFn = await getProcessArchive();

    // Process the archive
    const result = await processArchiveFn(filePath, (progress: number) => {
      updateJobProgress(jobId, progress);
      addJobLog(jobId, `📊 Progress: ${progress}%`, 'info');
    });

    job.status = 'completed';
    job.completed_at = new Date().toISOString();
    job.result = result;
    addJobLog(jobId, `✅ Processing completed successfully!`, 'success');
    addJobLog(
      jobId,
      `📈 Results: ${result.lessons_processed} processed, ${result.lessons_new} new, ${result.lessons_deduplicated} deduplicated`,
      'success'
    );

    if (result.errors.length > 0) {
      addJobLog(jobId, `⚠️ Errors: ${result.errors.join(', ')}`, 'warning');
    }

    // Cleanup uploaded file
    fs.unlink(filePath, (err) => {
      if (err) console.error('Failed to delete uploaded file:', err);
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    job.status = 'failed';
    job.completed_at = new Date().toISOString();
    addJobLog(jobId, `❌ Error: ${message}`, 'error');

    // Cleanup
    fs.unlink(filePath, (err) => {
      if (err) console.error('Failed to delete uploaded file:', err);
    });
  }
}

/**
 * POST /api/upload - Upload and process archive
 */
async function handleUpload(req: Request, res: Response): Promise<void> {
  try {
    // Parse the upload request
    const fileInfo = await parseUploadRequest(req);
    
    if (!fileInfo) {
      res.status(400).json({ error: 'No file uploaded' });
      return;
    }

    const jobId = randomUUID();
    const job: Job = {
      id: jobId,
      filename: fileInfo.filename,
      status: 'pending',
      progress: 0,
      logs: [],
      created_at: new Date().toISOString(),
    };

    jobs.set(jobId, job);

    // Send immediate response with job ID
    res.json({
      success: true,
      jobId,
      message: 'Upload started. Check job status for progress.',
    });

    // Process archive asynchronously
    processJobAsync(jobId, fileInfo.filepath);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    res.status(500).json({
      error: 'Upload failed',
      message,
    });
  }
}

/**
 * GET /api/job/:jobId - Get job status
 */
function handleGetJobStatus(req: Request, res: Response): void {
  const { jobId } = req.params;
  const job = jobs.get(jobId);

  if (!job) {
    res.status(404).json({ error: 'Job not found' });
    return;
  }

  res.json({
    id: job.id,
    filename: job.filename,
    status: job.status,
    progress: job.progress,
    logs: job.logs,
    result: job.result,
    created_at: job.created_at,
    started_at: job.started_at,
    completed_at: job.completed_at,
  });
}

/**
 * Register upload routes
 */
export function registerUploadRoutes(app: Express): void {
  // POST /api/upload - Upload and process archive
  app.post('/api/upload', handleUpload);

  // GET /api/job/:jobId - Get job status
  app.get('/api/job/:jobId', handleGetJobStatus);

  // GET /api/jobs - List all jobs (for debugging)
  app.get('/api/jobs', (req: Request, res: Response) => {
    const jobsList = Array.from(jobs.values()).map(job => ({
      id: job.id,
      filename: job.filename,
      status: job.status,
      progress: job.progress,
      created_at: job.created_at,
      completed_at: job.completed_at,
    }));
    res.json(jobsList);
  });

  console.log('✅ Upload routes registered');
}
