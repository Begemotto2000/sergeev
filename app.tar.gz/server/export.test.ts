import { describe, it, expect } from 'vitest';
import { exportToMarkdown, generateFilename } from './export';

describe('Export Functionality', () => {
  const mockOptions = {
    title: 'Test Results',
    content: '# Content\n\nThis is test content.',
    mode: 'ОТВЕТ',
    query: 'test query',
    timestamp: new Date('2026-05-06T10:00:00Z'),
  };

  describe('exportToMarkdown', () => {
    it('should generate markdown with header', async () => {
      const result = await exportToMarkdown(mockOptions);

      expect(result).toContain('# Test Results');
      expect(result).toContain('**Режим:** ОТВЕТ');
      expect(result).toContain('**Запрос:** test query');
      expect(result).toContain('**Дата:**');
    });

    it('should include content in markdown', async () => {
      const result = await exportToMarkdown(mockOptions);

      expect(result).toContain('# Content');
      expect(result).toContain('This is test content.');
    });

    it('should handle empty content', async () => {
      const result = await exportToMarkdown({
        ...mockOptions,
        content: '',
      });

      expect(result).toContain('# Test Results');
      expect(result).toContain('---');
    });

    it('should format timestamp correctly', async () => {
      const result = await exportToMarkdown(mockOptions);

      expect(result).toMatch(/\d{1,2}\.\d{1,2}\.\d{4}/); // Date format
    });
  });

  describe('generateFilename', () => {
    it('should generate filename from query and mode', () => {
      const filename = generateFilename('What is marketing?', 'ОТВЕТ');

      expect(filename).toContain('ОТВЕТ');
      expect(filename).toMatch(/\d+/); // Should contain timestamp
    });

    it('should sanitize special characters', () => {
      const filename = generateFilename('Test@#$%^&*()', 'ТАЙМКОД');

      expect(filename).not.toContain('@');
      expect(filename).not.toContain('#');
      expect(filename).not.toContain('$');
    });

    it('should handle long queries', () => {
      const longQuery = 'A'.repeat(100);
      const filename = generateFilename(longQuery, 'DEEP RESEARCH');

      expect(filename.length).toBeLessThan(100); // Should be truncated
    });

    it('should convert to lowercase', () => {
      const filename = generateFilename('UPPERCASE QUERY', 'ИМИГО');

      expect(filename).toMatch(/[a-z_]/);
    });

    it('should include mode prefix', () => {
      const modes = ['ОТВЕТ', 'ТАЙМКОД', 'DEEP RESEARCH', 'ИМИГО'];

      modes.forEach((mode) => {
        const filename = generateFilename('test', mode);
        expect(filename).toContain(mode);
      });
    });
  });

  describe('Export format support', () => {
    it('should support markdown format', () => {
      expect(['pdf', 'docx', 'md']).toContain('md');
    });

    it('should support docx format', () => {
      expect(['pdf', 'docx', 'md']).toContain('docx');
    });

    it('should support pdf format', () => {
      expect(['pdf', 'docx', 'md']).toContain('pdf');
    });
  });

  describe('Content parsing', () => {
    it('should handle markdown headers', async () => {
      const content = '# Header 1\n## Header 2\n### Header 3';
      const result = await exportToMarkdown({
        ...mockOptions,
        content,
      });

      expect(result).toContain('# Header 1');
      expect(result).toContain('## Header 2');
      expect(result).toContain('### Header 3');
    });

    it('should handle bullet points', async () => {
      const content = '- Item 1\n- Item 2\n  - Subitem';
      const result = await exportToMarkdown({
        ...mockOptions,
        content,
      });

      expect(result).toContain('- Item 1');
      expect(result).toContain('- Item 2');
    });

    it('should handle bold text', async () => {
      const content = 'This is **bold** text';
      const result = await exportToMarkdown({
        ...mockOptions,
        content,
      });

      expect(result).toContain('**bold**');
    });

    it('should handle code blocks', async () => {
      const content = '```\ncode here\n```';
      const result = await exportToMarkdown({
        ...mockOptions,
        content,
      });

      expect(result).toContain('```');
    });
  });

  describe('Metadata handling', () => {
    it('should include mode in export', async () => {
      const result = await exportToMarkdown({
        ...mockOptions,
        mode: 'DEEP RESEARCH',
      });

      expect(result).toContain('DEEP RESEARCH');
    });

    it('should include query in export', async () => {
      const result = await exportToMarkdown({
        ...mockOptions,
        query: 'What is mentorship?',
      });

      expect(result).toContain('What is mentorship?');
    });

    it('should include title in export', async () => {
      const result = await exportToMarkdown({
        ...mockOptions,
        title: 'Research Results',
      });

      expect(result).toContain('Research Results');
    });
  });

  describe('File naming conventions', () => {
    it('should use consistent naming pattern', () => {
      const filename1 = generateFilename('query', 'ОТВЕТ');
      const filename2 = generateFilename('query', 'ОТВЕТ');

      // Both should have mode prefix
      expect(filename1).toContain('ОТВЕТ');
      expect(filename2).toContain('ОТВЕТ');
    });

    it('should include timestamp for uniqueness', () => {
      const filename1 = generateFilename('query', 'ТАЙМКОД');
      const filename2 = generateFilename('query', 'ТАЙМКОД');

      // Timestamps might be different
      expect(filename1).toMatch(/\d+/);
      expect(filename2).toMatch(/\d+/);
    });
  });
});
