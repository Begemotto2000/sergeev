import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import {
  batchUpsertVectors,
  cachedSearch,
  optimizeIndex,
  getPerformanceMetrics,
  clearCache,
  analyzeQueryPerformance,
  generateOptimizationReport,
} from './qdrantOptimization';

describe('Qdrant Optimization', () => {
  beforeEach(() => {
    clearCache();
  });

  afterEach(() => {
    clearCache();
  });

  describe('batchUpsertVectors', () => {
    it('should batch upsert vectors successfully', async () => {
      const vectors = Array.from({ length: 250 }, (_, i) => ({
        id: `vec-${i}`,
        vector: Array(384).fill(Math.random()),
        metadata: { index: i },
      }));

      const result = await batchUpsertVectors(vectors, {
        batchSize: 100,
        cacheEnabled: true,
        cacheTTL: 300000,
        indexOptimization: true,
      });

      expect(result.success).toBe(true);
      expect(result.batchCount).toBe(3);
      expect(result.avgTime).toBeGreaterThan(0);
    });

    it('should handle empty vector list', async () => {
      const result = await batchUpsertVectors([]);

      expect(result.success).toBe(true);
      expect(result.batchCount).toBe(0);
    });
  });

  describe('cachedSearch', () => {
    it('should cache search results', async () => {
      let callCount = 0;
      const mockSearch = async (q: string) => {
        callCount++;
        return { query: q, results: ['result1', 'result2'] };
      };

      // First call - should execute search
      const result1 = await cachedSearch('test query', mockSearch);
      expect(result1.cached).toBe(false);
      expect(callCount).toBe(1);

      // Second call - should return cached result
      const result2 = await cachedSearch('test query', mockSearch);
      expect(result2.cached).toBe(true);
      expect(callCount).toBe(1); // Should not increment
      expect(result2.cacheAge).toBeGreaterThanOrEqual(0);
    });

    it('should not cache when caching is disabled', async () => {
      let callCount = 0;
      const mockSearch = async (q: string) => {
        callCount++;
        return { query: q, results: [] };
      };

      const result1 = await cachedSearch('test', mockSearch, {
        batchSize: 100,
        cacheEnabled: false,
        cacheTTL: 300000,
        indexOptimization: true,
      });
      expect(result1.cached).toBe(false);

      const result2 = await cachedSearch('test', mockSearch, {
        batchSize: 100,
        cacheEnabled: false,
        cacheTTL: 300000,
        indexOptimization: true,
      });
      expect(result2.cached).toBe(false);
      expect(callCount).toBe(2);
    });
  });

  describe('optimizeIndex', () => {
    it('should optimize index successfully', async () => {
      const result = await optimizeIndex('test_collection');

      expect(result.success).toBe(true);
      expect(result.optimizationTime).toBeGreaterThan(0);
    });
  });

  describe('getPerformanceMetrics', () => {
    it('should return performance metrics', async () => {
      const metrics = await getPerformanceMetrics();

      expect(metrics.avgSearchTime).toBeGreaterThan(0);
      expect(metrics.avgUpsertTime).toBeGreaterThan(0);
      expect(metrics.cacheHitRate).toBeGreaterThanOrEqual(0);
      expect(metrics.cacheHitRate).toBeLessThanOrEqual(100);
      expect(metrics.indexSize).toBeGreaterThanOrEqual(0);
    });
  });

  describe('analyzeQueryPerformance', () => {
    it('should analyze query performance', async () => {
      const queries = ['query1', 'query2', 'query3'];
      const result = await analyzeQueryPerformance(queries);

      expect(result.avgTime).toBeGreaterThan(0);
      expect(result.slowestQuery).toBeTruthy();
      expect(result.fastestQuery).toBeTruthy();
      expect(Array.isArray(result.recommendations)).toBe(true);
    });

    it('should generate recommendations for slow queries', async () => {
      const queries = Array.from({ length: 10 }, (_, i) => `query${i}`);
      const result = await analyzeQueryPerformance(queries);

      expect(result.recommendations.length).toBeGreaterThanOrEqual(0);
    });
  });

  describe('generateOptimizationReport', () => {
    it('should generate optimization report', async () => {
      const report = await generateOptimizationReport();

      expect(report.metrics).toBeDefined();
      expect(report.recommendations).toBeDefined();
      expect(report.optimizationScore).toBeGreaterThanOrEqual(0);
      expect(report.optimizationScore).toBeLessThanOrEqual(100);
    });

    it('should include metrics in report', async () => {
      const report = await generateOptimizationReport();

      expect(report.metrics.avgSearchTime).toBeGreaterThan(0);
      expect(report.metrics.avgUpsertTime).toBeGreaterThan(0);
      expect(report.metrics.cacheHitRate).toBeDefined();
    });
  });

  describe('clearCache', () => {
    it('should clear cache', async () => {
      const mockSearch = async (q: string) => ({ results: [] });

      // Add items to cache
      await cachedSearch('query1', mockSearch);
      await cachedSearch('query2', mockSearch);

      const result = clearCache();
      expect(result.clearedSize).toBeGreaterThan(0);

      // Verify cache is cleared
      const metrics = await getPerformanceMetrics();
      expect(metrics.indexSize).toBe(0);
    });
  });
});
