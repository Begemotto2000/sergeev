/**
 * Rate Limiting Module
 * Implements per-user and global rate limiting with adaptive limits
 */

import { getRedisClient, incrementCounter, getCounter, setCounter, getCacheKey } from './redis';

export interface RateLimitConfig {
  windowMs: number; // Time window in milliseconds
  maxRequests: number; // Max requests per window
  message: string;
  statusCode: number;
  skipSuccessfulRequests: boolean;
  skipFailedRequests: boolean;
}

export interface RateLimitStatus {
  limit: number;
  current: number;
  remaining: number;
  resetTime: number;
  isLimited: boolean;
}

export interface AdaptiveLimitConfig {
  baseLimit: number;
  minLimit: number;
  maxLimit: number;
  systemLoadThreshold: number; // CPU/memory threshold
  adjustmentFactor: number; // How much to adjust per check
}

// Default configurations
const DEFAULT_CONFIG: RateLimitConfig = {
  windowMs: 60 * 1000, // 1 minute
  maxRequests: 100,
  message: 'Too many requests, please try again later.',
  statusCode: 429,
  skipSuccessfulRequests: false,
  skipFailedRequests: false,
};

const ADAPTIVE_CONFIG: AdaptiveLimitConfig = {
  baseLimit: 100,
  minLimit: 10,
  maxLimit: 500,
  systemLoadThreshold: 80,
  adjustmentFactor: 0.1,
};

/**
 * Check if user is rate limited
 */
export async function checkRateLimit(
  userId: number,
  config: Partial<RateLimitConfig> = {}
): Promise<RateLimitStatus> {
  const finalConfig = { ...DEFAULT_CONFIG, ...config };
  const key = getCacheKey('ratelimit', `user:${userId}`);
  const windowKey = getCacheKey('ratelimit:window', `user:${userId}`);

  try {
    const client = await getRedisClient();

    // Get current count
    const current = await getCounter(key);
    const windowStart = await getCounter(windowKey);
    const now = Date.now();

    // Check if window has expired
    if (windowStart === 0 || now - windowStart > finalConfig.windowMs) {
      // Reset window
      await setCounter(key, 1, finalConfig.windowMs / 1000);
      await setCounter(windowKey, now, finalConfig.windowMs / 1000);

      return {
        limit: finalConfig.maxRequests,
        current: 1,
        remaining: finalConfig.maxRequests - 1,
        resetTime: now + finalConfig.windowMs,
        isLimited: false,
      };
    }

    // Increment counter
    const newCount = await incrementCounter(key);

    const isLimited = newCount > finalConfig.maxRequests;

    return {
      limit: finalConfig.maxRequests,
      current: newCount,
      remaining: Math.max(0, finalConfig.maxRequests - newCount),
      resetTime: windowStart + finalConfig.windowMs,
      isLimited,
    };
  } catch (error) {
    console.error('Rate limit check error:', error);
    // Fail open - allow request if Redis is down
    return {
      limit: finalConfig.maxRequests,
      current: 0,
      remaining: finalConfig.maxRequests,
      resetTime: Date.now() + finalConfig.windowMs,
      isLimited: false,
    };
  }
}

/**
 * Check global rate limit
 */
export async function checkGlobalRateLimit(
  config: Partial<RateLimitConfig> = {}
): Promise<RateLimitStatus> {
  const finalConfig = { ...DEFAULT_CONFIG, ...config };
  const key = getCacheKey('ratelimit:global', 'all');
  const windowKey = getCacheKey('ratelimit:window:global', 'all');

  try {
    const current = await getCounter(key);
    const windowStart = await getCounter(windowKey);
    const now = Date.now();

    if (windowStart === 0 || now - windowStart > finalConfig.windowMs) {
      await setCounter(key, 1, finalConfig.windowMs / 1000);
      await setCounter(windowKey, now, finalConfig.windowMs / 1000);

      return {
        limit: finalConfig.maxRequests,
        current: 1,
        remaining: finalConfig.maxRequests - 1,
        resetTime: now + finalConfig.windowMs,
        isLimited: false,
      };
    }

    const newCount = await incrementCounter(key);
    const isLimited = newCount > finalConfig.maxRequests;

    return {
      limit: finalConfig.maxRequests,
      current: newCount,
      remaining: Math.max(0, finalConfig.maxRequests - newCount),
      resetTime: windowStart + finalConfig.windowMs,
      isLimited,
    };
  } catch (error) {
    console.error('Global rate limit check error:', error);
    return {
      limit: finalConfig.maxRequests,
      current: 0,
      remaining: finalConfig.maxRequests,
      resetTime: Date.now() + finalConfig.windowMs,
      isLimited: false,
    };
  }
}

/**
 * Get adaptive rate limit based on system load
 */
export async function getAdaptiveRateLimit(
  userId: number,
  systemLoad: number = 50
): Promise<number> {
  const config = ADAPTIVE_CONFIG;

  // Calculate adaptive limit based on system load
  if (systemLoad > config.systemLoadThreshold) {
    // Reduce limit when system is under heavy load
    const reductionFactor = (systemLoad - config.systemLoadThreshold) / 100;
    const reducedLimit = Math.max(
      config.minLimit,
      Math.floor(config.baseLimit * (1 - reductionFactor * config.adjustmentFactor))
    );
    return reducedLimit;
  }

  // Increase limit when system has capacity
  const capacityFactor = (100 - systemLoad) / 100;
  const increasedLimit = Math.min(
    config.maxLimit,
    Math.floor(config.baseLimit * (1 + capacityFactor * config.adjustmentFactor * 0.5))
  );

  return increasedLimit;
}

/**
 * Get priority-based rate limit
 */
export function getPriorityRateLimit(userRole: string): number {
  const limits: Record<string, number> = {
    admin: 1000,
    premium: 500,
    user: 100,
    guest: 20,
  };

  return limits[userRole] || limits.user;
}

/**
 * Record rate limit event
 */
export async function recordRateLimitEvent(
  userId: number,
  endpoint: string,
  status: 'allowed' | 'limited'
): Promise<void> {
  try {
    const key = getCacheKey('ratelimit:events', userId.toString());
    const event = {
      timestamp: Date.now(),
      endpoint,
      status,
    };

    // Store event in Redis list (keep last 1000 events per user)
    const client = await getRedisClient();
    await client.rPush(key, JSON.stringify(event));
    await client.lTrim(key, -1000, -1);
    await client.expire(key, 86400); // Expire after 24 hours
  } catch (error) {
    console.error('Failed to record rate limit event:', error);
  }
}

/**
 * Get rate limit statistics
 */
export async function getRateLimitStats(userId: number): Promise<{
  allowedCount: number;
  limitedCount: number;
  totalEvents: number;
  limitPercentage: number;
}> {
  try {
    const key = getCacheKey('ratelimit:events', userId.toString());
    const client = await getRedisClient();
    const events = await client.lRange(key, 0, -1);

    const parsed = events.map((e) => JSON.parse(e));
    const allowed = parsed.filter((e) => e.status === 'allowed').length;
    const limited = parsed.filter((e) => e.status === 'limited').length;
    const total = parsed.length;

    return {
      allowedCount: allowed,
      limitedCount: limited,
      totalEvents: total,
      limitPercentage: total > 0 ? (limited / total) * 100 : 0,
    };
  } catch (error) {
    console.error('Failed to get rate limit stats:', error);
    return {
      allowedCount: 0,
      limitedCount: 0,
      totalEvents: 0,
      limitPercentage: 0,
    };
  }
}

/**
 * Reset rate limit for user
 */
export async function resetRateLimit(userId: number): Promise<void> {
  try {
    const client = await getRedisClient();
    const key = getCacheKey('ratelimit', `user:${userId}`);
    const windowKey = getCacheKey('ratelimit:window', `user:${userId}`);

    await client.del([key, windowKey]);
  } catch (error) {
    console.error('Failed to reset rate limit:', error);
  }
}

/**
 * Reset global rate limit
 */
export async function resetGlobalRateLimit(): Promise<void> {
  try {
    const client = await getRedisClient();
    const key = getCacheKey('ratelimit:global', 'all');
    const windowKey = getCacheKey('ratelimit:window:global', 'all');

    await client.del([key, windowKey]);
  } catch (error) {
    console.error('Failed to reset global rate limit:', error);
  }
}

/**
 * Get rate limit configuration for endpoint
 */
export function getEndpointRateLimit(endpoint: string): Partial<RateLimitConfig> {
  const configs: Record<string, Partial<RateLimitConfig>> = {
    '/api/trpc/knowledgeBase.answerQuery': {
      windowMs: 60 * 1000,
      maxRequests: 30,
    },
    '/api/trpc/transcriptionIntake.uploadTranscription': {
      windowMs: 60 * 60 * 1000, // 1 hour
      maxRequests: 10,
    },
    '/api/trpc/knowledgeBase.deepResearch': {
      windowMs: 60 * 1000,
      maxRequests: 5,
    },
    '/api/trpc/health.getStatus': {
      windowMs: 10 * 1000,
      maxRequests: 100,
    },
  };

  return configs[endpoint] || DEFAULT_CONFIG;
}

/**
 * Check if endpoint should be rate limited
 */
export function shouldRateLimit(endpoint: string): boolean {
  const rateLimitedEndpoints = [
    '/api/trpc/knowledgeBase',
    '/api/trpc/transcriptionIntake',
    '/api/trpc/telegram',
    '/api/trpc/analyticsAdvanced',
  ];

  return rateLimitedEndpoints.some((prefix) => endpoint.startsWith(prefix));
}

/**
 * Get rate limit headers
 */
export function getRateLimitHeaders(status: RateLimitStatus): Record<string, string> {
  return {
    'X-RateLimit-Limit': status.limit.toString(),
    'X-RateLimit-Remaining': status.remaining.toString(),
    'X-RateLimit-Reset': status.resetTime.toString(),
  };
}
