/**
 * Export Functionality for Search Results
 * Supports PDF, DOCX, and Markdown formats
 */

import { Document, Packer, Paragraph, TextRun, HeadingLevel } from 'docx';
import { storagePut } from './storage';

interface ExportOptions {
  title: string;
  content: string;
  mode: string;
  query: string;
  timestamp: Date;
}

/**
 * Export to Markdown format
 */
export async function exportToMarkdown(options: ExportOptions): Promise<string> {
  const header = `# ${options.title}

**Режим:** ${options.mode}  
**Запрос:** ${options.query}  
**Дата:** ${options.timestamp.toLocaleString('ru-RU')}

---

`;

  return header + options.content;
}

/**
 * Export to DOCX format
 */
export async function exportToDocx(options: ExportOptions): Promise<Buffer> {
  // Parse markdown content into paragraphs
  const lines = options.content.split('\n');
  const paragraphs: Paragraph[] = [];

  // Add header
  paragraphs.push(
    new Paragraph({
      text: options.title,
      heading: HeadingLevel.HEADING_1,
      spacing: { after: 200 },
    })
  );

  paragraphs.push(
    new Paragraph({
      text: `Режим: ${options.mode}`,
      spacing: { after: 100 },
    })
  );

  paragraphs.push(
    new Paragraph({
      text: `Запрос: ${options.query}`,
      spacing: { after: 100 },
    })
  );

  paragraphs.push(
    new Paragraph({
      text: `Дата: ${options.timestamp.toLocaleString('ru-RU')}`,
      spacing: { after: 300 },
    })
  );

  // Parse content
  let currentHeading = '';
  for (const line of lines) {
    if (line.startsWith('# ')) {
      paragraphs.push(
        new Paragraph({
          text: line.replace('# ', ''),
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 200, after: 100 },
        })
      );
    } else if (line.startsWith('## ')) {
      paragraphs.push(
        new Paragraph({
          text: line.replace('## ', ''),
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 150, after: 100 },
        })
      );
    } else if (line.startsWith('### ')) {
      paragraphs.push(
        new Paragraph({
          text: line.replace('### ', ''),
          heading: HeadingLevel.HEADING_3,
          spacing: { before: 100, after: 50 },
        })
      );
    } else if (line.startsWith('- ')) {
      paragraphs.push(
        new Paragraph({
          text: line.replace('- ', ''),
          bullet: { level: 0 },
          spacing: { after: 50 },
        })
      );
    } else if (line.startsWith('  - ')) {
      paragraphs.push(
        new Paragraph({
          text: line.replace('  - ', ''),
          bullet: { level: 1 },
          spacing: { after: 50 },
        })
      );
    } else if (line.trim()) {
      // Handle bold text
      const runs: TextRun[] = [];
      const parts = line.split(/(\*\*.*?\*\*)/);

      for (const part of parts) {
        if (part.startsWith('**') && part.endsWith('**')) {
          runs.push(
            new TextRun({
              text: part.replace(/\*\*/g, ''),
              bold: true,
            })
          );
        } else if (part) {
          runs.push(new TextRun(part));
        }
      }

      if (runs.length > 0) {
        paragraphs.push(
          new Paragraph({
            children: runs,
            spacing: { after: 100 },
          })
        );
      }
    } else {
      // Empty line
      paragraphs.push(new Paragraph({ text: '' }));
    }
  }

  const doc = new Document({
    sections: [
      {
        properties: {},
        children: paragraphs,
      },
    ],
  });

  return Packer.toBuffer(doc);
}

/**
 * Export to PDF format (using markdown as intermediate)
 * In production, would use a PDF library like pdfkit or weasyprint
 */
export async function exportToPdf(options: ExportOptions): Promise<Buffer> {
  // For now, return markdown as a fallback
  // In production, use weasyprint or similar to convert HTML to PDF
  const markdown = await exportToMarkdown(options);
  return Buffer.from(markdown, 'utf-8');
}

/**
 * Save exported file to storage
 */
export async function saveExportedFile(
  format: 'pdf' | 'docx' | 'md',
  buffer: Buffer,
  filename: string
): Promise<{ key: string; url: string }> {
  const mimeTypes: Record<string, string> = {
    pdf: 'application/pdf',
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    md: 'text/markdown',
  };

  const key = `exports/${Date.now()}_${filename}.${format}`;
  const result = await storagePut(key, buffer, mimeTypes[format]);

  return result;
}

/**
 * Generate filename based on query and mode
 */
export function generateFilename(query: string, mode: string): string {
  const sanitized = query
    .replace(/[^a-z0-9а-яё]/gi, '_')
    .toLowerCase()
    .substring(0, 30);

  return `${mode}_${sanitized}_${Date.now()}`;
}
