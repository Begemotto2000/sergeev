/**
 * Analytics Module
 * Tracks and analyzes search queries, modes, and user behavior
 */

import { invokeLLM } from './_core/llm';

export interface QueryAnalytics {
  queryId: string;
  query: string;
  mode: 'ОТВЕТ' | 'ТАЙМКОД' | 'DEEP RESEARCH' | 'ИМИГО';
  resultCount: number;
  responseTime: number;
  confidence: number;
  timestamp: Date;
  userId?: string;
}

export interface ModeStatistics {
  mode: string;
  count: number;
  percentage: number;
  avgResponseTime: number;
  avgConfidence: number;
  successRate: number;
}

export interface AnalyticsInsight {
  title: string;
  description: string;
  recommendation: string;
  priority: 'high' | 'medium' | 'low';
  dataPoints: string[];
}

/**
 * Store query analytics
 */
export async function storeQueryAnalytics(analytics: QueryAnalytics): Promise<void> {
  try {
    // In production, would save to database
    console.log('[Analytics] Query recorded:', {
      query: analytics.query,
      mode: analytics.mode,
      resultCount: analytics.resultCount,
      responseTime: analytics.responseTime,
      confidence: analytics.confidence,
    });
  } catch (error) {
    console.error('Failed to store analytics:', error);
  }
}

/**
 * Get mode statistics from analytics data
 */
export function getModeStatistics(analyticsData: QueryAnalytics[]): ModeStatistics[] {
  const modeMap = new Map<string, QueryAnalytics[]>();

  // Group by mode
  for (const analytics of analyticsData) {
    if (!modeMap.has(analytics.mode)) {
      modeMap.set(analytics.mode, []);
    }
    modeMap.get(analytics.mode)!.push(analytics);
  }

  // Calculate statistics for each mode
  const statistics: ModeStatistics[] = [];
  const totalQueries = analyticsData.length;

  modeMap.forEach((queries, mode) => {
    const avgResponseTime = queries.reduce((sum, q) => sum + q.responseTime, 0) / queries.length;
    const avgConfidence = queries.reduce((sum, q) => sum + q.confidence, 0) / queries.length;
    const successRate = (queries.filter(q => q.resultCount > 0).length / queries.length) * 100;

    statistics.push({
      mode,
      count: queries.length,
      percentage: (queries.length / totalQueries) * 100,
      avgResponseTime,
      avgConfidence,
      successRate,
    });
  });

  return statistics.sort((a, b) => b.count - a.count);
}

/**
 * Generate insights from analytics data
 */
export async function generateAnalyticsInsights(
  analyticsData: QueryAnalytics[]
): Promise<AnalyticsInsight[]> {
  if (analyticsData.length === 0) {
    return [];
  }

  try {
    const modeStats = getModeStatistics(analyticsData);
    const insights: AnalyticsInsight[] = [];

    // Insight 1: Mode usage patterns
    const mostUsedMode = modeStats[0];
    const leastUsedMode = modeStats[modeStats.length - 1];

    insights.push({
      title: 'Mode Usage Pattern',
      description: `${mostUsedMode.mode} is the most used mode (${mostUsedMode.percentage.toFixed(1)}% of queries), while ${leastUsedMode.mode} is used only ${leastUsedMode.percentage.toFixed(1)}% of the time.`,
      recommendation: `Consider promoting ${leastUsedMode.mode} mode through tutorials or examples, as it might be underutilized.`,
      priority: 'medium',
      dataPoints: [
        `${mostUsedMode.mode}: ${mostUsedMode.count} queries`,
        `${leastUsedMode.mode}: ${leastUsedMode.count} queries`,
      ],
    });

    // Insight 2: Performance by mode
    const slowestMode = modeStats.reduce((prev, curr) =>
      curr.avgResponseTime > prev.avgResponseTime ? curr : prev
    );
    const fastestMode = modeStats.reduce((prev, curr) =>
      curr.avgResponseTime < prev.avgResponseTime ? curr : prev
    );

    insights.push({
      title: 'Performance Variation',
      description: `Response times vary significantly by mode. ${fastestMode.mode} averages ${fastestMode.avgResponseTime.toFixed(0)}ms, while ${slowestMode.mode} averages ${slowestMode.avgResponseTime.toFixed(0)}ms.`,
      recommendation: `Optimize ${slowestMode.mode} mode by analyzing its processing pipeline and identifying bottlenecks.`,
      priority: slowestMode.avgResponseTime > 3000 ? 'high' : 'medium',
      dataPoints: [
        `${fastestMode.mode}: ${fastestMode.avgResponseTime.toFixed(0)}ms avg`,
        `${slowestMode.mode}: ${slowestMode.avgResponseTime.toFixed(0)}ms avg`,
      ],
    });

    // Insight 3: Success rates
    const lowSuccessMode = modeStats.find(m => m.successRate < 70);
    if (lowSuccessMode) {
      insights.push({
        title: 'Low Success Rate Alert',
        description: `${lowSuccessMode.mode} mode has a success rate of only ${lowSuccessMode.successRate.toFixed(1)}%, indicating potential issues with result quality or relevance.`,
        recommendation: `Review the search algorithm and Qdrant indexing for ${lowSuccessMode.mode} mode. Consider improving query preprocessing or result ranking.`,
        priority: 'high',
        dataPoints: [
          `${lowSuccessMode.mode} success rate: ${lowSuccessMode.successRate.toFixed(1)}%`,
          `Queries with results: ${lowSuccessMode.count}`,
        ],
      });
    }

    // Insight 4: Confidence scores
    const lowConfidenceMode = modeStats.find(m => m.avgConfidence < 0.6);
    if (lowConfidenceMode) {
      insights.push({
        title: 'Low Confidence Scores',
        description: `${lowConfidenceMode.mode} mode produces answers with average confidence of only ${(lowConfidenceMode.avgConfidence * 100).toFixed(0)}%.`,
        recommendation: `Improve source quality and relevance scoring. Consider expanding the knowledge base or refining the semantic search parameters.`,
        priority: 'medium',
        dataPoints: [
          `${lowConfidenceMode.mode} avg confidence: ${(lowConfidenceMode.avgConfidence * 100).toFixed(0)}%`,
        ],
      });
    }

    return insights;
  } catch (error) {
    console.error('Failed to generate insights:', error);
    return [];
  }
}

/**
 * Generate recommendations using ИМИГО mode
 */
export async function generateRecommendations(
  analyticsData: QueryAnalytics[]
): Promise<string[]> {
  if (analyticsData.length < 10) {
    return ['Collect more analytics data (minimum 10 queries) to generate meaningful recommendations.'];
  }

  try {
    const modeStats = getModeStatistics(analyticsData);
    const insights = await generateAnalyticsInsights(analyticsData);

    const statsText = modeStats
      .map(
        m =>
          `${m.mode}: ${m.count} queries (${m.percentage.toFixed(1)}%), avg response ${m.avgResponseTime.toFixed(0)}ms, success rate ${m.successRate.toFixed(1)}%`
      )
      .join('\n');

    const insightsText = insights
      .map(i => `${i.title}: ${i.description}`)
      .join('\n\n');

    const response = await invokeLLM({
      messages: [
        {
          role: 'system',
          content:
            'Вы - эксперт по оптимизации систем поиска. На основе аналитики, предложите 3-5 конкретных, практических рекомендаций для улучшения сервиса.',
        },
        {
          role: 'user',
          content: `Аналитика использования системы:

${statsText}

Выявленные инсайты:
${insightsText}

Пожалуйста, предложите конкретные рекомендации для улучшения сервиса. Каждая рекомендация должна быть:
1. Практичной и реализуемой
2. Основана на данных аналитики
3. Направлена на улучшение пользовательского опыта или производительности`,
        },
      ],
    });

    const recommendations = typeof response.choices[0].message.content === 'string'
      ? response.choices[0].message.content
          .split('\n')
          .filter(line => line.trim().length > 0)
          .slice(0, 5)
      : [];

    return recommendations;
  } catch (error) {
    console.error('Failed to generate recommendations:', error);
    return [];
  }
}

/**
 * Get trending queries
 */
export function getTrendingQueries(analyticsData: QueryAnalytics[], limit: number = 10): string[] {
  const queryMap = new Map<string, number>();

  for (const analytics of analyticsData) {
    const count = queryMap.get(analytics.query) || 0;
    queryMap.set(analytics.query, count + 1);
  }

  return Array.from(queryMap.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([query]) => query);
}

/**
 * Get mode effectiveness score
 */
export function getModeEffectivenessScore(stats: ModeStatistics): number {
  // Score based on success rate (40%), confidence (40%), and response time (20%)
  const successScore = (stats.successRate / 100) * 0.4;
  const confidenceScore = stats.avgConfidence * 0.4;
  const responseScore = Math.max(0, 1 - stats.avgResponseTime / 5000) * 0.2;

  return (successScore + confidenceScore + responseScore) * 100;
}

/**
 * Compare mode effectiveness
 */
export function compareModesEffectiveness(stats: ModeStatistics[]): Map<string, number> {
  const scores = new Map<string, number>();

  for (const stat of stats) {
    scores.set(stat.mode, getModeEffectivenessScore(stat));
  }

  return scores;
}
