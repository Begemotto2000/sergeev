/**
 * Rate Limit Monitoring & Alerting
 * Monitors rate limit violations and sends alerts
 */

import { getCacheKey, getCounter, setCounter, pushToList, getList } from './redis';
import { sendSystemAlert } from './notifications';

export interface RateLimitAlert {
  id: string;
  userId: number;
  timestamp: number;
  severity: 'info' | 'warning' | 'critical';
  message: string;
  endpoint: string;
  limitPercentage: number;
}

export interface RateLimitThresholds {
  warningThreshold: number; // 80%
  criticalThreshold: number; // 95%
  violationThreshold: number; // 100%
}

const DEFAULT_THRESHOLDS: RateLimitThresholds = {
  warningThreshold: 80,
  criticalThreshold: 95,
  violationThreshold: 100,
};

/**
 * Check if rate limit alert should be triggered
 */
export function shouldTriggerAlert(
  current: number,
  limit: number,
  thresholds: Partial<RateLimitThresholds> = {}
): { shouldAlert: boolean; severity: 'info' | 'warning' | 'critical' | null } {
  const finalThresholds = { ...DEFAULT_THRESHOLDS, ...thresholds };
  const percentage = (current / limit) * 100;

  if (percentage >= finalThresholds.violationThreshold) {
    return { shouldAlert: true, severity: 'critical' };
  }

  if (percentage >= finalThresholds.criticalThreshold) {
    return { shouldAlert: true, severity: 'critical' };
  }

  if (percentage >= finalThresholds.warningThreshold) {
    return { shouldAlert: true, severity: 'warning' };
  }

  return { shouldAlert: false, severity: null };
}

/**
 * Record rate limit alert
 */
export async function recordAlert(alert: Omit<RateLimitAlert, 'id'>): Promise<string> {
  try {
    const alertId = `alert_${Date.now()}_${Math.random().toString(36).substring(7)}`;
    const fullAlert: RateLimitAlert = {
      ...alert,
      id: alertId,
    };

    const key = getCacheKey('ratelimit:alerts', alert.userId.toString());
    await pushToList(key, [fullAlert], 1000);

    return alertId;
  } catch (error) {
    console.error('Failed to record alert:', error);
    return '';
  }
}

/**
 * Get recent alerts for user
 */
export async function getUserAlerts(userId: number, limit: number = 50): Promise<RateLimitAlert[]> {
  try {
    const key = getCacheKey('ratelimit:alerts', userId.toString());
    const alerts = await getList<RateLimitAlert>(key, -limit, -1);
    return alerts.reverse();
  } catch (error) {
    console.error('Failed to get user alerts:', error);
    return [];
  }
}

/**
 * Get critical alerts
 */
export async function getCriticalAlerts(): Promise<RateLimitAlert[]> {
  try {
    // In a real implementation, would query all users' alerts
    // For now, return empty array
    return [];
  } catch (error) {
    console.error('Failed to get critical alerts:', error);
    return [];
  }
}

/**
 * Track rate limit violations
 */
export async function trackViolation(userId: number, endpoint: string): Promise<void> {
  try {
    const key = getCacheKey('ratelimit:violations', userId.toString());
    const countKey = getCacheKey('ratelimit:violation_count', userId.toString());

    const violation = {
      timestamp: Date.now(),
      endpoint,
    };

    await pushToList(key, [violation], 1000);
    await incrementViolationCounter(userId);
  } catch (error) {
    console.error('Failed to track violation:', error);
  }
}

/**
 * Increment violation counter
 */
export async function incrementViolationCounter(userId: number): Promise<number> {
  try {
    const key = getCacheKey('ratelimit:violation_count', userId.toString());
    const count = await getCounter(key);
    await setCounter(key, count + 1, 86400); // Reset after 24 hours
    return count + 1;
  } catch (error) {
    console.error('Failed to increment violation counter:', error);
    return 0;
  }
}

/**
 * Get violation count
 */
export async function getViolationCount(userId: number): Promise<number> {
  try {
    const key = getCacheKey('ratelimit:violation_count', userId.toString());
    return await getCounter(key);
  } catch (error) {
    console.error('Failed to get violation count:', error);
    return 0;
  }
}

/**
 * Get violation history
 */
export async function getViolationHistory(userId: number, hours: number = 24): Promise<any[]> {
  try {
    const key = getCacheKey('ratelimit:violations', userId.toString());
    const violations = await getList<any>(key, 0, -1);

    const cutoffTime = Date.now() - hours * 60 * 60 * 1000;
    return violations.filter((v) => v.timestamp >= cutoffTime);
  } catch (error) {
    console.error('Failed to get violation history:', error);
    return [];
  }
}

/**
 * Check if user should be temporarily blocked
 */
export async function shouldBlockUser(userId: number): Promise<boolean> {
  try {
    const violationCount = await getViolationCount(userId);
    const threshold = 10; // Block after 10 violations in 24 hours

    return violationCount >= threshold;
  } catch (error) {
    console.error('Failed to check if user should be blocked:', error);
    return false;
  }
}

/**
 * Get rate limit status for monitoring dashboard
 */
export async function getMonitoringStatus(): Promise<{
  totalAlerts: number;
  criticalAlerts: number;
  warningAlerts: number;
  totalViolations: number;
  blockedUsers: number;
  topViolators: Array<{ userId: number; violationCount: number }>;
}> {
  try {
    // In a real implementation, would aggregate data from Redis
    return {
      totalAlerts: 0,
      criticalAlerts: 0,
      warningAlerts: 0,
      totalViolations: 0,
      blockedUsers: 0,
      topViolators: [],
    };
  } catch (error) {
    console.error('Failed to get monitoring status:', error);
    return {
      totalAlerts: 0,
      criticalAlerts: 0,
      warningAlerts: 0,
      totalViolations: 0,
      blockedUsers: 0,
      topViolators: [],
    };
  }
}

/**
 * Generate alert message
 */
export function generateAlertMessage(
  endpoint: string,
  limitPercentage: number,
  severity: 'warning' | 'critical'
): string {
  if (severity === 'critical') {
    return `CRITICAL: Rate limit at ${limitPercentage.toFixed(1)}% for ${endpoint}. Requests will be blocked.`;
  }

  return `WARNING: Rate limit at ${limitPercentage.toFixed(1)}% for ${endpoint}. Approaching limit.`;
}

/**
 * Clear old alerts
 */
export async function clearOldAlerts(olderThanHours: number = 24): Promise<void> {
  try {
    const cutoffTime = Date.now() - olderThanHours * 60 * 60 * 1000;
    // In a real implementation, would delete old alerts from Redis
    console.log(`Clearing alerts older than ${olderThanHours} hours (before ${new Date(cutoffTime).toISOString()})`);
  } catch (error) {
    console.error('Failed to clear old alerts:', error);
  }
}

/**
 * Get alert statistics
 */
export async function getAlertStatistics(): Promise<{
  alertsPerHour: number;
  averageSeverity: string;
  mostCommonEndpoint: string;
  uniqueUsers: number;
}> {
  try {
    return {
      alertsPerHour: 0,
      averageSeverity: 'info',
      mostCommonEndpoint: 'unknown',
      uniqueUsers: 0,
    };
  } catch (error) {
    console.error('Failed to get alert statistics:', error);
    return {
      alertsPerHour: 0,
      averageSeverity: 'info',
      mostCommonEndpoint: 'unknown',
      uniqueUsers: 0,
    };
  }
}

/**
 * Send rate limit alert notification
 */
export async function sendRateLimitAlert(
  io: any,
  userId: number,
  message: string,
  severity: 'warning' | 'critical'
): Promise<void> {
  try {
    await sendSystemAlert(io, userId, message, severity === 'critical' ? 'error' : 'warning');
  } catch (error) {
    console.error('Failed to send rate limit alert:', error);
  }
}
