/**
 * i18n Tests
 */

import { describe, it, expect } from 'vitest';
import {
  t,
  getLLMPrompt,
  getTranslations,
  getSupportedLanguages,
  detectLanguage,
  formatDate,
  formatNumber,
  formatCurrency,
} from './i18n';

describe('i18n (Internationalization)', () => {
  describe('Translation Retrieval', () => {
    it('should get English translation', () => {
      const text = t('en', 'common.welcome');
      expect(text).toBe('Welcome to Sergeev Digitization System');
    });

    it('should get Russian translation', () => {
      const text = t('ru', 'common.welcome');
      expect(text).toContain('Сергеева');
    });

    it('should get Spanish translation', () => {
      const text = t('es', 'common.welcome');
      expect(text).toContain('Sergeev');
    });

    it('should get French translation', () => {
      const text = t('fr', 'common.welcome');
      expect(text).toContain('Sergeev');
    });

    it('should get German translation', () => {
      const text = t('de', 'common.welcome');
      expect(text).toContain('Sergeev');
    });

    it('should get Chinese translation', () => {
      const text = t('zh', 'common.welcome');
      expect(text).toContain('谢尔盖耶夫');
    });

    it('should return key if translation not found', () => {
      const text = t('en', 'nonexistent.key');
      expect(text).toBe('nonexistent.key');
    });

    it('should use default value if provided', () => {
      const text = t('en', 'nonexistent.key', 'Default Value');
      expect(text).toBe('Default Value');
    });
  });

  describe('LLM Prompt Translations', () => {
    it('should get English LLM prompt', () => {
      const prompt = getLLMPrompt('en', 'summarize');
      expect(prompt).toContain('Summarize');
    });

    it('should get Russian LLM prompt', () => {
      const prompt = getLLMPrompt('ru', 'summarize');
      expect(prompt).toContain('Подведите');
    });

    it('should get Spanish LLM prompt', () => {
      const prompt = getLLMPrompt('es', 'analyze');
      expect(prompt).toContain('Analice');
    });

    it('should get French LLM prompt', () => {
      const prompt = getLLMPrompt('fr', 'extract');
      expect(prompt).toContain('Extrayez');
    });

    it('should get German LLM prompt', () => {
      const prompt = getLLMPrompt('de', 'answer');
      expect(prompt).toContain('Beantworten');
    });

    it('should get Chinese LLM prompt', () => {
      const prompt = getLLMPrompt('zh', 'summarize');
      expect(prompt).toContain('总结');
    });
  });

  describe('Language Detection', () => {
    it('should detect English', () => {
      const lang = detectLanguage('en');
      expect(lang).toBe('en');
    });

    it('should detect Russian', () => {
      const lang = detectLanguage('ru');
      expect(lang).toBe('ru');
    });

    it('should default to English for unsupported language', () => {
      const lang = detectLanguage('xx');
      expect(lang).toBe('en');
    });

    it('should default to English when no language provided', () => {
      const lang = detectLanguage();
      expect(lang).toBe('en');
    });
  });

  describe('Supported Languages', () => {
    it('should list all supported languages', () => {
      const languages = getSupportedLanguages();
      expect(languages).toContain('en');
      expect(languages).toContain('ru');
      expect(languages).toContain('es');
      expect(languages).toContain('fr');
      expect(languages).toContain('de');
      expect(languages).toContain('zh');
    });

    it('should have at least 6 languages', () => {
      const languages = getSupportedLanguages();
      expect(languages.length).toBeGreaterThanOrEqual(6);
    });
  });

  describe('Translation Collections', () => {
    it('should get all English translations', () => {
      const translations = getTranslations('en');
      expect(translations).toHaveProperty('common');
      expect(translations).toHaveProperty('search');
      expect(translations).toHaveProperty('transcription');
    });

    it('should get all Russian translations', () => {
      const translations = getTranslations('ru');
      expect(translations).toHaveProperty('common');
      expect(translations).toHaveProperty('dashboard');
      expect(translations).toHaveProperty('errors');
    });

    it('should have common sections in all languages', () => {
      const languages = getSupportedLanguages();
      languages.forEach((lang) => {
        const translations = getTranslations(lang);
        expect(translations).toHaveProperty('common');
        expect(translations).toHaveProperty('errors');
      });
    });
  });

  describe('Date Formatting', () => {
    it('should format date in English', () => {
      const date = new Date('2026-05-06');
      const formatted = formatDate(date, 'en');
      expect(formatted).toContain('May');
    });

    it('should format date in Russian', () => {
      const date = new Date('2026-05-06');
      const formatted = formatDate(date, 'ru');
      expect(formatted).toBeTruthy();
    });

    it('should format date in Spanish', () => {
      const date = new Date('2026-05-06');
      const formatted = formatDate(date, 'es');
      expect(formatted).toBeTruthy();
    });

    it('should format date in Chinese', () => {
      const date = new Date('2026-05-06');
      const formatted = formatDate(date, 'zh');
      expect(formatted).toBeTruthy();
    });
  });

  describe('Number Formatting', () => {
    it('should format number in English', () => {
      const formatted = formatNumber(1234567, 'en');
      expect(formatted).toContain('1');
    });

    it('should format number in Russian', () => {
      const formatted = formatNumber(1234567, 'ru');
      expect(formatted).toBeTruthy();
    });

    it('should format number in German', () => {
      const formatted = formatNumber(1234567, 'de');
      expect(formatted).toBeTruthy();
    });

    it('should format number in Chinese', () => {
      const formatted = formatNumber(1234567, 'zh');
      expect(formatted).toBeTruthy();
    });
  });

  describe('Currency Formatting', () => {
    it('should format USD in English', () => {
      const formatted = formatCurrency(100, 'en', 'USD');
      expect(formatted).toContain('100');
    });

    it('should format EUR in French', () => {
      const formatted = formatCurrency(100, 'fr', 'EUR');
      expect(formatted).toBeTruthy();
    });

    it('should format RUB in Russian', () => {
      const formatted = formatCurrency(100, 'ru', 'RUB');
      expect(formatted).toBeTruthy();
    });

    it('should format CNY in Chinese', () => {
      const formatted = formatCurrency(100, 'zh', 'CNY');
      expect(formatted).toBeTruthy();
    });
  });

  describe('Error Messages', () => {
    it('should get English error messages', () => {
      const unauthorized = t('en', 'errors.unauthorized');
      expect(unauthorized).toBe('Unauthorized');
    });

    it('should get Russian error messages', () => {
      const forbidden = t('ru', 'errors.forbidden');
      expect(forbidden).toContain('Доступ');
    });

    it('should get Spanish error messages', () => {
      const notFound = t('es', 'errors.notFound');
      expect(notFound).toContain('No encontrado');
    });
  });

  describe('Search Translations', () => {
    it('should get search title in English', () => {
      const title = t('en', 'search.title');
      expect(title).toContain('Knowledge Base');
    });

    it('should get search title in Russian', () => {
      const title = t('ru', 'search.title');
      expect(title).toContain('базе');
    });

    it('should get search placeholder in multiple languages', () => {
      const enPlaceholder = t('en', 'search.placeholder');
      const ruPlaceholder = t('ru', 'search.placeholder');
      const esPlaceholder = t('es', 'search.placeholder');

      expect(enPlaceholder).toBeTruthy();
      expect(ruPlaceholder).toBeTruthy();
      expect(esPlaceholder).toBeTruthy();
    });
  });

  describe('Transcription Translations', () => {
    it('should get transcription messages in English', () => {
      const success = t('en', 'transcription.success');
      expect(success).toContain('successfully');
    });

    it('should get transcription messages in Russian', () => {
      const error = t('ru', 'transcription.error');
      expect(error).toContain('Ошибка');
    });

    it('should get supported formats in multiple languages', () => {
      const enFormats = t('en', 'transcription.formats');
      const ruFormats = t('ru', 'transcription.formats');

      expect(enFormats).toContain('PDF');
      expect(ruFormats).toContain('PDF');
    });
  });
});
