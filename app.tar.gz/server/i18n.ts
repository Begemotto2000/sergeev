/**
 * i18n (Internationalization) Module
 * Manages translations for UI and LLM prompts
 */

export type Language = 'en' | 'ru' | 'es' | 'fr' | 'de' | 'zh';

export interface TranslationConfig {
  language: Language;
  fallback: Language;
  supportedLanguages: Language[];
}

export interface TranslationStrings {
  [key: string]: string | TranslationStrings;
}

// Translation dictionaries
const translations: Record<Language, TranslationStrings> = {
  en: {
    common: {
      welcome: 'Welcome to Sergeev Digitization System',
      loading: 'Loading...',
      error: 'An error occurred',
      success: 'Success',
      cancel: 'Cancel',
      save: 'Save',
      delete: 'Delete',
      edit: 'Edit',
      search: 'Search',
    },
    search: {
      title: 'Search Knowledge Base',
      placeholder: 'Enter your query...',
      noResults: 'No results found',
      searching: 'Searching...',
      results: 'Results',
    },
    transcription: {
      title: 'Upload Transcription',
      upload: 'Upload File',
      uploading: 'Uploading...',
      success: 'Transcription uploaded successfully',
      error: 'Failed to upload transcription',
      formats: 'Supported formats: PDF, DOCX, TXT, JSON, SRT',
    },
    dashboard: {
      title: 'Dashboard',
      analytics: 'Analytics',
      performance: 'Performance',
      cache: 'Cache',
      queries: 'Queries',
    },
    rateLimit: {
      limited: 'Rate limit exceeded. Please try again later.',
      warning: 'Approaching rate limit',
      critical: 'Rate limit critical',
    },
    errors: {
      unauthorized: 'Unauthorized',
      forbidden: 'Forbidden',
      notFound: 'Not found',
      serverError: 'Server error',
      networkError: 'Network error',
    },
  },
  ru: {
    common: {
      welcome: 'Добро пожаловать в Систему оцифровки Сергеева',
      loading: 'Загрузка...',
      error: 'Произошла ошибка',
      success: 'Успешно',
      cancel: 'Отмена',
      save: 'Сохранить',
      delete: 'Удалить',
      edit: 'Редактировать',
      search: 'Поиск',
    },
    search: {
      title: 'Поиск в базе знаний',
      placeholder: 'Введите ваш запрос...',
      noResults: 'Результаты не найдены',
      searching: 'Поиск...',
      results: 'Результаты',
    },
    transcription: {
      title: 'Загрузка транскрипции',
      upload: 'Загрузить файл',
      uploading: 'Загрузка...',
      success: 'Транскрипция успешно загружена',
      error: 'Ошибка при загрузке транскрипции',
      formats: 'Поддерживаемые форматы: PDF, DOCX, TXT, JSON, SRT',
    },
    dashboard: {
      title: 'Панель управления',
      analytics: 'Аналитика',
      performance: 'Производительность',
      cache: 'Кеш',
      queries: 'Запросы',
    },
    rateLimit: {
      limited: 'Лимит запросов превышен. Попробуйте позже.',
      warning: 'Приближение к лимиту запросов',
      critical: 'Критический лимит запросов',
    },
    errors: {
      unauthorized: 'Не авторизован',
      forbidden: 'Доступ запрещен',
      notFound: 'Не найдено',
      serverError: 'Ошибка сервера',
      networkError: 'Ошибка сети',
    },
  },
  es: {
    common: {
      welcome: 'Bienvenido al Sistema de Digitalización de Sergeev',
      loading: 'Cargando...',
      error: 'Ocurrió un error',
      success: 'Éxito',
      cancel: 'Cancelar',
      save: 'Guardar',
      delete: 'Eliminar',
      edit: 'Editar',
      search: 'Buscar',
    },
    search: {
      title: 'Buscar en la Base de Conocimientos',
      placeholder: 'Ingrese su consulta...',
      noResults: 'No se encontraron resultados',
      searching: 'Buscando...',
      results: 'Resultados',
    },
    transcription: {
      title: 'Cargar Transcripción',
      upload: 'Cargar Archivo',
      uploading: 'Cargando...',
      success: 'Transcripción cargada exitosamente',
      error: 'Error al cargar la transcripción',
      formats: 'Formatos soportados: PDF, DOCX, TXT, JSON, SRT',
    },
    dashboard: {
      title: 'Panel de Control',
      analytics: 'Analítica',
      performance: 'Rendimiento',
      cache: 'Caché',
      queries: 'Consultas',
    },
    rateLimit: {
      limited: 'Límite de velocidad excedido. Intente más tarde.',
      warning: 'Acercándose al límite de velocidad',
      critical: 'Límite de velocidad crítico',
    },
    errors: {
      unauthorized: 'No autorizado',
      forbidden: 'Prohibido',
      notFound: 'No encontrado',
      serverError: 'Error del servidor',
      networkError: 'Error de red',
    },
  },
  fr: {
    common: {
      welcome: 'Bienvenue dans le Système de Numérisation de Sergeev',
      loading: 'Chargement...',
      error: 'Une erreur est survenue',
      success: 'Succès',
      cancel: 'Annuler',
      save: 'Enregistrer',
      delete: 'Supprimer',
      edit: 'Modifier',
      search: 'Rechercher',
    },
    search: {
      title: 'Rechercher dans la Base de Connaissances',
      placeholder: 'Entrez votre requête...',
      noResults: 'Aucun résultat trouvé',
      searching: 'Recherche en cours...',
      results: 'Résultats',
    },
    transcription: {
      title: 'Télécharger la Transcription',
      upload: 'Télécharger le Fichier',
      uploading: 'Téléchargement...',
      success: 'Transcription téléchargée avec succès',
      error: 'Erreur lors du téléchargement de la transcription',
      formats: 'Formats supportés: PDF, DOCX, TXT, JSON, SRT',
    },
    dashboard: {
      title: 'Tableau de Bord',
      analytics: 'Analytique',
      performance: 'Performance',
      cache: 'Cache',
      queries: 'Requêtes',
    },
    rateLimit: {
      limited: 'Limite de débit dépassée. Réessayez plus tard.',
      warning: 'Approche de la limite de débit',
      critical: 'Limite de débit critique',
    },
    errors: {
      unauthorized: 'Non autorisé',
      forbidden: 'Interdit',
      notFound: 'Non trouvé',
      serverError: 'Erreur du serveur',
      networkError: 'Erreur réseau',
    },
  },
  de: {
    common: {
      welcome: 'Willkommen im Sergeev-Digitalisierungssystem',
      loading: 'Wird geladen...',
      error: 'Ein Fehler ist aufgetreten',
      success: 'Erfolg',
      cancel: 'Abbrechen',
      save: 'Speichern',
      delete: 'Löschen',
      edit: 'Bearbeiten',
      search: 'Suchen',
    },
    search: {
      title: 'Wissensdatenbank durchsuchen',
      placeholder: 'Geben Sie Ihre Abfrage ein...',
      noResults: 'Keine Ergebnisse gefunden',
      searching: 'Suche läuft...',
      results: 'Ergebnisse',
    },
    transcription: {
      title: 'Transkription hochladen',
      upload: 'Datei hochladen',
      uploading: 'Wird hochgeladen...',
      success: 'Transkription erfolgreich hochgeladen',
      error: 'Fehler beim Hochladen der Transkription',
      formats: 'Unterstützte Formate: PDF, DOCX, TXT, JSON, SRT',
    },
    dashboard: {
      title: 'Dashboard',
      analytics: 'Analytik',
      performance: 'Leistung',
      cache: 'Cache',
      queries: 'Abfragen',
    },
    rateLimit: {
      limited: 'Ratenlimit überschritten. Versuchen Sie es später.',
      warning: 'Ratenlimit wird erreicht',
      critical: 'Kritisches Ratenlimit',
    },
    errors: {
      unauthorized: 'Nicht autorisiert',
      forbidden: 'Verboten',
      notFound: 'Nicht gefunden',
      serverError: 'Serverfehler',
      networkError: 'Netzwerkfehler',
    },
  },
  zh: {
    common: {
      welcome: '欢迎来到谢尔盖耶夫数字化系统',
      loading: '加载中...',
      error: '发生错误',
      success: '成功',
      cancel: '取消',
      save: '保存',
      delete: '删除',
      edit: '编辑',
      search: '搜索',
    },
    search: {
      title: '搜索知识库',
      placeholder: '输入您的查询...',
      noResults: '未找到结果',
      searching: '搜索中...',
      results: '结果',
    },
    transcription: {
      title: '上传转录',
      upload: '上传文件',
      uploading: '上传中...',
      success: '转录上传成功',
      error: '转录上传失败',
      formats: '支持的格式: PDF, DOCX, TXT, JSON, SRT',
    },
    dashboard: {
      title: '仪表板',
      analytics: '分析',
      performance: '性能',
      cache: '缓存',
      queries: '查询',
    },
    rateLimit: {
      limited: '超过速率限制。请稍后重试。',
      warning: '接近速率限制',
      critical: '严重速率限制',
    },
    errors: {
      unauthorized: '未授权',
      forbidden: '禁止',
      notFound: '未找到',
      serverError: '服务器错误',
      networkError: '网络错误',
    },
  },
};

// LLM Prompt translations
const llmPrompts: Record<Language, Record<string, string>> = {
  en: {
    summarize: 'Summarize the following text in English:',
    analyze: 'Analyze the following text in English:',
    extract: 'Extract key points from the following text in English:',
    answer: 'Answer the following question based on the provided context in English:',
  },
  ru: {
    summarize: 'Подведите итоги следующего текста на русском языке:',
    analyze: 'Проанализируйте следующий текст на русском языке:',
    extract: 'Извлеките ключевые моменты из следующего текста на русском языке:',
    answer: 'Ответьте на следующий вопрос на основе предоставленного контекста на русском языке:',
  },
  es: {
    summarize: 'Resuma el siguiente texto en español:',
    analyze: 'Analice el siguiente texto en español:',
    extract: 'Extraiga puntos clave del siguiente texto en español:',
    answer: 'Responda la siguiente pregunta basada en el contexto proporcionado en español:',
  },
  fr: {
    summarize: 'Résumez le texte suivant en français:',
    analyze: 'Analysez le texte suivant en français:',
    extract: 'Extrayez les points clés du texte suivant en français:',
    answer: 'Répondez à la question suivante en fonction du contexte fourni en français:',
  },
  de: {
    summarize: 'Fassen Sie den folgenden Text auf Deutsch zusammen:',
    analyze: 'Analysieren Sie den folgenden Text auf Deutsch:',
    extract: 'Extrahieren Sie Schlüsselpunkte aus dem folgenden Text auf Deutsch:',
    answer: 'Beantworten Sie die folgende Frage basierend auf dem bereitgestellten Kontext auf Deutsch:',
  },
  zh: {
    summarize: '用中文总结以下文本:',
    analyze: '用中文分析以下文本:',
    extract: '从以下文本中用中文提取要点:',
    answer: '根据提供的上下文用中文回答以下问题:',
  },
};

/**
 * Get translation string
 */
export function t(language: Language, key: string, defaultValue?: string): string {
  const keys = key.split('.');
  let current: any = translations[language];

  for (const k of keys) {
    current = current?.[k];
  }

  return current || defaultValue || key;
}

/**
 * Get LLM prompt translation
 */
export function getLLMPrompt(language: Language, promptKey: string): string {
  return llmPrompts[language]?.[promptKey] || llmPrompts.en[promptKey] || '';
}

/**
 * Get all translations for language
 */
export function getTranslations(language: Language): TranslationStrings {
  return translations[language] || translations.en;
}

/**
 * Get supported languages
 */
export function getSupportedLanguages(): Language[] {
  return Object.keys(translations) as Language[];
}

/**
 * Detect language from user preference or browser
 */
export function detectLanguage(userLanguage?: string): Language {
  const supported = getSupportedLanguages();

  if (userLanguage && supported.includes(userLanguage as Language)) {
    return userLanguage as Language;
  }

  // Default to English
  return 'en';
}

/**
 * Format date for language
 */
export function formatDate(date: Date, language: Language): string {
  const options: Intl.DateTimeFormatOptions = {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  };

  return new Intl.DateTimeFormat(language === 'zh' ? 'zh-CN' : language, options).format(date);
}

/**
 * Format number for language
 */
export function formatNumber(num: number, language: Language): string {
  return new Intl.NumberFormat(language === 'zh' ? 'zh-CN' : language).format(num);
}

/**
 * Format currency for language
 */
export function formatCurrency(amount: number, language: Language, currency: string = 'USD'): string {
  return new Intl.NumberFormat(language === 'zh' ? 'zh-CN' : language, {
    style: 'currency',
    currency,
  }).format(amount);
}
