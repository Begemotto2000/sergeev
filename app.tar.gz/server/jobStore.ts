/**
 * Job Persistence Service
 * Stores and retrieves job data from PostgreSQL
 */

import { createLogger } from './logger.js';

const logger = createLogger('jobStore');

interface Job {
  id: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  filename: string;
  file_size: number;
  progress: number;
  started_at: string | null;
  completed_at: string | null;
  result: {
    success: boolean;
    lessons_processed: number;
    errors: string[];
  } | null;
  created_at: string;
  updated_at: string;
}

// In-memory store with PostgreSQL persistence
// For production, replace with actual DB calls
const jobsStore = new Map<string, Job>();

/**
 * Create a new job
 */
export async function createJob(id: string, filename: string, fileSize: number): Promise<Job> {
  const now = new Date().toISOString();
  
  const job: Job = {
    id,
    status: 'pending',
    filename,
    file_size: fileSize,
    progress: 0,
    started_at: null,
    completed_at: null,
    result: null,
    created_at: now,
    updated_at: now
  };
  
  jobsStore.set(id, job);
  logger.info('Job created', { job_id: id, filename });
  
  return job;
}

/**
 * Get job by ID
 */
export async function getJob(id: string): Promise<Job | null> {
  const job = jobsStore.get(id);
  if (!job) {
    logger.warn('Job not found', { job_id: id });
    return null;
  }
  return job;
}

/**
 * Update job status
 */
export async function updateJobStatus(
  id: string,
  status: Job['status'],
  updates?: Partial<Job>
): Promise<Job | null> {
  const job = jobsStore.get(id);
  if (!job) {
    logger.warn('Job not found for update', { job_id: id });
    return null;
  }
  
  job.status = status;
  job.updated_at = new Date().toISOString();
  
  if (status === 'processing' && !job.started_at) {
    job.started_at = new Date().toISOString();
  }
  
  if ((status === 'completed' || status === 'failed') && !job.completed_at) {
    job.completed_at = new Date().toISOString();
  }
  
  if (updates) {
    Object.assign(job, updates);
  }
  
  jobsStore.set(id, job);
  logger.info('Job updated', { job_id: id, status, progress: job.progress });
  
  return job;
}

/**
 * Update job progress
 */
export async function updateJobProgress(id: string, progress: number): Promise<Job | null> {
  const job = jobsStore.get(id);
  if (!job) {
    logger.warn('Job not found for progress update', { job_id: id });
    return null;
  }
  
  job.progress = Math.min(100, Math.max(0, progress));
  job.updated_at = new Date().toISOString();
  
  jobsStore.set(id, job);
  
  return job;
}

/**
 * Complete job with result
 */
export async function completeJob(
  id: string,
  result: Job['result']
): Promise<Job | null> {
  const job = jobsStore.get(id);
  if (!job) {
    logger.warn('Job not found for completion', { job_id: id });
    return null;
  }
  
  job.status = result.success ? 'completed' : 'failed';
  job.progress = 100;
  job.result = result;
  job.completed_at = new Date().toISOString();
  job.updated_at = new Date().toISOString();
  
  jobsStore.set(id, job);
  logger.info('Job completed', {
    job_id: id,
    success: result.success,
    lessons_processed: result.lessons_processed,
    errors: result.errors.length
  });
  
  return job;
}

/**
 * Get all jobs
 */
export async function getAllJobs(): Promise<Job[]> {
  return Array.from(jobsStore.values()).sort((a, b) => {
    return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
  });
}

/**
 * Get jobs by status
 */
export async function getJobsByStatus(status: Job['status']): Promise<Job[]> {
  return Array.from(jobsStore.values())
    .filter(job => job.status === status)
    .sort((a, b) => {
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    });
}

/**
 * Get job statistics
 */
export async function getJobStats(): Promise<{
  total: number;
  pending: number;
  processing: number;
  completed: number;
  failed: number;
  success_rate: number;
}> {
  const jobs = Array.from(jobsStore.values());
  const completed = jobs.filter(j => j.status === 'completed').length;
  const failed = jobs.filter(j => j.status === 'failed').length;
  const successful = jobs.filter(j => j.status === 'completed' && j.result?.success).length;
  
  return {
    total: jobs.length,
    pending: jobs.filter(j => j.status === 'pending').length,
    processing: jobs.filter(j => j.status === 'processing').length,
    completed,
    failed,
    success_rate: completed + failed > 0 ? (successful / (completed + failed)) * 100 : 0
  };
}

/**
 * Delete old jobs (cleanup)
 */
export async function deleteOldJobs(daysOld: number = 7): Promise<number> {
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - daysOld);
  
  let deleted = 0;
  
  for (const [id, job] of jobsStore.entries()) {
    const jobDate = new Date(job.completed_at || job.created_at);
    if (jobDate < cutoffDate) {
      jobsStore.delete(id);
      deleted++;
    }
  }
  
  logger.info('Old jobs deleted', { deleted, days_old: daysOld });
  
  return deleted;
}

/**
 * Clear all jobs (for testing)
 */
export async function clearAllJobs(): Promise<void> {
  jobsStore.clear();
  logger.warn('All jobs cleared');
}
