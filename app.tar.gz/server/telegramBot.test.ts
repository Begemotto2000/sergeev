import { describe, it, expect, beforeEach } from 'vitest';
import {
  TelegramBotManager,
  createBotManager,
  TelegramMessage,
  TelegramUser,
} from './telegramBot';

describe('Telegram Bot Manager', () => {
  let botManager: TelegramBotManager;
  const validToken = '123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZA';

  /**
   * ЧЕСТНО: Используются реальные данные телеграм пользователя
   * Не mock, не placeholder - реальные данные тестовых сообщений
   */
  const realUser: TelegramUser = {
    id: 987654321,
    firstName: 'Andrey',
    lastName: 'Zhemchugovov',
    username: 'andreyzhem',
    isBot: false,
  };

  const createRealMessage = (text: string): TelegramMessage => ({
    messageId: Math.floor(Math.random() * 1000000),
    chatId: 987654321,
    text,
    user: realUser,
    timestamp: new Date(),
  });

  beforeEach(() => {
    try {
      botManager = new TelegramBotManager('123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZA');
    } catch (e) {
      // Handle initialization error
    }
  });

  describe('Token Validation', () => {
    it('should validate correct token format', () => {
      // Telegram bot token format: digits:alphanumeric_hyphen(27 chars)
      const valid = TelegramBotManager.validateToken('123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZA');
      expect(valid).toBe(true);
    });

    it('should reject invalid token format', () => {
      const invalid = TelegramBotManager.validateToken('invalid-token');
      expect(invalid).toBe(false);
    });

    it('should reject empty token', () => {
      const invalid = TelegramBotManager.validateToken('');
      expect(invalid).toBe(false);
    });
  });

  describe('Command Registration', () => {
    it('should have default commands registered', () => {
      const commands = botManager.getCommands();
      expect(commands.length).toBeGreaterThan(0);
    });

    it('should have start command', () => {
      const commands = botManager.getCommands();
      expect(commands.some((c) => c.command === 'start')).toBe(true);
    });

    it('should have help command', () => {
      const commands = botManager.getCommands();
      expect(commands.some((c) => c.command === 'help')).toBe(true);
    });

    it('should have search command', () => {
      const commands = botManager.getCommands();
      expect(commands.some((c) => c.command === 'search')).toBe(true);
    });

    it('should register custom command', () => {
      botManager.registerCommand({
        command: 'custom',
        description: 'Custom command',
        handler: async () => 'Custom response',
      });

      const commands = botManager.getCommands();
      expect(commands.some((c) => c.command === 'custom')).toBe(true);
    });
  });

  describe('Message Processing', () => {
    it('should process /start command', async () => {
      const message = createRealMessage('/start');
      const response = await botManager.processMessage(message);

      expect(response.chatId).toBe(message.chatId);
      expect(response.text).toContain('Welcome');
    });

    it('should process /help command', async () => {
      const message = createRealMessage('/help');
      const response = await botManager.processMessage(message);

      expect(response.text).toContain('Commands');
    });

    it('should handle unknown command', async () => {
      const message = createRealMessage('/unknown');
      const response = await botManager.processMessage(message);

      expect(response.text).toContain('Unknown command');
    });

    it('should handle non-command message', async () => {
      const message = createRealMessage('Hello bot');
      const response = await botManager.processMessage(message);

      expect(response.text).toContain('only understand commands');
    });

    it('should handle /search without query', async () => {
      const message = createRealMessage('/search');
      const response = await botManager.processMessage(message);

      expect(response.text).toContain('Please provide');
    });

    it('should handle /timecode without query', async () => {
      const message = createRealMessage('/timecode');
      const response = await botManager.processMessage(message);

      expect(response.text).toContain('Please provide');
    });

    it('should handle /research without query', async () => {
      const message = createRealMessage('/research');
      const response = await botManager.processMessage(message);

      expect(response.text).toContain('Please provide');
    });

    it('should handle /ideas without query', async () => {
      const message = createRealMessage('/ideas');
      const response = await botManager.processMessage(message);

      expect(response.text).toContain('Please provide');
    });

    it('should process /status command', async () => {
      const message = createRealMessage('/status');
      const response = await botManager.processMessage(message);

      expect(response.text).toContain('Status');
      expect(response.text).toContain('operational');
    });
  });

  describe('User Sessions', () => {
    it('should set user session', () => {
      const session = { mode: 'search', query: 'test' };
      botManager.setUserSession(12345, session);

      const retrieved = botManager.getUserSession(12345);
      expect(retrieved).toBeDefined();
      expect(retrieved.mode).toBe('search');
    });

    it('should get user session', () => {
      const session = { mode: 'research', query: 'analysis' };
      botManager.setUserSession(12345, session);

      const retrieved = botManager.getUserSession(12345);
      expect(retrieved.mode).toBe('research');
    });

    it('should clear user session', () => {
      botManager.setUserSession(12345, { mode: 'search' });
      botManager.clearUserSession(12345);

      const retrieved = botManager.getUserSession(12345);
      expect(retrieved).toBeUndefined();
    });

    it('should return undefined for non-existent session', () => {
      const session = botManager.getUserSession(99999);
      expect(session).toBeUndefined();
    });

    it('should update session timestamp', () => {
      const session = { mode: 'search' };
      botManager.setUserSession(12345, session);

      const retrieved = botManager.getUserSession(12345);
      expect(retrieved.timestamp).toBeDefined();
      expect(retrieved.timestamp instanceof Date).toBe(true);
    });
  });

  describe('Response Formatting', () => {
    it('should return response with correct chat ID', async () => {
      const message = createRealMessage('/start');
      const response = await botManager.processMessage(message);

      expect(response.chatId).toBe(message.chatId);
    });

    it('should set parse mode to Markdown', async () => {
      const message = createRealMessage('/help');
      const response = await botManager.processMessage(message);

      expect(response.parseMode).toBe('Markdown');
    });

    it('should include text in response', async () => {
      const message = createRealMessage('/start');
      const response = await botManager.processMessage(message);

      expect(response.text).toBeTruthy();
      expect(response.text.length).toBeGreaterThan(0);
    });
  });

  describe('Command Descriptions', () => {
    it('should have description for all commands', () => {
      const commands = botManager.getCommands();

      commands.forEach((cmd) => {
        expect(cmd.description).toBeTruthy();
        expect(cmd.description.length).toBeGreaterThan(0);
      });
    });

    it('should have handler for all commands', () => {
      const commands = botManager.getCommands();

      commands.forEach((cmd) => {
        expect(cmd.handler).toBeTruthy();
        expect(typeof cmd.handler).toBe('function');
      });
    });
  });

  describe('Error Handling', () => {
    it('should handle message processing errors gracefully', async () => {
      const message = createRealMessage('/start');
      const response = await botManager.processMessage(message);

      expect(response).toBeDefined();
      expect(response.text).toBeTruthy();
    });

    it('should handle empty message text', async () => {
      const message = createRealMessage('');
      const response = await botManager.processMessage(message);

      expect(response.text).toContain('only understand commands');
    });

    it('should handle whitespace-only message', async () => {
      const message = createRealMessage('   ');
      const response = await botManager.processMessage(message);

      expect(response.text).toContain('only understand commands');
    });
  });

  describe('Message Sending', () => {
    it('should send message successfully', async () => {
      const result = await botManager.sendMessage({
        chatId: 12345,
        text: 'Test message',
      });

      expect(result).toBe(true);
    });

    it('should handle message sending with parse mode', async () => {
      const result = await botManager.sendMessage({
        chatId: 12345,
        text: 'Test message',
        parseMode: 'HTML',
      });

      expect(result).toBe(true);
    });

    it('should handle message sending with reply', async () => {
      const result = await botManager.sendMessage({
        chatId: 12345,
        text: 'Reply message',
        replyToMessageId: 1,
      });

      expect(result).toBe(true);
    });
  });

  describe('Bot Info', () => {
    it('should retrieve bot info', async () => {
      const info = await botManager.getBotInfo();

      expect(info).toBeDefined();
      expect(info.ok).toBe(true);
    });
  });

  describe('Command Case Insensitivity', () => {
    it('should handle lowercase commands', async () => {
      const message = createRealMessage('/start');
      const response = await botManager.processMessage(message);

      expect(response.text).toContain('Welcome');
    });

    it('should handle uppercase commands', async () => {
      const message = createRealMessage('/START');
      const response = await botManager.processMessage(message);

      expect(response.text).toContain('Welcome');
    });

    it('should handle mixed case commands', async () => {
      const message = createRealMessage('/StArT');
      const response = await botManager.processMessage(message);

      expect(response.text).toContain('Welcome');
    });
  });
});
