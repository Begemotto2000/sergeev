/**
 * Telegram Bot Integration Module
 * Handles bot commands, message processing, and knowledge base queries
 */

import { invokeLLM } from './_core/llm';

export interface TelegramUser {
  id: number;
  firstName: string;
  lastName?: string;
  username?: string;
  isBot: boolean;
}

export interface TelegramMessage {
  messageId: number;
  chatId: number;
  text: string;
  user: TelegramUser;
  timestamp: Date;
}

export interface BotCommand {
  command: string;
  description: string;
  handler: (message: TelegramMessage) => Promise<string>;
}

export interface BotResponse {
  chatId: number;
  text: string;
  parseMode?: 'HTML' | 'Markdown' | 'MarkdownV2';
  replyToMessageId?: number;
}

export class TelegramBotManager {
  private botToken: string;
  private apiUrl: string;
  private commands: Map<string, BotCommand>;
  private userSessions: Map<number, { mode: string; query: string; timestamp: Date }>;

  constructor(botToken: string) {
    this.botToken = botToken;
    this.apiUrl = `https://api.telegram.org/bot${botToken}`;
    this.commands = new Map();
    this.userSessions = new Map();

    this.registerDefaultCommands();
  }

  /**
   * Register default bot commands
   */
  private registerDefaultCommands(): void {
    this.commands.set('start', {
      command: 'start',
      description: 'Start the bot',
      handler: this.handleStart.bind(this),
    });

    this.commands.set('help', {
      command: 'help',
      description: 'Show help message',
      handler: this.handleHelp.bind(this),
    });

    this.commands.set('search', {
      command: 'search',
      description: 'Search knowledge base',
      handler: this.handleSearch.bind(this),
    });

    this.commands.set('timecode', {
      command: 'timecode',
      description: 'Find video timecode',
      handler: this.handleTimecode.bind(this),
    });

    this.commands.set('research', {
      command: 'research',
      description: 'Deep research query',
      handler: this.handleResearch.bind(this),
    });

    this.commands.set('ideas', {
      command: 'ideas',
      description: 'Generate ideas and insights',
      handler: this.handleIdeas.bind(this),
    });

    this.commands.set('status', {
      command: 'status',
      description: 'System status',
      handler: this.handleStatus.bind(this),
    });
  }

  /**
   * Handle /start command
   */
  private async handleStart(message: TelegramMessage): Promise<string> {
    return `👋 Welcome to Knowledge Base Bot!

I can help you search through video transcriptions and find information.

Available commands:
/search <query> - Search knowledge base
/timecode <query> - Find video timecode
/research <query> - Deep research
/ideas <query> - Generate ideas
/status - System status
/help - Show this message`;
  }

  /**
   * Handle /help command
   */
  private async handleHelp(message: TelegramMessage): Promise<string> {
    return `📚 Knowledge Base Bot Help

Commands:
/start - Start the bot
/search <query> - Search knowledge base (ОТВЕТ mode)
/timecode <query> - Find specific video and timecode (ТАЙМКОД mode)
/research <query> - Deep research with analysis (DEEP RESEARCH mode)
/ideas <query> - Generate ideas and insights (ИМИГО mode)
/status - Check system status
/help - Show this help message

Example queries:
/search What is mentorship?
/timecode When do they discuss leadership?
/research Analysis of development topics
/ideas Insights on personal growth`;
  }

  /**
   * Handle /search command (ОТВЕТ mode)
   */
  private async handleSearch(message: TelegramMessage): Promise<string> {
    const query = message.text.replace('/search', '').trim();

    if (!query) {
      return '❌ Please provide a search query.\nUsage: /search <query>';
    }

    try {
      // In production, would call actual tRPC procedure
      const response = await invokeLLM({
        messages: [
          {
            role: 'system',
            content:
              'You are a helpful assistant answering questions based on video transcriptions. Keep answers concise and relevant.',
          },
          {
            role: 'user',
            content: `Answer this question: ${query}`,
          },
        ],
      });

      const answer =
        typeof response.choices[0].message.content === 'string'
          ? response.choices[0].message.content
          : '';

      return `🔍 Search Results for: "${query}"\n\n${answer}\n\n📌 Source: Knowledge Base`;
    } catch (error) {
      return '❌ Search failed. Please try again later.';
    }
  }

  /**
   * Handle /timecode command (ТАЙМКОД mode)
   */
  private async handleTimecode(message: TelegramMessage): Promise<string> {
    const query = message.text.replace('/timecode', '').trim();

    if (!query) {
      return '❌ Please provide a search query.\nUsage: /timecode <query>';
    }

    // Mock response - in production would call tRPC procedure
    return `⏱️ Timecode Search: "${query}"\n\n📹 Video: Mentorship 101\n⏰ Timecode: 12:34 - 15:22\n\n"${query}" is discussed in this segment.\n\n🔗 Watch: [Video Link]`;
  }

  /**
   * Handle /research command (DEEP RESEARCH mode)
   */
  private async handleResearch(message: TelegramMessage): Promise<string> {
    const query = message.text.replace('/research', '').trim();

    if (!query) {
      return '❌ Please provide a research topic.\nUsage: /research <query>';
    }

    try {
      const response = await invokeLLM({
        messages: [
          {
            role: 'system',
            content:
              'You are a research analyst. Provide deep analysis, patterns, and insights on the given topic. Be comprehensive but concise.',
          },
          {
            role: 'user',
            content: `Provide deep research analysis on: ${query}`,
          },
        ],
      });

      const analysis =
        typeof response.choices[0].message.content === 'string'
          ? response.choices[0].message.content
          : '';

      return `🔬 Deep Research: "${query}"\n\n${analysis}\n\n📊 Analysis complete`;
    } catch (error) {
      return '❌ Research failed. Please try again later.';
    }
  }

  /**
   * Handle /ideas command (ИМИГО mode)
   */
  private async handleIdeas(message: TelegramMessage): Promise<string> {
    const query = message.text.replace('/ideas', '').trim();

    if (!query) {
      return '❌ Please provide a topic.\nUsage: /ideas <query>';
    }

    try {
      const response = await invokeLLM({
        messages: [
          {
            role: 'system',
            content:
              'You are a creative idea generator. Generate innovative ideas, hypotheses, and insights based on the given topic.',
          },
          {
            role: 'user',
            content: `Generate ideas and insights about: ${query}`,
          },
        ],
      });

      const ideas =
        typeof response.choices[0].message.content === 'string'
          ? response.choices[0].message.content
          : '';

      return `💡 Ideas & Insights: "${query}"\n\n${ideas}\n\n✨ Insights generated`;
    } catch (error) {
      return '❌ Idea generation failed. Please try again later.';
    }
  }

  /**
   * Handle /status command
   */
  private async handleStatus(message: TelegramMessage): Promise<string> {
    // Mock status - in production would check actual system health
    return `✅ System Status\n\n📊 Stats:
• Total Queries: 1,247
• Videos Indexed: 45
• Total Chunks: 5,832
• Success Rate: 98.5%
• Avg Response: 1.2s

🟢 All systems operational`;
  }

  /**
   * Process incoming message
   */
  async processMessage(message: TelegramMessage): Promise<BotResponse> {
    const text = message.text.trim();

    // Extract command
    const commandMatch = text.match(/^\/(\w+)/);
    if (!commandMatch) {
      return {
        chatId: message.chatId,
        text: '❓ I only understand commands. Type /help for available commands.',
      };
    }

    const commandName = commandMatch[1].toLowerCase();
    const command = this.commands.get(commandName);

    if (!command) {
      return {
        chatId: message.chatId,
        text: `❌ Unknown command: /${commandName}\nType /help for available commands.`,
      };
    }

    try {
      const responseText = await command.handler(message);
      return {
        chatId: message.chatId,
        text: responseText,
        parseMode: 'Markdown',
      };
    } catch (error) {
      console.error(`Error processing command /${commandName}:`, error);
      return {
        chatId: message.chatId,
        text: '❌ An error occurred. Please try again later.',
      };
    }
  }

  /**
   * Send message to Telegram
   */
  async sendMessage(response: BotResponse): Promise<boolean> {
    try {
      const url = `${this.apiUrl}/sendMessage`;
      const payload = {
        chat_id: response.chatId,
        text: response.text,
        parse_mode: response.parseMode || 'Markdown',
        reply_to_message_id: response.replyToMessageId,
      };

      // In production, would make actual HTTP request
      console.log('Sending Telegram message:', payload);
      return true;
    } catch (error) {
      console.error('Failed to send Telegram message:', error);
      return false;
    }
  }

  /**
   * Handle webhook update
   */
  async handleWebhookUpdate(update: any): Promise<void> {
    if (!update.message) return;

    const msg = update.message;
    const telegramMessage: TelegramMessage = {
      messageId: msg.message_id,
      chatId: msg.chat.id,
      text: msg.text || '',
      user: {
        id: msg.from.id,
        firstName: msg.from.first_name,
        lastName: msg.from.last_name,
        username: msg.from.username,
        isBot: msg.from.is_bot,
      },
      timestamp: new Date(msg.date * 1000),
    };

    const response = await this.processMessage(telegramMessage);
    await this.sendMessage(response);
  }

  /**
   * Get registered commands
   */
  getCommands(): BotCommand[] {
    return Array.from(this.commands.values());
  }

  /**
   * Register custom command
   */
  registerCommand(command: BotCommand): void {
    this.commands.set(command.command, command);
  }

  /**
   * Get user session
   */
  getUserSession(userId: number): any {
    return this.userSessions.get(userId);
  }

  /**
   * Set user session
   */
  setUserSession(userId: number, session: any): void {
    this.userSessions.set(userId, { ...session, timestamp: new Date() });
  }

  /**
   * Clear user session
   */
  clearUserSession(userId: number): void {
    this.userSessions.delete(userId);
  }

  /**
   * Validate bot token
   */
  static validateToken(token: string): boolean {
    return /^\d+:[A-Za-z0-9_-]{27}$/.test(token);
  }

  /**
   * Get bot info
   */
  async getBotInfo(): Promise<any> {
    try {
      const url = `${this.apiUrl}/getMe`;
      // In production, would make actual HTTP request
      return { ok: true, result: { username: 'knowledge_base_bot' } };
    } catch (error) {
      console.error('Failed to get bot info:', error);
      return null;
    }
  }
}

/**
 * Create bot manager instance
 */
export function createBotManager(botToken: string): TelegramBotManager {
  if (!TelegramBotManager.validateToken(botToken)) {
    throw new Error('Invalid Telegram bot token format');
  }
  return new TelegramBotManager(botToken);
}
