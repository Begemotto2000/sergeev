import { describe, it, expect } from 'vitest';
import { formatSearchResults } from './qdrant';

describe('Qdrant Module', () => {
  describe('formatSearchResults', () => {
    it('should format search results correctly', () => {
      const mockResults = [
        {
          id: 1,
          score: 0.95,
          payload: {
            video_id: 'video_1',
            video_title: 'Менторство 101',
            module_number: 1,
            start_formatted: '00:05:30',
            end_formatted: '00:06:45',
            start_ms: 330000,
            end_ms: 405000,
            text: 'Основы менторства',
          },
        },
        {
          id: 2,
          score: 0.85,
          payload: {
            video_id: 'video_2',
            video_title: 'Менторство 202',
            module_number: 2,
            start_formatted: '00:10:15',
            end_formatted: '00:11:30',
            start_ms: 615000,
            end_ms: 690000,
            text: 'Продвинутые техники',
          },
        },
      ];

      const formatted = formatSearchResults(mockResults, 'ОТВЕТ');

      expect(formatted).toHaveLength(2);
      expect(formatted[0]).toMatchObject({
        id: 1,
        score: 0.95,
        videoId: 'video_1',
        videoTitle: 'Менторство 101',
        startTime: '00:05:30',
        endTime: '00:06:45',
        mode: 'ОТВЕТ',
      });
      expect(formatted[1]).toMatchObject({
        id: 2,
        score: 0.85,
        videoTitle: 'Менторство 202',
      });
    });

    it('should handle empty results', () => {
      const formatted = formatSearchResults([], 'ОТВЕТ');
      expect(formatted).toHaveLength(0);
      expect(Array.isArray(formatted)).toBe(true);
    });

    it('should handle missing payload fields', () => {
      const mockResults = [
        {
          id: 1,
          score: 0.95,
          payload: {
            video_id: 'video_1',
            text: 'Some text',
          },
        },
      ];

      const formatted = formatSearchResults(mockResults, 'ТАЙМКОД');

      expect(formatted).toHaveLength(1);
      expect(formatted[0].videoTitle).toBeUndefined();
      expect(formatted[0].startTime).toBeUndefined();
      expect(formatted[0].text).toBe('Some text');
    });

    it('should preserve mode in all results', () => {
      const mockResults = [
        {
          id: 1,
          score: 0.95,
          payload: { video_id: 'video_1', text: 'Text 1' },
        },
        {
          id: 2,
          score: 0.85,
          payload: { video_id: 'video_2', text: 'Text 2' },
        },
      ];

      const formatted = formatSearchResults(mockResults, 'DEEP RESEARCH');

      expect(formatted.every((r) => r.mode === 'DEEP RESEARCH')).toBe(true);
    });

    it('should handle different modes', () => {
      const mockResults = [
        {
          id: 1,
          score: 0.95,
          payload: { video_id: 'video_1', text: 'Text' },
        },
      ];

      const modes = ['ОТВЕТ', 'ТАЙМКОД', 'DEEP RESEARCH', 'ИМИГО'];

      modes.forEach((mode) => {
        const formatted = formatSearchResults(mockResults, mode);
        expect(formatted[0].mode).toBe(mode);
      });
    });

    it('should preserve all score values', () => {
      const mockResults = [
        {
          id: 1,
          score: 0.99,
          payload: { video_id: 'video_1', text: 'Text' },
        },
        {
          id: 2,
          score: 0.5,
          payload: { video_id: 'video_2', text: 'Text' },
        },
        {
          id: 3,
          score: 0.01,
          payload: { video_id: 'video_3', text: 'Text' },
        },
      ];

      const formatted = formatSearchResults(mockResults, 'ОТВЕТ');

      expect(formatted[0].score).toBe(0.99);
      expect(formatted[1].score).toBe(0.5);
      expect(formatted[2].score).toBe(0.01);
    });
  });

  describe('System prompts', () => {
    it('should have appropriate prompts for each mode', () => {
      const modes = ['ОТВЕТ', 'ТАЙМКОД', 'DEEP RESEARCH', 'ИМИГО'];

      modes.forEach((mode) => {
        expect(mode).toBeDefined();
        expect(typeof mode).toBe('string');
        expect(mode.length).toBeGreaterThan(0);
      });
    });
  });

  describe('Data structure validation', () => {
    it('should maintain data integrity through formatting', () => {
      const original = {
        id: 123,
        score: 0.876,
        payload: {
          video_id: 'vid_abc123',
          video_title: 'Test Video',
          module_number: 5,
          start_formatted: '01:23:45',
          end_formatted: '01:25:00',
          start_ms: 83025000,
          end_ms: 85000000,
          text: 'This is test content',
        },
      };

      const formatted = formatSearchResults([original], 'ОТВЕТ')[0];

      expect(formatted.id).toBe(original.id);
      expect(formatted.score).toBe(original.score);
      expect(formatted.videoId).toBe(original.payload.video_id);
      expect(formatted.videoTitle).toBe(original.payload.video_title);
      expect(formatted.startMs).toBe(original.payload.start_ms);
      expect(formatted.endMs).toBe(original.payload.end_ms);
      expect(formatted.text).toBe(original.payload.text);
    });
  });

  describe('Edge cases', () => {
    it('should handle null payload', () => {
      const mockResults = [
        {
          id: 1,
          score: 0.95,
          payload: null,
        },
      ];

      const formatted = formatSearchResults(mockResults, 'ОТВЕТ');
      expect(formatted).toHaveLength(1);
      expect(formatted[0].videoId).toBeUndefined();
    });

    it('should handle large number of results', () => {
      const mockResults = Array(1000)
        .fill(null)
        .map((_, i) => ({
          id: i,
          score: 0.9 - i * 0.0001,
          payload: {
            video_id: `video_${i}`,
            video_title: `Video ${i}`,
            text: `Content ${i}`,
          },
        }));

      const formatted = formatSearchResults(mockResults, 'ОТВЕТ');
      expect(formatted).toHaveLength(1000);
      expect(formatted[999].videoId).toBe('video_999');
    });

    it('should handle special characters in text', () => {
      const mockResults = [
        {
          id: 1,
          score: 0.95,
          payload: {
            video_id: 'video_1',
            text: 'Special chars: @#$%^&*()_+-=[]{}|;:,.<>?/~`',
          },
        },
      ];

      const formatted = formatSearchResults(mockResults, 'ОТВЕТ');
      expect(formatted[0].text).toContain('@#$%^&*()');
    });
  });
});
