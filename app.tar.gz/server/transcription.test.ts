import { describe, it, expect } from 'vitest';
import {
  parseTranscriptionJSON,
  parseTranscriptionSRT,
  estimateTokenCount,
  chunkTranscription,
  validateTranscription,
  secondsToTimeFormat,
  timeFormatToSeconds,
  processTranscription,
} from './transcription';

describe('Transcription Processing', () => {
  describe('JSON Parsing', () => {
    it('should parse JSON array format', () => {
      const json = JSON.stringify([
        { id: '1', startTime: '00:00:00', endTime: '00:00:05', text: 'Hello world' },
        { id: '2', startTime: '00:00:05', endTime: '00:00:10', text: 'This is a test' },
      ]);

      const segments = parseTranscriptionJSON(json);

      expect(segments).toHaveLength(2);
      expect(segments[0].text).toBe('Hello world');
      expect(segments[1].text).toBe('This is a test');
    });

    it('should parse JSON object with segments property', () => {
      const json = JSON.stringify({
        segments: [
          { startTime: '00:00:00', endTime: '00:00:05', text: 'First segment' },
          { startTime: '00:00:05', endTime: '00:00:10', text: 'Second segment' },
        ],
      });

      const segments = parseTranscriptionJSON(json);

      expect(segments).toHaveLength(2);
      expect(segments[0].text).toBe('First segment');
    });

    it('should handle missing optional fields', () => {
      const json = JSON.stringify([{ text: 'Only text' }]);

      const segments = parseTranscriptionJSON(json);

      expect(segments).toHaveLength(1);
      expect(segments[0].startTime).toBe('00:00:00');
      expect(segments[0].endTime).toBe('00:00:00');
    });

    it('should return empty array for invalid JSON', () => {
      const segments = parseTranscriptionJSON('invalid json');

      expect(segments).toEqual([]);
    });
  });

  describe('SRT Parsing', () => {
    it('should parse SRT format', () => {
      const srt = `1
00:00:00,000 --> 00:00:05,000
First subtitle

2
00:00:05,000 --> 00:00:10,000
Second subtitle`;

      const segments = parseTranscriptionSRT(srt);

      expect(segments).toHaveLength(2);
      expect(segments[0].text).toBe('First subtitle');
      expect(segments[0].startTime).toBe('00:00:00');
      expect(segments[0].endTime).toBe('00:00:05');
    });

    it('should handle multi-line subtitles', () => {
      const srt = `1
00:00:00,000 --> 00:00:05,000
Line one
Line two`;

      const segments = parseTranscriptionSRT(srt);

      expect(segments).toHaveLength(1);
      expect(segments[0].text).toBe('Line one\nLine two');
    });
  });

  describe('Token Counting', () => {
    it('should estimate token count', () => {
      const text = 'This is a test'; // 14 characters
      const tokens = estimateTokenCount(text);

      expect(tokens).toBe(4); // 14 / 4 = 3.5, rounded up to 4
    });

    it('should handle empty text', () => {
      const tokens = estimateTokenCount('');

      expect(tokens).toBe(0);
    });

    it('should handle long text', () => {
      const text = 'A'.repeat(1000);
      const tokens = estimateTokenCount(text);

      expect(tokens).toBe(250); // 1000 / 4 = 250
    });
  });

  describe('Chunking', () => {
    it('should chunk transcription into segments', () => {
      const segments = [
        { id: '1', startTime: '00:00:00', endTime: '00:00:05', text: 'A'.repeat(100) },
        { id: '2', startTime: '00:00:05', endTime: '00:00:10', text: 'B'.repeat(100) },
        { id: '3', startTime: '00:00:10', endTime: '00:00:15', text: 'C'.repeat(100) },
      ];

      const chunks = chunkTranscription(segments, 'video_1', 100);

      expect(chunks.length).toBeGreaterThan(0);
      expect(chunks[0].videoId).toBe('video_1');
      expect(chunks[0].startTime).toBe('00:00:00');
    });

    it('should respect target token count', () => {
      const segments = Array(10)
        .fill(null)
        .map((_, i) => ({
          id: `${i}`,
          startTime: `00:00:${String(i * 5).padStart(2, '0')}`,
          endTime: `00:00:${String(i * 5 + 5).padStart(2, '0')}`,
          text: 'Test content for chunking',
        }));

      const chunks = chunkTranscription(segments, 'video_1', 50);

      chunks.forEach((chunk) => {
        expect(chunk.tokenCount).toBeLessThanOrEqual(100); // Some buffer
      });
    });
  });

  describe('Validation', () => {
    it('should validate correct transcription', () => {
      const segments = [
        { id: '1', startTime: '00:00:00', endTime: '00:00:05', text: 'Valid text' },
      ];

      const result = validateTranscription(segments);

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('should reject empty segments', () => {
      const result = validateTranscription([]);

      expect(result.valid).toBe(false);
      expect(result.errors).toContain('No segments found in transcription');
    });

    it('should reject empty text', () => {
      const segments = [{ id: '1', startTime: '00:00:00', endTime: '00:00:05', text: '' }];

      const result = validateTranscription(segments);

      expect(result.valid).toBe(false);
    });

    it('should reject invalid time format', () => {
      const segments = [
        { id: '1', startTime: 'invalid', endTime: '00:00:05', text: 'Text' },
      ];

      const result = validateTranscription(segments);

      expect(result.valid).toBe(false);
    });

    it('should reject startTime after endTime', () => {
      const segments = [
        { id: '1', startTime: '00:00:10', endTime: '00:00:05', text: 'Text' },
      ];

      const result = validateTranscription(segments);

      expect(result.valid).toBe(false);
    });
  });

  describe('Time Conversion', () => {
    it('should convert seconds to HH:MM:SS', () => {
      expect(secondsToTimeFormat(0)).toBe('00:00:00');
      expect(secondsToTimeFormat(3661)).toBe('01:01:01');
      expect(secondsToTimeFormat(7325)).toBe('02:02:05');
    });

    it('should convert HH:MM:SS to seconds', () => {
      expect(timeFormatToSeconds('00:00:00')).toBe(0);
      expect(timeFormatToSeconds('01:01:01')).toBe(3661);
      expect(timeFormatToSeconds('02:02:05')).toBe(7325);
    });

    it('should be reversible', () => {
      const original = 12345;
      const formatted = secondsToTimeFormat(original);
      const converted = timeFormatToSeconds(formatted);

      expect(converted).toBe(original);
    });
  });

  describe('Full Processing Workflow', () => {
    it('should process JSON transcription successfully', async () => {
      const json = JSON.stringify([
        { startTime: '00:00:00', endTime: '00:00:05', text: 'First segment' },
        { startTime: '00:00:05', endTime: '00:00:10', text: 'Second segment' },
      ]);

      const result = await processTranscription('video_1', json, 'json');

      expect(result.success).toBe(true);
      expect(result.chunks).toBeDefined();
      expect(result.chunks!.length).toBeGreaterThan(0);
      expect(result.stats).toBeDefined();
      expect(result.stats!.segmentCount).toBe(2);
    });

    it('should process SRT transcription successfully', async () => {
      const srt = `1
00:00:00,000 --> 00:00:05,000
First segment

2
00:00:05,000 --> 00:00:10,000
Second segment`;

      const result = await processTranscription('video_1', srt, 'srt');

      expect(result.success).toBe(true);
      expect(result.chunks).toBeDefined();
      expect(result.stats!.segmentCount).toBe(2);
    });

    it('should return error for invalid transcription', async () => {
      const json = JSON.stringify([{ text: '' }]);

      const result = await processTranscription('video_1', json, 'json');

      expect(result.success).toBe(false);
      expect(result.errors).toBeDefined();
    });

    it('should calculate correct statistics', async () => {
      const json = JSON.stringify([
        { startTime: '00:00:00', endTime: '00:00:05', text: 'A'.repeat(100) },
        { startTime: '00:00:05', endTime: '00:00:10', text: 'B'.repeat(100) },
      ]);

      const result = await processTranscription('video_1', json, 'json');

      expect(result.stats!.segmentCount).toBe(2);
      expect(result.stats!.chunkCount).toBeGreaterThan(0);
      expect(result.stats!.totalTokens).toBeGreaterThan(0);
      expect(result.stats!.totalCharacters).toBe(201); // Includes space between segments
    });
  });

  describe('Edge Cases', () => {
    it('should handle very long segments', async () => {
      const json = JSON.stringify([
        {
          startTime: '00:00:00',
          endTime: '01:00:00',
          text: 'A'.repeat(10000),
        },
      ]);

      const result = await processTranscription('video_1', json, 'json');

      expect(result.success).toBe(true);
      expect(result.chunks!.length).toBeGreaterThanOrEqual(1); // May fit in one chunk depending on tokenization
    });

    it('should handle many small segments', async () => {
      const segments = Array(100)
        .fill(null)
        .map((_, i) => ({
          startTime: `00:${String(Math.floor(i / 60)).padStart(2, '0')}:${String(i % 60).padStart(2, '0')}`,
          endTime: `00:${String(Math.floor((i + 1) / 60)).padStart(2, '0')}:${String((i + 1) % 60).padStart(2, '0')}`,
          text: 'Short text',
        }));

      const json = JSON.stringify(segments);
      const result = await processTranscription('video_1', json, 'json');

      expect(result.success).toBe(true);
      expect(result.stats!.segmentCount).toBe(100);
    });
  });
});
