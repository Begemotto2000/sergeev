import { describe, it, expect, vi } from 'vitest';
import * as db from './db';

describe('Dashboard Stats', () => {
  it('should return dashboard statistics with zero uploads', async () => {
    // Mock empty logs
    vi.spyOn(db, 'getUserUploadLogs').mockResolvedValueOnce([]);

    const logs = await db.getUserUploadLogs(1, 100);
    
    const totalUploads = logs.length;
    const successfulUploads = logs.filter(log => log.status === 'completed').length;
    const failedUploads = logs.filter(log => log.status === 'failed').length;
    const pendingUploads = logs.filter(log => log.status === 'processing' || log.status === 'pending').length;
    
    expect(totalUploads).toBe(0);
    expect(successfulUploads).toBe(0);
    expect(failedUploads).toBe(0);
    expect(pendingUploads).toBe(0);
  });

  it('should calculate success rate correctly', async () => {
    // Mock logs with mixed statuses
    const mockLogs = [
      { id: 1, userId: 1, filename: 'test1.json', status: 'completed', createdAt: new Date(), updatedAt: new Date() },
      { id: 2, userId: 1, filename: 'test2.json', status: 'completed', createdAt: new Date(), updatedAt: new Date() },
      { id: 3, userId: 1, filename: 'test3.json', status: 'failed', createdAt: new Date(), updatedAt: new Date() },
      { id: 4, userId: 1, filename: 'test4.json', status: 'pending', createdAt: new Date(), updatedAt: new Date() },
    ] as any;

    vi.spyOn(db, 'getUserUploadLogs').mockResolvedValueOnce(mockLogs);

    const logs = await db.getUserUploadLogs(1, 100);
    
    const totalUploads = logs.length;
    const successfulUploads = logs.filter(log => log.status === 'completed').length;
    const successRate = totalUploads > 0 ? Math.round((successfulUploads / totalUploads) * 100) : 0;
    
    expect(totalUploads).toBe(4);
    expect(successfulUploads).toBe(2);
    expect(successRate).toBe(50);
  });

  it('should count pending uploads correctly', async () => {
    const mockLogs = [
      { id: 1, userId: 1, filename: 'test1.json', status: 'pending', createdAt: new Date(), updatedAt: new Date() },
      { id: 2, userId: 1, filename: 'test2.json', status: 'processing', createdAt: new Date(), updatedAt: new Date() },
      { id: 3, userId: 1, filename: 'test3.json', status: 'completed', createdAt: new Date(), updatedAt: new Date() },
    ] as any;

    vi.spyOn(db, 'getUserUploadLogs').mockResolvedValueOnce(mockLogs);

    const logs = await db.getUserUploadLogs(1, 100);
    
    const pendingUploads = logs.filter(log => log.status === 'processing' || log.status === 'pending').length;
    
    expect(pendingUploads).toBe(2);
  });

  it('should return recent uploads correctly', async () => {
    const mockLogs = Array.from({ length: 15 }, (_, i) => ({
      id: i + 1,
      userId: 1,
      filename: `test${i + 1}.json`,
      status: 'pending',
      createdAt: new Date(),
      updatedAt: new Date(),
    })) as any;

    vi.spyOn(db, 'getUserUploadLogs').mockResolvedValueOnce(mockLogs);

    const logs = await db.getUserUploadLogs(1, 100);
    const recentUploads = logs.slice(0, 10);
    
    expect(recentUploads.length).toBe(10);
    expect(logs.length).toBe(15);
  });
});
