import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import * as db from './db';

// Mock the database module
vi.mock('./db', () => ({
  getDb: vi.fn(),
  getUserUploadLogs: vi.fn(),
  getErrorReports: vi.fn(),
  getAllErrorReports: vi.fn(),
}));

describe('Dashboard Functions', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  describe('getUserUploadLogs', () => {
    it('should return upload logs for a user', async () => {
      const mockLogs = [
        {
          id: 1,
          userId: 1,
          filename: 'test1.pdf',
          fileType: 'pdf',
          status: 'completed',
          createdAt: new Date('2026-05-12'),
          updatedAt: new Date('2026-05-12'),
          fileUrl: 'http://example.com/test1.pdf',
          fileKey: 'test1-key',
          errorMessage: null,
          segmentCount: 10,
          chunkCount: 5,
          totalTokens: 1000,
        },
        {
          id: 2,
          userId: 1,
          filename: 'test2.pdf',
          fileType: 'pdf',
          status: 'pending',
          createdAt: new Date('2026-05-11'),
          updatedAt: new Date('2026-05-11'),
          fileUrl: null,
          fileKey: null,
          errorMessage: null,
          segmentCount: 0,
          chunkCount: 0,
          totalTokens: 0,
        },
      ];

      vi.mocked(db.getUserUploadLogs).mockResolvedValue(mockLogs);

      const result = await db.getUserUploadLogs(1, 100);

      expect(result).toEqual(mockLogs);
      expect(result).toHaveLength(2);
      expect(result[0].status).toBe('completed');
      expect(result[1].status).toBe('pending');
    });

    it('should return empty array when user has no logs', async () => {
      vi.mocked(db.getUserUploadLogs).mockResolvedValue([]);

      const result = await db.getUserUploadLogs(999, 100);

      expect(result).toEqual([]);
      expect(result).toHaveLength(0);
    });

    it('should respect the limit parameter', async () => {
      const mockLogs = Array.from({ length: 50 }, (_, i) => ({
        id: i + 1,
        userId: 1,
        filename: `test${i + 1}.pdf`,
        fileType: 'pdf',
        status: 'completed',
        createdAt: new Date(),
        updatedAt: new Date(),
        fileUrl: `http://example.com/test${i + 1}.pdf`,
        fileKey: `test${i + 1}-key`,
        errorMessage: null,
        segmentCount: 10,
        chunkCount: 5,
        totalTokens: 1000,
      }));

      vi.mocked(db.getUserUploadLogs).mockResolvedValue(mockLogs.slice(0, 20));

      const result = await db.getUserUploadLogs(1, 20);

      expect(result).toHaveLength(20);
    });
  });

  describe('Dashboard Statistics Calculation', () => {
    it('should calculate correct statistics from logs', () => {
      const logs = [
        { status: 'completed', id: 1, userId: 1, filename: 'a.pdf', fileType: 'pdf', createdAt: new Date(), updatedAt: new Date(), fileUrl: null, fileKey: null, errorMessage: null, segmentCount: 0, chunkCount: 0, totalTokens: 0 },
        { status: 'completed', id: 2, userId: 1, filename: 'b.pdf', fileType: 'pdf', createdAt: new Date(), updatedAt: new Date(), fileUrl: null, fileKey: null, errorMessage: null, segmentCount: 0, chunkCount: 0, totalTokens: 0 },
        { status: 'failed', id: 3, userId: 1, filename: 'c.pdf', fileType: 'pdf', createdAt: new Date(), updatedAt: new Date(), fileUrl: null, fileKey: null, errorMessage: 'Error', segmentCount: 0, chunkCount: 0, totalTokens: 0 },
        { status: 'pending', id: 4, userId: 1, filename: 'd.pdf', fileType: 'pdf', createdAt: new Date(), updatedAt: new Date(), fileUrl: null, fileKey: null, errorMessage: null, segmentCount: 0, chunkCount: 0, totalTokens: 0 },
      ];

      const successful = logs.filter((log) => log.status === 'completed').length;
      const failed = logs.filter((log) => log.status === 'failed').length;
      const pending = logs.filter((log) => log.status === 'processing' || log.status === 'pending').length;

      expect(successful).toBe(2);
      expect(failed).toBe(1);
      expect(pending).toBe(1);
      expect(logs.length).toBe(4);

      const successRate = Math.round((successful / logs.length) * 100);
      expect(successRate).toBe(50);
    });

    it('should handle empty logs array', () => {
      const logs: any[] = [];

      const successful = logs.filter((log) => log.status === 'completed').length;
      const failed = logs.filter((log) => log.status === 'failed').length;
      const pending = logs.filter((log) => log.status === 'processing' || log.status === 'pending').length;

      expect(successful).toBe(0);
      expect(failed).toBe(0);
      expect(pending).toBe(0);

      const successRate = logs.length > 0 ? Math.round((successful / logs.length) * 100) : 0;
      expect(successRate).toBe(0);
    });
  });

  describe('Error Reports', () => {
    it('should fetch error reports for a user', async () => {
      const mockReports = [
        {
          id: 1,
          userId: 1,
          title: 'Upload failed',
          description: 'File was too large',
          email: 'user@example.com',
          screenshotUrl: null,
          screenshotKey: null,
          priority: 'high',
          status: 'new',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];

      vi.mocked(db.getErrorReports).mockResolvedValue(mockReports);

      const result = await db.getErrorReports(1);

      expect(result).toEqual(mockReports);
      expect(result).toHaveLength(1);
      expect(result[0].priority).toBe('high');
    });

    it('should fetch all error reports (admin)', async () => {
      const mockReports = [
        {
          id: 1,
          userId: 1,
          title: 'Upload failed',
          description: 'File was too large',
          email: 'user@example.com',
          screenshotUrl: null,
          screenshotKey: null,
          priority: 'high',
          status: 'new',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          id: 2,
          userId: 2,
          title: 'Search not working',
          description: 'Search returns no results',
          email: 'user2@example.com',
          screenshotUrl: null,
          screenshotKey: null,
          priority: 'medium',
          status: 'acknowledged',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ];

      vi.mocked(db.getAllErrorReports).mockResolvedValue(mockReports);

      const result = await db.getAllErrorReports();

      expect(result).toEqual(mockReports);
      expect(result).toHaveLength(2);
    });
  });

  describe('Dashboard Data Aggregation', () => {
    it('should aggregate upload and error data for dashboard', async () => {
      const mockLogs = [
        { id: 1, userId: 1, filename: 'a.pdf', fileType: 'pdf', status: 'completed', createdAt: new Date(), updatedAt: new Date(), fileUrl: null, fileKey: null, errorMessage: null, segmentCount: 10, chunkCount: 5, totalTokens: 1000 },
        { id: 2, userId: 1, filename: 'b.pdf', fileType: 'pdf', status: 'failed', createdAt: new Date(), updatedAt: new Date(), fileUrl: null, fileKey: null, errorMessage: 'Error', segmentCount: 0, chunkCount: 0, totalTokens: 0 },
      ];

      const mockErrors = [
        { id: 1, userId: 1, title: 'Error', description: 'Test', email: 'test@example.com', screenshotUrl: null, screenshotKey: null, priority: 'high', status: 'new', createdAt: new Date(), updatedAt: new Date() },
      ];

      vi.mocked(db.getUserUploadLogs).mockResolvedValue(mockLogs);
      vi.mocked(db.getErrorReports).mockResolvedValue(mockErrors);

      const logs = await db.getUserUploadLogs(1, 100);
      const errors = await db.getErrorReports(1);

      expect(logs).toHaveLength(2);
      expect(errors).toHaveLength(1);

      const stats = {
        totalUploads: logs.length,
        successfulUploads: logs.filter((l) => l.status === 'completed').length,
        failedUploads: logs.filter((l) => l.status === 'failed').length,
        errorReports: errors.length,
      };

      expect(stats.totalUploads).toBe(2);
      expect(stats.successfulUploads).toBe(1);
      expect(stats.failedUploads).toBe(1);
      expect(stats.errorReports).toBe(1);
    });
  });
});
