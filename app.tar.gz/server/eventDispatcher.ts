/**
 * Event Dispatcher
 * Manages event emission and webhook delivery integration
 */

import { WebhookEvent, getUserWebhooks, shouldWebhookReceiveEvent, queueWebhookDelivery } from './webhooks';
import { createWebhookPayload } from './webhookDelivery';
import { pushToList, getCacheKey } from './redis';

export type EventType = 
  | 'transcription.started'
  | 'transcription.completed'
  | 'transcription.failed'
  | 'search.started'
  | 'search.completed'
  | 'search.failed'
  | 'rate_limit.warning'
  | 'rate_limit.critical'
  | 'user.created'
  | 'user.deleted'
  | 'user.updated';

export interface Event {
  id: string;
  type: EventType;
  userId: number;
  timestamp: number;
  data: Record<string, any>;
}

export interface EventListener {
  event: EventType;
  handler: (event: Event) => Promise<void>;
}

// Event listeners registry
const listeners: Map<EventType, EventListener['handler'][]> = new Map();

// Event history for analytics
const eventHistory: Event[] = [];
const MAX_HISTORY = 10000;

/**
 * Register event listener
 */
export function on(event: EventType, handler: EventListener['handler']): void {
  if (!listeners.has(event)) {
    listeners.set(event, []);
  }
  listeners.get(event)!.push(handler);
}

/**
 * Unregister event listener
 */
export function off(event: EventType, handler: EventListener['handler']): void {
  const handlers = listeners.get(event);
  if (handlers) {
    const index = handlers.indexOf(handler);
    if (index > -1) {
      handlers.splice(index, 1);
    }
  }
}

/**
 * Emit event and trigger webhooks
 */
export async function emit(
  type: EventType,
  userId: number,
  data: Record<string, any>
): Promise<Event> {
  const event: Event = {
    id: `evt_${Date.now()}_${Math.random().toString(36).substring(7)}`,
    type,
    userId,
    timestamp: Date.now(),
    data,
  };

  // Store in history
  eventHistory.push(event);
  if (eventHistory.length > MAX_HISTORY) {
    eventHistory.shift();
  }

  // Store in Redis for persistence
  try {
    const key = getCacheKey('events', userId.toString());
    await pushToList(key, [event], MAX_HISTORY);
  } catch (error) {
    console.error('Failed to store event in Redis:', error);
  }

  // Call registered listeners
  const handlers = listeners.get(type) || [];
  for (const handler of handlers) {
    try {
      await handler(event);
    } catch (error) {
      console.error(`Error in event handler for ${type}:`, error);
    }
  }

  // Dispatch to webhooks
  try {
    await dispatchToWebhooks(event);
  } catch (error) {
    console.error('Failed to dispatch to webhooks:', error);
  }

  return event;
}

/**
 * Dispatch event to user webhooks
 */
export async function dispatchToWebhooks(event: Event): Promise<void> {
  try {
    const webhooks = await getUserWebhooks(event.userId);

    for (const webhook of webhooks) {
      if (shouldWebhookReceiveEvent(webhook, event.type as WebhookEvent)) {
        const payload = createWebhookPayload(event.type, event.data);
        await queueWebhookDelivery(webhook, event.type as WebhookEvent, event.data);
      }
    }
  } catch (error) {
    console.error('Failed to dispatch to webhooks:', error);
  }
}

/**
 * Get event history
 */
export function getEventHistory(type?: EventType): Event[] {
  if (type) {
    return eventHistory.filter((e) => e.type === type);
  }
  return [...eventHistory];
}

/**
 * Get events by user
 */
export function getEventsByUser(userId: number, type?: EventType): Event[] {
  let events = eventHistory.filter((e) => e.userId === userId);
  if (type) {
    events = events.filter((e) => e.type === type);
  }
  return events;
}

/**
 * Get event statistics
 */
export function getEventStats(): {
  totalEvents: number;
  eventsByType: Record<EventType, number>;
  eventsByUser: Record<number, number>;
  lastEvent?: Event;
} {
  const stats = {
    totalEvents: eventHistory.length,
    eventsByType: {} as Record<EventType, number>,
    eventsByUser: {} as Record<number, number>,
    lastEvent: eventHistory[eventHistory.length - 1],
  };

  for (const event of eventHistory) {
    stats.eventsByType[event.type] = (stats.eventsByType[event.type] || 0) + 1;
    stats.eventsByUser[event.userId] = (stats.eventsByUser[event.userId] || 0) + 1;
  }

  return stats;
}

/**
 * Clear event history
 */
export function clearEventHistory(): void {
  eventHistory.length = 0;
}

/**
 * Get listener count
 */
export function getListenerCount(event?: EventType): number {
  if (event) {
    return listeners.get(event)?.length || 0;
  }
  return Array.from(listeners.values()).reduce((sum, handlers) => sum + handlers.length, 0);
}

/**
 * Emit transcription event
 */
export async function emitTranscriptionEvent(
  userId: number,
  transcriptionId: string,
  status: 'started' | 'completed' | 'failed',
  data?: Record<string, any>
): Promise<Event> {
  const eventType = `transcription.${status}` as EventType;
  return emit(eventType, userId, {
    transcriptionId,
    status,
    ...data,
  });
}

/**
 * Emit search event
 */
export async function emitSearchEvent(
  userId: number,
  queryId: string,
  status: 'started' | 'completed' | 'failed',
  data?: Record<string, any>
): Promise<Event> {
  const eventType = `search.${status}` as EventType;
  return emit(eventType, userId, {
    queryId,
    status,
    ...data,
  });
}

/**
 * Emit rate limit event
 */
export async function emitRateLimitEvent(
  userId: number,
  severity: 'warning' | 'critical',
  data?: Record<string, any>
): Promise<Event> {
  const eventType = `rate_limit.${severity}` as EventType;
  return emit(eventType, userId, {
    severity,
    ...data,
  });
}

/**
 * Emit user event
 */
export async function emitUserEvent(
  userId: number,
  action: 'created' | 'deleted' | 'updated',
  data?: Record<string, any>
): Promise<Event> {
  const eventType = `user.${action}` as EventType;
  return emit(eventType, userId, {
    action,
    ...data,
  });
}

/**
 * Register default event handlers
 */
export function registerDefaultHandlers(): void {
  // Log all events
  on('transcription.completed', async (event) => {
    console.log(`[Event] Transcription completed: ${event.data.transcriptionId}`);
  });

  on('search.completed', async (event) => {
    console.log(`[Event] Search completed: ${event.data.queryId}`);
  });

  on('rate_limit.critical', async (event) => {
    console.warn(`[Event] Rate limit critical for user ${event.userId}`);
  });
}

/**
 * Get all event types
 */
export function getAllEventTypes(): EventType[] {
  return [
    'transcription.started',
    'transcription.completed',
    'transcription.failed',
    'search.started',
    'search.completed',
    'search.failed',
    'rate_limit.warning',
    'rate_limit.critical',
    'user.created',
    'user.deleted',
    'user.updated',
  ];
}
