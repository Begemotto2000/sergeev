/**
 * Webhook Delivery Tests
 */

import { describe, it, expect } from 'vitest';
import {
  getRetryInfo,
  calculateBackoffDelay,
  addJitterToDelay,
  formatDeliveryStatus,
  shouldRetryDelivery,
  getDeliveryStats,
  createWebhookPayload,
  isValidWebhookResponse,
  isRetryableError,
} from './webhookDelivery';

describe('Webhook Delivery', () => {
  describe('Retry Information', () => {
    it('should get retry info for pending delivery', () => {
      const delivery = {
        id: 'del_1',
        webhookId: 'wh_1',
        event: 'transcription.completed' as const,
        status: 'pending' as const,
        attempts: 0,
        maxAttempts: 5,
        createdAt: Date.now(),
      };

      const info = getRetryInfo(delivery);
      expect(info.attempts).toBe(0);
      expect(info.maxAttempts).toBe(5);
      expect(info.canRetry).toBe(false);
    });

    it('should get retry info for retrying delivery', () => {
      const delivery = {
        id: 'del_1',
        webhookId: 'wh_1',
        event: 'transcription.completed' as const,
        status: 'retrying' as const,
        attempts: 2,
        maxAttempts: 5,
        nextRetry: Date.now() + 5000,
        createdAt: Date.now(),
      };

      const info = getRetryInfo(delivery);
      expect(info.attempts).toBe(2);
      expect(info.canRetry).toBe(true);
      expect(info.nextRetry).toBeTruthy();
    });

    it('should indicate no retry for failed delivery', () => {
      const delivery = {
        id: 'del_1',
        webhookId: 'wh_1',
        event: 'transcription.completed' as const,
        status: 'failed' as const,
        attempts: 5,
        maxAttempts: 5,
        error: 'Max retries exceeded',
        createdAt: Date.now(),
        completedAt: Date.now(),
      };

      const info = getRetryInfo(delivery);
      expect(info.canRetry).toBe(false);
    });
  });

  describe('Backoff Delay Calculation', () => {
    it('should calculate exponential backoff', () => {
      const delay0 = calculateBackoffDelay(0);
      const delay1 = calculateBackoffDelay(1);
      const delay2 = calculateBackoffDelay(2);

      expect(delay1).toBeGreaterThan(delay0);
      expect(delay2).toBeGreaterThan(delay1);
    });

    it('should cap maximum delay', () => {
      const maxDelay = 3600000; // 1 hour
      const delay10 = calculateBackoffDelay(10);

      expect(delay10).toBeLessThanOrEqual(maxDelay);
    });

    it('should use custom base delay', () => {
      const delay1 = calculateBackoffDelay(1, 5000);
      const delay2 = calculateBackoffDelay(1, 10000);

      expect(delay2).toBeGreaterThan(delay1);
    });

    it('should return positive delays', () => {
      for (let i = 0; i < 5; i++) {
        const delay = calculateBackoffDelay(i);
        expect(delay).toBeGreaterThan(0);
      }
    });
  });

  describe('Jitter Addition', () => {
    it('should add jitter to delay', () => {
      const baseDelay = 1000;
      const withJitter = addJitterToDelay(baseDelay, 10);

      expect(withJitter).toBeGreaterThanOrEqual(baseDelay * 0.9);
      expect(withJitter).toBeLessThanOrEqual(baseDelay * 1.1);
    });

    it('should not go negative with jitter', () => {
      const smallDelay = 100;
      const withJitter = addJitterToDelay(smallDelay, 50);

      expect(withJitter).toBeGreaterThanOrEqual(0);
    });

    it('should use default jitter percentage', () => {
      const delay1 = addJitterToDelay(1000);
      const delay2 = addJitterToDelay(1000);

      // Jitter should make delays different (with high probability)
      expect(delay1).toBeTruthy();
      expect(delay2).toBeTruthy();
    });
  });

  describe('Delivery Status Formatting', () => {
    it('should format successful delivery', () => {
      const delivery = {
        id: 'del_1',
        webhookId: 'wh_1',
        event: 'transcription.completed' as const,
        status: 'success' as const,
        attempts: 1,
        maxAttempts: 5,
        createdAt: Date.now(),
        completedAt: Date.now(),
      };

      const formatted = formatDeliveryStatus(delivery);
      expect(formatted).toContain('✓');
      expect(formatted).toContain('Delivered');
    });

    it('should format failed delivery', () => {
      const delivery = {
        id: 'del_1',
        webhookId: 'wh_1',
        event: 'transcription.completed' as const,
        status: 'failed' as const,
        attempts: 5,
        maxAttempts: 5,
        error: 'Connection timeout',
        createdAt: Date.now(),
        completedAt: Date.now(),
      };

      const formatted = formatDeliveryStatus(delivery);
      expect(formatted).toContain('✗');
      expect(formatted).toContain('Failed');
    });

    it('should format retrying delivery', () => {
      const delivery = {
        id: 'del_1',
        webhookId: 'wh_1',
        event: 'transcription.completed' as const,
        status: 'retrying' as const,
        attempts: 2,
        maxAttempts: 5,
        nextRetry: Date.now() + 5000,
        createdAt: Date.now(),
      };

      const formatted = formatDeliveryStatus(delivery);
      expect(formatted).toContain('Retrying');
      expect(formatted).toContain('2');
    });
  });

  describe('Retry Decision', () => {
    it('should retry pending delivery', () => {
      const delivery = {
        id: 'del_1',
        webhookId: 'wh_1',
        event: 'transcription.completed' as const,
        status: 'retrying' as const,
        attempts: 1,
        maxAttempts: 5,
        nextRetry: Date.now() - 1000, // Past time
        createdAt: Date.now(),
      };

      const shouldRetry = shouldRetryDelivery(delivery);
      expect(shouldRetry).toBe(true);
    });

    it('should not retry successful delivery', () => {
      const delivery = {
        id: 'del_1',
        webhookId: 'wh_1',
        event: 'transcription.completed' as const,
        status: 'success' as const,
        attempts: 1,
        maxAttempts: 5,
        createdAt: Date.now(),
        completedAt: Date.now(),
      };

      const shouldRetry = shouldRetryDelivery(delivery);
      expect(shouldRetry).toBe(false);
    });

    it('should not retry if max attempts exceeded', () => {
      const delivery = {
        id: 'del_1',
        webhookId: 'wh_1',
        event: 'transcription.completed' as const,
        status: 'retrying' as const,
        attempts: 5,
        maxAttempts: 5,
        nextRetry: Date.now() - 1000,
        createdAt: Date.now(),
      };

      const shouldRetry = shouldRetryDelivery(delivery);
      expect(shouldRetry).toBe(false);
    });

    it('should not retry if next retry is in future', () => {
      const delivery = {
        id: 'del_1',
        webhookId: 'wh_1',
        event: 'transcription.completed' as const,
        status: 'retrying' as const,
        attempts: 2,
        maxAttempts: 5,
        nextRetry: Date.now() + 10000, // Future time
        createdAt: Date.now(),
      };

      const shouldRetry = shouldRetryDelivery(delivery);
      expect(shouldRetry).toBe(false);
    });
  });

  describe('Delivery Statistics', () => {
    it('should calculate delivery statistics', () => {
      const deliveries = [
        {
          id: 'del_1',
          webhookId: 'wh_1',
          event: 'transcription.completed' as const,
          status: 'success' as const,
          attempts: 1,
          maxAttempts: 5,
          createdAt: Date.now(),
          completedAt: Date.now(),
        },
        {
          id: 'del_2',
          webhookId: 'wh_1',
          event: 'transcription.completed' as const,
          status: 'success' as const,
          attempts: 2,
          maxAttempts: 5,
          createdAt: Date.now(),
          completedAt: Date.now(),
        },
        {
          id: 'del_3',
          webhookId: 'wh_1',
          event: 'transcription.completed' as const,
          status: 'failed' as const,
          attempts: 5,
          maxAttempts: 5,
          error: 'Max retries',
          createdAt: Date.now(),
          completedAt: Date.now(),
        },
      ];

      const stats = getDeliveryStats(deliveries);
      expect(stats.total).toBe(3);
      expect(stats.successful).toBe(2);
      expect(stats.failed).toBe(1);
      expect(stats.successRate).toBeCloseTo(66.67, 1);
    });

    it('should calculate average attempts', () => {
      const deliveries = [
        {
          id: 'del_1',
          webhookId: 'wh_1',
          event: 'transcription.completed' as const,
          status: 'success' as const,
          attempts: 1,
          maxAttempts: 5,
          createdAt: Date.now(),
          completedAt: Date.now(),
        },
        {
          id: 'del_2',
          webhookId: 'wh_1',
          event: 'transcription.completed' as const,
          status: 'success' as const,
          attempts: 3,
          maxAttempts: 5,
          createdAt: Date.now(),
          completedAt: Date.now(),
        },
      ];

      const stats = getDeliveryStats(deliveries);
      expect(stats.averageAttempts).toBe(2);
    });
  });

  describe('Webhook Payload Creation', () => {
    it('should create valid webhook payload', () => {
      const payload = createWebhookPayload('transcription.completed', {
        transcriptionId: 'tr_123',
        status: 'completed',
      });

      expect(payload.id).toBeTruthy();
      expect(payload.event).toBe('transcription.completed');
      expect(payload.timestamp).toBeGreaterThan(0);
      expect(payload.data).toHaveProperty('transcriptionId');
    });

    it('should generate unique payload IDs', () => {
      const payload1 = createWebhookPayload('test.event', {});
      const payload2 = createWebhookPayload('test.event', {});

      expect(payload1.id).not.toBe(payload2.id);
    });
  });

  describe('Response Validation', () => {
    it('should validate successful responses', () => {
      expect(isValidWebhookResponse(200)).toBe(true);
      expect(isValidWebhookResponse(201)).toBe(true);
      expect(isValidWebhookResponse(204)).toBe(true);
      expect(isValidWebhookResponse(299)).toBe(true);
    });

    it('should reject error responses', () => {
      expect(isValidWebhookResponse(400)).toBe(false);
      expect(isValidWebhookResponse(401)).toBe(false);
      expect(isValidWebhookResponse(500)).toBe(false);
    });
  });

  describe('Retryable Errors', () => {
    it('should identify connection errors as retryable', () => {
      expect(isRetryableError('ECONNREFUSED')).toBe(true);
      expect(isRetryableError('ECONNRESET')).toBe(true);
      expect(isRetryableError('ETIMEDOUT')).toBe(true);
    });

    it('should identify rate limit as retryable', () => {
      expect(isRetryableError('429')).toBe(true);
    });

    it('should identify server errors as retryable', () => {
      expect(isRetryableError('503')).toBe(true);
      expect(isRetryableError('504')).toBe(true);
    });

    it('should not identify client errors as retryable', () => {
      expect(isRetryableError('400')).toBe(false);
      expect(isRetryableError('401')).toBe(false);
      expect(isRetryableError('403')).toBe(false);
    });
  });
});
