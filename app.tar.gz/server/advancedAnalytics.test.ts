/**
 * Advanced Analytics Tests
 */

import { describe, it, expect } from 'vitest';
import {
  getWebhookMetrics,
  getEventMetrics,
  getDeliveryTrend,
  getSuccessRateTrend,
  getEventDistribution,
  getTopWebhooks,
  getAnalyticsSummary,
  exportAnalyticsData,
} from './advancedAnalytics';

describe('Advanced Analytics', () => {
  describe('Webhook Metrics', () => {
    it('should get webhook metrics', async () => {
      const metrics = await getWebhookMetrics();

      expect(metrics).toHaveProperty('totalDeliveries');
      expect(metrics).toHaveProperty('successfulDeliveries');
      expect(metrics).toHaveProperty('failedDeliveries');
      expect(metrics).toHaveProperty('successRate');
    });

    it('should calculate success rate', async () => {
      const metrics = await getWebhookMetrics();

      expect(metrics.successRate).toBeGreaterThanOrEqual(0);
      expect(metrics.successRate).toBeLessThanOrEqual(100);
    });

    it('should track deliveries by event type', async () => {
      const metrics = await getWebhookMetrics();

      expect(metrics).toHaveProperty('deliveriesByEventType');
      expect(typeof metrics.deliveriesByEventType).toBe('object');
    });
  });

  describe('Event Metrics', () => {
    it('should get event metrics', async () => {
      const metrics = await getEventMetrics();

      expect(metrics).toHaveProperty('totalEvents');
      expect(metrics).toHaveProperty('eventsByType');
      expect(metrics).toHaveProperty('eventsByUser');
      expect(metrics).toHaveProperty('eventsPerHour');
    });

    it('should track events by type', async () => {
      const metrics = await getEventMetrics();

      expect(typeof metrics.eventsByType).toBe('object');
    });

    it('should track events by user', async () => {
      const metrics = await getEventMetrics();

      expect(typeof metrics.eventsByUser).toBe('object');
    });
  });

  describe('Delivery Trends', () => {
    it('should get delivery trend', async () => {
      const trend = await getDeliveryTrend(7);

      expect(trend).toHaveProperty('metric');
      expect(trend).toHaveProperty('data');
      expect(trend).toHaveProperty('trend');
      expect(trend).toHaveProperty('changePercentage');
    });

    it('should return time series data', async () => {
      const trend = await getDeliveryTrend(7);

      expect(trend.data).toHaveLength(7);
      expect(trend.data[0]).toHaveProperty('timestamp');
      expect(trend.data[0]).toHaveProperty('value');
      expect(trend.data[0]).toHaveProperty('label');
    });

    it('should calculate trend direction', async () => {
      const trend = await getDeliveryTrend(7);

      expect(['up', 'down', 'stable']).toContain(trend.trend);
    });

    it('should support custom day range', async () => {
      const trend30 = await getDeliveryTrend(30);
      const trend7 = await getDeliveryTrend(7);

      expect(trend30.data.length).toBe(30);
      expect(trend7.data.length).toBe(7);
    });
  });

  describe('Success Rate Trends', () => {
    it('should get success rate trend', async () => {
      const trend = await getSuccessRateTrend(7);

      expect(trend.metric).toBe('success_rate');
      expect(trend.data).toHaveLength(7);
    });

    it('should track success rate percentage', async () => {
      const trend = await getSuccessRateTrend(7);

      for (const point of trend.data) {
        expect(point.value).toBeGreaterThanOrEqual(0);
        expect(point.value).toBeLessThanOrEqual(100);
      }
    });

    it('should calculate change percentage', async () => {
      const trend = await getSuccessRateTrend(7);

      expect(typeof trend.changePercentage).toBe('number');
    });
  });

  describe('Event Distribution', () => {
    it('should get event distribution', async () => {
      const distribution = await getEventDistribution();

      expect(typeof distribution).toBe('object');
    });

    it('should include major event types', async () => {
      const distribution = await getEventDistribution();

      expect(Object.keys(distribution).length).toBeGreaterThan(0);
    });

    it('should have positive counts', async () => {
      const distribution = await getEventDistribution();

      for (const [event, count] of Object.entries(distribution)) {
        expect(count).toBeGreaterThanOrEqual(0);
      }
    });
  });

  describe('Top Webhooks', () => {
    it('should get top webhooks', async () => {
      const webhooks = await getTopWebhooks(10);

      expect(Array.isArray(webhooks)).toBe(true);
    });

    it('should include webhook metrics', async () => {
      const webhooks = await getTopWebhooks(5);

      if (webhooks.length > 0) {
        expect(webhooks[0]).toHaveProperty('webhookId');
        expect(webhooks[0]).toHaveProperty('deliveryCount');
        expect(webhooks[0]).toHaveProperty('successRate');
      }
    });

    it('should respect limit parameter', async () => {
      const webhooks5 = await getTopWebhooks(5);
      const webhooks10 = await getTopWebhooks(10);

      expect(webhooks5.length).toBeLessThanOrEqual(5);
      expect(webhooks10.length).toBeLessThanOrEqual(10);
    });

    it('should sort by delivery count', async () => {
      const webhooks = await getTopWebhooks(10);

      for (let i = 1; i < webhooks.length; i++) {
        expect(webhooks[i - 1].deliveryCount).toBeGreaterThanOrEqual(webhooks[i].deliveryCount);
      }
    });
  });

  describe('Analytics Summary', () => {
    it('should get complete analytics summary', async () => {
      const summary = await getAnalyticsSummary();

      expect(summary).toHaveProperty('webhookMetrics');
      expect(summary).toHaveProperty('eventMetrics');
      expect(summary).toHaveProperty('deliveryTrend');
      expect(summary).toHaveProperty('successRateTrend');
      expect(summary).toHaveProperty('eventDistribution');
      expect(summary).toHaveProperty('topWebhooks');
    });

    it('should include all metric types', async () => {
      const summary = await getAnalyticsSummary();

      expect(summary.webhookMetrics).toBeTruthy();
      expect(summary.eventMetrics).toBeTruthy();
      expect(summary.deliveryTrend).toBeTruthy();
      expect(summary.successRateTrend).toBeTruthy();
    });
  });

  describe('Data Export', () => {
    it('should export as JSON', async () => {
      const json = await exportAnalyticsData('json');

      expect(typeof json).toBe('string');
      const parsed = JSON.parse(json);
      expect(parsed).toHaveProperty('webhookMetrics');
    });

    it('should export as CSV', async () => {
      const csv = await exportAnalyticsData('csv');

      expect(typeof csv).toBe('string');
      expect(csv).toContain('Metric,Value');
      expect(csv).toContain('Total Deliveries');
    });

    it('should default to JSON', async () => {
      const data = await exportAnalyticsData();

      expect(typeof data).toBe('string');
      const parsed = JSON.parse(data);
      expect(parsed).toHaveProperty('webhookMetrics');
    });

    it('should include all metrics in export', async () => {
      const json = await exportAnalyticsData('json');
      const parsed = JSON.parse(json);

      expect(parsed.webhookMetrics).toBeTruthy();
      expect(parsed.eventMetrics).toBeTruthy();
      expect(parsed.deliveryTrend).toBeTruthy();
    });
  });

  describe('Metrics Calculation', () => {
    it('should calculate average attempts', async () => {
      const metrics = await getWebhookMetrics();

      expect(metrics.averageAttempts).toBeGreaterThanOrEqual(0);
    });

    it('should handle zero deliveries', async () => {
      const metrics = await getWebhookMetrics();

      if (metrics.totalDeliveries === 0) {
        expect(metrics.successRate).toBe(0);
      }
    });

    it('should calculate success rate correctly', async () => {
      const metrics = await getWebhookMetrics();

      if (metrics.totalDeliveries > 0) {
        const expected = (metrics.successfulDeliveries / metrics.totalDeliveries) * 100;
        expect(metrics.successRate).toBeCloseTo(expected, 1);
      }
    });
  });

  describe('Trend Analysis', () => {
    it('should identify upward trend', async () => {
      const trend = await getDeliveryTrend(7);

      expect(['up', 'down', 'stable']).toContain(trend.trend);
    });

    it('should calculate percentage change', async () => {
      const trend = await getDeliveryTrend(7);

      expect(typeof trend.changePercentage).toBe('number');
    });

    it('should handle flat trends', async () => {
      const trend = await getSuccessRateTrend(7);

      // Should not throw and should return valid data
      expect(trend.data).toBeTruthy();
    });
  });
});
