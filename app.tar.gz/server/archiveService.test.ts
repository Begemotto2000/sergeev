/**
 * Archive Service Tests
 */

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { chunkText, getSupportedFileTypes, validateArchive } from './archiveService.js';

describe('Archive Service', () => {
  describe('chunkText', () => {
    it('should chunk text into 50-word chunks', () => {
      const text = 'word '.repeat(100); // 100 words
      const chunks = chunkText(text, 50, 300);
      
      expect(chunks.length).toBeGreaterThan(0);
      chunks.forEach(chunk => {
        const wordCount = chunk.split(/\s+/).length;
        expect(wordCount).toBeLessThanOrEqual(50);
      });
    });

    it('should respect 300 character limit', () => {
      const text = 'a'.repeat(500);
      const chunks = chunkText(text, 50, 300);
      
      chunks.forEach(chunk => {
        expect(chunk.length).toBeLessThanOrEqual(300);
      });
    });

    it('should handle empty text', () => {
      const chunks = chunkText('', 50, 300);
      expect(chunks.length).toBe(0);
    });

    it('should handle single word', () => {
      const chunks = chunkText('hello', 50, 300);
      expect(chunks.length).toBe(1);
      expect(chunks[0]).toBe('hello');
    });

    it('should preserve word boundaries', () => {
      const text = 'The quick brown fox jumps over the lazy dog';
      const chunks = chunkText(text, 5, 100);
      
      chunks.forEach(chunk => {
        // No partial words
        expect(chunk).not.toMatch(/\s\w+$/);
      });
    });
  });

  describe('getSupportedFileTypes', () => {
    it('should return array of supported types', () => {
      const types = getSupportedFileTypes();
      
      expect(Array.isArray(types)).toBe(true);
      expect(types.length).toBeGreaterThan(0);
      expect(types).toContain('.txt');
      expect(types).toContain('.srt');
      expect(types).toContain('.json');
      expect(types).toContain('.csv');
      expect(types).toContain('.zip');
    });
  });

  describe('validateArchive', () => {
    it('should validate ZIP files', () => {
      expect(validateArchive('archive.zip')).toBe(true);
    });

    it('should validate TAR files', () => {
      expect(validateArchive('archive.tar')).toBe(true);
    });

    it('should validate GZ files', () => {
      expect(validateArchive('archive.gz')).toBe(true);
    });

    it('should reject non-archive files', () => {
      expect(validateArchive('document.txt')).toBe(false);
      expect(validateArchive('image.jpg')).toBe(false);
      expect(validateArchive('video.mp4')).toBe(false);
    });

    it('should be case-insensitive', () => {
      expect(validateArchive('archive.ZIP')).toBe(true);
      expect(validateArchive('archive.Zip')).toBe(true);
    });
  });

  describe('Text chunking edge cases', () => {
    it('should handle very long words', () => {
      const longWord = 'a'.repeat(400);
      const chunks = chunkText(longWord, 50, 300);
      
      // Should still create chunks, even if word exceeds limit
      expect(chunks.length).toBeGreaterThan(0);
    });

    it('should handle multiple spaces', () => {
      const text = 'word1    word2    word3';
      const chunks = chunkText(text, 50, 300);
      
      expect(chunks.length).toBeGreaterThan(0);
      chunks.forEach(chunk => {
        expect(chunk.trim()).toBeTruthy();
      });
    });

    it('should handle newlines and special characters', () => {
      const text = 'line1\nline2\nline3\tword4';
      const chunks = chunkText(text, 50, 300);
      
      expect(chunks.length).toBeGreaterThan(0);
    });
  });
});
