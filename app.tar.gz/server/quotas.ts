/**
 * User Quotas & Billing System
 * Manages API usage limits, credits, and billing
 */

import { getCacheKey, getCounter, setCounter, pushToList } from './redis';

export interface UserQuota {
  userId: number;
  apiCallsLimit: number;
  apiCallsUsed: number;
  storageLimit: number; // MB
  storageUsed: number;
  creditsLimit: number;
  creditsUsed: number;
  resetDate: Date;
  tier: 'free' | 'pro' | 'enterprise';
}

export interface BillingRecord {
  id: string;
  userId: number;
  amount: number;
  creditsUsed: number;
  description: string;
  timestamp: number;
  status: 'pending' | 'completed' | 'failed';
}

export interface QuotaAlert {
  userId: number;
  type: 'api_calls' | 'storage' | 'credits';
  percentage: number;
  timestamp: number;
}

const TIER_LIMITS = {
  free: {
    apiCallsLimit: 1000,
    storageLimit: 100, // MB
    creditsLimit: 100,
  },
  pro: {
    apiCallsLimit: 100000,
    storageLimit: 10000, // MB
    creditsLimit: 10000,
  },
  enterprise: {
    apiCallsLimit: Infinity,
    storageLimit: Infinity,
    creditsLimit: Infinity,
  },
};

const API_CALL_COST = 1;
const STORAGE_COST_PER_MB = 0.1;
const SEARCH_COST = 5;
const TRANSCRIPTION_COST = 50;

/**
 * Get user quota
 */
export async function getUserQuota(userId: number): Promise<UserQuota> {
  try {
    const key = getCacheKey('quota', userId.toString());
    const tier = (await getCounter(getCacheKey('user:tier', userId.toString()))) as any || 'free';
    const limits = TIER_LIMITS[tier as keyof typeof TIER_LIMITS] || TIER_LIMITS.free;

    const apiCallsUsed = await getCounter(getCacheKey('quota:api_calls', userId.toString()));
    const storageUsed = await getCounter(getCacheKey('quota:storage', userId.toString()));
    const creditsUsed = await getCounter(getCacheKey('quota:credits', userId.toString()));

    return {
      userId,
      apiCallsLimit: limits.apiCallsLimit,
      apiCallsUsed,
      storageLimit: limits.storageLimit,
      storageUsed,
      creditsLimit: limits.creditsLimit,
      creditsUsed,
      resetDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      tier: tier as any,
    };
  } catch (error) {
    console.error('Failed to get user quota:', error);
    return {
      userId,
      apiCallsLimit: 1000,
      apiCallsUsed: 0,
      storageLimit: 100,
      storageUsed: 0,
      creditsLimit: 100,
      creditsUsed: 0,
      resetDate: new Date(),
      tier: 'free',
    };
  }
}

/**
 * Check if user has quota available
 */
export async function hasQuota(userId: number, type: 'api_calls' | 'storage' | 'credits', amount: number = 1): Promise<boolean> {
  try {
    const quota = await getUserQuota(userId);

    switch (type) {
      case 'api_calls':
        return quota.apiCallsUsed + amount <= quota.apiCallsLimit;
      case 'storage':
        return quota.storageUsed + amount <= quota.storageLimit;
      case 'credits':
        return quota.creditsUsed + amount <= quota.creditsLimit;
      default:
        return false;
    }
  } catch (error) {
    console.error('Failed to check quota:', error);
    return false;
  }
}

/**
 * Deduct quota
 */
export async function deductQuota(userId: number, type: 'api_calls' | 'storage' | 'credits', amount: number = 1): Promise<boolean> {
  try {
    const hasAvailable = await hasQuota(userId, type, amount);
    if (!hasAvailable) {
      return false;
    }

    const key = getCacheKey(`quota:${type}`, userId.toString());
    const current = await getCounter(key);
    await setCounter(key, current + amount, 2592000); // 30 days

    // Check for alerts
    const quota = await getUserQuota(userId);
    const percentage = ((current + amount) / (quota as any)[`${type}Limit`]) * 100;

    if (percentage >= 80) {
      await recordQuotaAlert(userId, type, percentage);
    }

    return true;
  } catch (error) {
    console.error('Failed to deduct quota:', error);
    return false;
  }
}

/**
 * Calculate cost for operation
 */
export function calculateOperationCost(operation: 'api_call' | 'search' | 'transcription'): number {
  switch (operation) {
    case 'api_call':
      return API_CALL_COST;
    case 'search':
      return SEARCH_COST;
    case 'transcription':
      return TRANSCRIPTION_COST;
    default:
      return 0;
  }
}

/**
 * Charge user for operation
 */
export async function chargeUser(userId: number, operation: 'api_call' | 'search' | 'transcription'): Promise<boolean> {
  try {
    const cost = calculateOperationCost(operation);

    // Deduct from credits
    const charged = await deductQuota(userId, 'credits', cost);

    if (charged) {
      // Record billing
      await recordBillingEvent(userId, cost, operation);
    }

    return charged;
  } catch (error) {
    console.error('Failed to charge user:', error);
    return false;
  }
}

/**
 * Record billing event
 */
export async function recordBillingEvent(userId: number, creditsUsed: number, description: string): Promise<BillingRecord> {
  try {
    const record: BillingRecord = {
      id: `bill_${Date.now()}_${Math.random().toString(36).substring(7)}`,
      userId,
      amount: creditsUsed * 0.01, // Convert credits to dollars
      creditsUsed,
      description,
      timestamp: Date.now(),
      status: 'completed',
    };

    const key = getCacheKey('billing', userId.toString());
    await pushToList(key, [record], 10000);

    return record;
  } catch (error) {
    console.error('Failed to record billing event:', error);
    return {
      id: '',
      userId,
      amount: 0,
      creditsUsed: 0,
      description: '',
      timestamp: 0,
      status: 'failed',
    };
  }
}

/**
 * Record quota alert
 */
export async function recordQuotaAlert(userId: number, type: 'api_calls' | 'storage' | 'credits', percentage: number): Promise<void> {
  try {
    const alert: QuotaAlert = {
      userId,
      type,
      percentage,
      timestamp: Date.now(),
    };

    const key = getCacheKey('quota:alerts', userId.toString());
    await pushToList(key, [alert], 1000);
  } catch (error) {
    console.error('Failed to record quota alert:', error);
  }
}

/**
 * Get billing history
 */
export async function getBillingHistory(userId: number, limit: number = 100): Promise<BillingRecord[]> {
  try {
    // Placeholder - would fetch from Redis
    return [];
  } catch (error) {
    console.error('Failed to get billing history:', error);
    return [];
  }
}

/**
 * Get quota usage percentage
 */
export async function getQuotaUsagePercentage(userId: number): Promise<{
  apiCalls: number;
  storage: number;
  credits: number;
}> {
  try {
    const quota = await getUserQuota(userId);

    return {
      apiCalls: (quota.apiCallsUsed / quota.apiCallsLimit) * 100,
      storage: (quota.storageUsed / quota.storageLimit) * 100,
      credits: (quota.creditsUsed / quota.creditsLimit) * 100,
    };
  } catch (error) {
    console.error('Failed to get quota usage percentage:', error);
    return { apiCalls: 0, storage: 0, credits: 0 };
  }
}

/**
 * Reset user quota
 */
export async function resetUserQuota(userId: number): Promise<void> {
  try {
    await setCounter(getCacheKey('quota:api_calls', userId.toString()), 0, 2592000);
    await setCounter(getCacheKey('quota:storage', userId.toString()), 0, 2592000);
    await setCounter(getCacheKey('quota:credits', userId.toString()), 0, 2592000);
  } catch (error) {
    console.error('Failed to reset user quota:', error);
  }
}

/**
 * Upgrade user tier
 */
export async function upgradeUserTier(userId: number, tier: 'free' | 'pro' | 'enterprise'): Promise<void> {
  try {
    await setCounter(getCacheKey('user:tier', userId.toString()), tier as any, 31536000); // 1 year
    await resetUserQuota(userId);
  } catch (error) {
    console.error('Failed to upgrade user tier:', error);
  }
}

/**
 * Get quota alerts
 */
export async function getQuotaAlerts(userId: number): Promise<QuotaAlert[]> {
  try {
    // Placeholder - would fetch from Redis
    return [];
  } catch (error) {
    console.error('Failed to get quota alerts:', error);
    return [];
  }
}

/**
 * Get billing summary
 */
export async function getBillingSummary(userId: number): Promise<{
  totalSpent: number;
  totalCreditsUsed: number;
  averageTransactionSize: number;
  lastBillingDate: Date;
}> {
  try {
    const history = await getBillingHistory(userId, 100);

    const totalSpent = history.reduce((sum, record) => sum + record.amount, 0);
    const totalCreditsUsed = history.reduce((sum, record) => sum + record.creditsUsed, 0);
    const averageTransactionSize = history.length > 0 ? totalSpent / history.length : 0;

    return {
      totalSpent,
      totalCreditsUsed,
      averageTransactionSize,
      lastBillingDate: history.length > 0 ? new Date(history[0].timestamp) : new Date(),
    };
  } catch (error) {
    console.error('Failed to get billing summary:', error);
    return {
      totalSpent: 0,
      totalCreditsUsed: 0,
      averageTransactionSize: 0,
      lastBillingDate: new Date(),
    };
  }
}
