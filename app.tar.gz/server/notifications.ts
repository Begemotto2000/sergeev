/**
 * WebSocket Notification Service
 * Handles real-time notifications for transcription processing and search updates
 */

import { Server as SocketIOServer, Socket } from 'socket.io';
import { publishMessage, getRedisClient } from './redis';

export type NotificationType = 
  | 'transcription_started'
  | 'transcription_progress'
  | 'transcription_completed'
  | 'transcription_failed'
  | 'search_started'
  | 'search_completed'
  | 'system_alert'
  | 'cache_update';

export interface Notification {
  type: NotificationType;
  userId: number;
  data: any;
  timestamp: number;
  id?: string;
}

// Store connected users and their socket IDs
const connectedUsers = new Map<number, Set<string>>();

// Store notification history
const notificationHistory = new Map<number, Notification[]>();
const MAX_HISTORY = 100;

/**
 * Initialize Socket.IO server
 */
export function initializeSocketIO(httpServer: any): SocketIOServer {
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: process.env.FRONTEND_URL || '*',
      methods: ['GET', 'POST'],
    },
    transports: ['websocket', 'polling'],
  });

  io.on('connection', (socket: Socket) => {
    console.log(`User connected: ${socket.id}`);

    // Handle user authentication
    socket.on('authenticate', (userId: number) => {
      if (!connectedUsers.has(userId)) {
        connectedUsers.set(userId, new Set());
      }
      connectedUsers.get(userId)!.add(socket.id);
      socket.data.userId = userId;
      socket.join(`user:${userId}`);
      console.log(`User ${userId} authenticated with socket ${socket.id}`);
    });

    // Handle disconnect
    socket.on('disconnect', () => {
      const userId = socket.data.userId;
      if (userId && connectedUsers.has(userId)) {
        connectedUsers.get(userId)!.delete(socket.id);
        if (connectedUsers.get(userId)!.size === 0) {
          connectedUsers.delete(userId);
        }
      }
      console.log(`User disconnected: ${socket.id}`);
    });

    // Handle errors
    socket.on('error', (error) => {
      console.error(`Socket error for ${socket.id}:`, error);
    });
  });

  return io;
}

/**
 * Send notification to user
 */
export async function sendNotification(
  io: SocketIOServer,
  userId: number,
  notification: Omit<Notification, 'userId' | 'timestamp' | 'id'>
): Promise<void> {
  const fullNotification: Notification = {
    ...notification,
    userId,
    timestamp: Date.now(),
    id: `notif_${userId}_${Date.now()}_${Math.random().toString(36).substring(7)}`,
  };

  // Store in history
  if (!notificationHistory.has(userId)) {
    notificationHistory.set(userId, []);
  }
  const history = notificationHistory.get(userId)!;
  history.push(fullNotification);
  if (history.length > MAX_HISTORY) {
    history.shift();
  }

  // Emit to user's sockets
  io.to(`user:${userId}`).emit('notification', fullNotification);

  // Publish to Redis for cross-server communication
  await publishMessage(`notifications:${userId}`, fullNotification);
}

/**
 * Broadcast notification to all connected users
 */
export async function broadcastNotification(
  io: SocketIOServer,
  notification: Omit<Notification, 'userId' | 'timestamp' | 'id'>
): Promise<void> {
  const fullNotification: Notification = {
    ...notification,
    userId: 0,
    timestamp: Date.now(),
    id: `broadcast_${Date.now()}_${Math.random().toString(36).substring(7)}`,
  };

  io.emit('notification', fullNotification);
  await publishMessage('notifications:broadcast', fullNotification);
}

/**
 * Send transcription status update
 */
export async function notifyTranscriptionStatus(
  io: SocketIOServer,
  userId: number,
  uploadId: number,
  status: 'started' | 'progress' | 'completed' | 'failed',
  data: any = {}
): Promise<void> {
  const typeMap = {
    started: 'transcription_started' as NotificationType,
    progress: 'transcription_progress' as NotificationType,
    completed: 'transcription_completed' as NotificationType,
    failed: 'transcription_failed' as NotificationType,
  };

  await sendNotification(io, userId, {
    type: typeMap[status],
    data: {
      uploadId,
      status,
      ...data,
    },
  });
}

/**
 * Send search update
 */
export async function notifySearchUpdate(
  io: SocketIOServer,
  userId: number,
  searchId: string,
  status: 'started' | 'completed',
  data: any = {}
): Promise<void> {
  await sendNotification(io, userId, {
    type: status === 'started' ? 'search_started' : 'search_completed',
    data: {
      searchId,
      status,
      ...data,
    },
  });
}

/**
 * Send system alert
 */
export async function sendSystemAlert(
  io: SocketIOServer,
  userId: number,
  message: string,
  severity: 'info' | 'warning' | 'error' = 'info'
): Promise<void> {
  await sendNotification(io, userId, {
    type: 'system_alert',
    data: {
      message,
      severity,
    },
  });
}

/**
 * Get user notification history
 */
export function getUserNotificationHistory(userId: number): Notification[] {
  return notificationHistory.get(userId) || [];
}

/**
 * Clear user notification history
 */
export function clearUserNotificationHistory(userId: number): void {
  notificationHistory.delete(userId);
}

/**
 * Get connected users count
 */
export function getConnectedUsersCount(): number {
  return connectedUsers.size;
}

/**
 * Get user socket count
 */
export function getUserSocketCount(userId: number): number {
  return connectedUsers.get(userId)?.size || 0;
}

/**
 * Check if user is online
 */
export function isUserOnline(userId: number): boolean {
  return connectedUsers.has(userId) && connectedUsers.get(userId)!.size > 0;
}

/**
 * Get all connected user IDs
 */
export function getConnectedUserIds(): number[] {
  return Array.from(connectedUsers.keys());
}

/**
 * Notify cache update
 */
export async function notifyCacheUpdate(
  io: SocketIOServer,
  userId: number,
  cacheStats: any
): Promise<void> {
  await sendNotification(io, userId, {
    type: 'cache_update',
    data: cacheStats,
  });
}
