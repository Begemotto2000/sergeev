/**
 * Mock Redis Client - Replaces redis package for production
 * This is a simple in-memory cache that mimics redis API
 */

interface RedisStore {
  [key: string]: any;
}

const store: RedisStore = {};
const lists: { [key: string]: any[] } = {};
const counters: { [key: string]: number } = {};

export const createClient = () => {
  return {
    connect: async () => {},
    disconnect: async () => {},
    get: async (key: string) => store[key] || null,
    set: async (key: string, value: any, options?: any) => {
      store[key] = value;
      if (options?.EX) {
        setTimeout(() => delete store[key], options.EX * 1000);
      }
    },
    del: async (key: string) => {
      delete store[key];
      return 1;
    },
    exists: async (key: string) => (key in store ? 1 : 0),
    incr: async (key: string) => {
      counters[key] = (counters[key] || 0) + 1;
      return counters[key];
    },
    decr: async (key: string) => {
      counters[key] = (counters[key] || 0) - 1;
      return counters[key];
    },
    incrBy: async (key: string, increment: number) => {
      counters[key] = (counters[key] || 0) + increment;
      return counters[key];
    },
    decrBy: async (key: string, decrement: number) => {
      counters[key] = (counters[key] || 0) - decrement;
      return counters[key];
    },
    lpush: async (key: string, ...values: any[]) => {
      if (!lists[key]) lists[key] = [];
      lists[key].unshift(...values);
      return lists[key].length;
    },
    rpush: async (key: string, ...values: any[]) => {
      if (!lists[key]) lists[key] = [];
      lists[key].push(...values);
      return lists[key].length;
    },
    lpop: async (key: string) => {
      if (!lists[key]) return null;
      return lists[key].shift() || null;
    },
    rpop: async (key: string) => {
      if (!lists[key]) return null;
      return lists[key].pop() || null;
    },
    lrange: async (key: string, start: number, stop: number) => {
      if (!lists[key]) return [];
      return lists[key].slice(start, stop + 1);
    },
    llen: async (key: string) => {
      return lists[key]?.length || 0;
    },
    publish: async (channel: string, message: any) => {
      return 0;
    },
    subscribe: async (channel: string) => {},
    unsubscribe: async (channel: string) => {},
    on: (event: string, callback: Function) => {},
    flushAll: async () => {
      Object.keys(store).forEach(key => delete store[key]);
      Object.keys(lists).forEach(key => delete lists[key]);
      Object.keys(counters).forEach(key => delete counters[key]);
    },
  };
};

export default {
  createClient,
};
