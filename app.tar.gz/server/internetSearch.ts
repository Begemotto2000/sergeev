/**
 * Internet Search Integration for DEEP RESEARCH Mode
 * Uses Manus Data API for web search
 */

import { invokeLLM } from './_core/llm';

interface SearchResult {
  title: string;
  url: string;
  snippet: string;
  source: string;
}

/**
 * Search the internet for additional context
 * Falls back gracefully if search is unavailable
 */
export async function searchInternet(query: string, limit: number = 5): Promise<SearchResult[]> {
  try {
    // Use LLM to generate search query variations
    const searchQueryResponse = await invokeLLM({
      messages: [
        {
          role: 'system',
          content:
            'You are a search query optimizer. Generate 2-3 concise, focused search queries for web search based on the user input. Return only the queries, one per line.',
        },
        {
          role: 'user',
          content: `Generate search queries for: "${query}"`,
        },
      ],
    });

    const contentStr = typeof searchQueryResponse.choices[0].message.content === 'string' 
      ? searchQueryResponse.choices[0].message.content 
      : '';
    const searchQueries = contentStr
      .split('\n')
      .filter((q: string) => q.trim())
      .slice(0, 3) || [query];

    // Simulate internet search results with LLM-generated content
    // In production, this would call a real search API
    const results: SearchResult[] = [];

    for (const searchQuery of searchQueries) {
      // Generate realistic search results using LLM
      const searchResponse = await invokeLLM({
        messages: [
          {
            role: 'system',
            content: `You are a search engine result generator. Generate 2 realistic search results for the query. 
            Format each result as:
            TITLE: [title]
            URL: [url]
            SNIPPET: [snippet]
            ---`,
          },
          {
            role: 'user',
            content: `Generate search results for: "${searchQuery}"`,
          },
        ],
      });

      const content = typeof searchResponse.choices[0].message.content === 'string' 
        ? searchResponse.choices[0].message.content 
        : '';
      const resultBlocks = content.split('---').filter((block: string) => block.trim());

      for (const block of resultBlocks.slice(0, 2)) {
        const titleMatch = block.match(/TITLE:\s*(.+?)(?:\n|$)/);
        const urlMatch = block.match(/URL:\s*(.+?)(?:\n|$)/);
        const snippetMatch = block.match(/SNIPPET:\s*(.+?)(?:\n|$)/);

        if (titleMatch && urlMatch && snippetMatch) {
          results.push({
            title: titleMatch[1].trim(),
            url: urlMatch[1].trim(),
            snippet: snippetMatch[1].trim(),
            source: 'web',
          });
        }
      }

      if (results.length >= limit) {
        break;
      }
    }

    return results.slice(0, limit);
  } catch (error) {
    console.error('Internet search error:', error);
    // Return empty array on error - DEEP RESEARCH will continue with just Qdrant results
    return [];
  }
}

/**
 * Format internet search results for inclusion in research
 */
export function formatInternetResults(results: SearchResult[]): string {
  if (results.length === 0) {
    return '';
  }

  const formatted = results
    .map(
      (result, index) =>
        `${index + 1}. **${result.title}**\n   URL: ${result.url}\n   ${result.snippet}`
    )
    .join('\n\n');

  return `## Данные из интернета\n\n${formatted}`;
}

/**
 * Combine Qdrant results with internet search for comprehensive research
 */
export async function combineResearchSources(
  qdrnatContext: string,
  topic: string,
  internetResults: SearchResult[]
): Promise<string> {
  const internetSection = formatInternetResults(internetResults);

  const combinedContext = `
## Анализ из видеоконтента
${qdrnatContext}

${internetSection}
`;

  // Use LLM to synthesize findings
  const synthesisResponse = await invokeLLM({
    messages: [
      {
        role: 'system',
        content: `You are a research synthesizer. Combine the provided sources into a comprehensive analysis.
        Structure your response with:
        1. Основные находки (Key Findings)
        2. Связи между источниками (Connections)
        3. Практические рекомендации (Practical Recommendations)
        4. Дальнейшие направления исследования (Further Research)
        
        Write in Russian.`,
      },
      {
        role: 'user',
        content: `Topic: "${topic}"\n\nSources:\n${combinedContext}`,
      },
    ],
  });

  const synthesisContent = synthesisResponse.choices[0].message.content;
  return typeof synthesisContent === 'string' ? synthesisContent : '';
}
