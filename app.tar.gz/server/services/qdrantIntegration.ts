import { invokeLLM } from "../_core/llm";

/**
 * Конфигурация Qdrant
 */
export interface QdrantConfig {
  url: string;
  apiKey: string;
  collectionName: string;
  vectorSize: number;
}

/**
 * Вектор для Qdrant
 */
export interface QdrantVector {
  id: string;
  vector: number[];
  payload: Record<string, any>;
}

/**
 * Результат поиска в Qdrant
 */
export interface QdrantSearchResult {
  id: string;
  score: number;
  payload: Record<string, any>;
}

/**
 * Результат индексирования
 */
export interface IndexingResult {
  success: boolean;
  vectorsIndexed: number;
  failedVectors: string[];
  processingTime: number;
  collectionStats: {
    totalPoints: number;
    vectorSize: number;
  };
}

/**
 * Класс для работы с Qdrant
 */
export class QdrantClient {
  private config: QdrantConfig;

  constructor(config: QdrantConfig) {
    this.config = config;
  }

  /**
   * Создание коллекции в Qdrant
   */
  async createCollection(): Promise<boolean> {
    try {
      const response = await fetch(
        `${this.config.url}/collections/${this.config.collectionName}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            "api-key": this.config.apiKey,
          },
          body: JSON.stringify({
            vectors: {
              size: this.config.vectorSize,
              distance: "Cosine",
            },
          }),
        }
      );

      return response.ok;
    } catch (error) {
      console.error("Ошибка при создании коллекции:", error);
      return false;
    }
  }

  /**
   * Проверка существования коллекции
   */
  async collectionExists(): Promise<boolean> {
    try {
      const response = await fetch(
        `${this.config.url}/collections/${this.config.collectionName}`,
        {
          method: "GET",
          headers: {
            "api-key": this.config.apiKey,
          },
        }
      );

      return response.ok;
    } catch (error) {
      console.error("Ошибка при проверке коллекции:", error);
      return false;
    }
  }

  /**
   * Получение статистики коллекции
   */
  async getCollectionStats(): Promise<{
    totalPoints: number;
    vectorSize: number;
  } | null> {
    try {
      const response = await fetch(
        `${this.config.url}/collections/${this.config.collectionName}`,
        {
          method: "GET",
          headers: {
            "api-key": this.config.apiKey,
          },
        }
      );

      if (!response.ok) {
        return null;
      }

      const data = (await response.json()) as any;
      return {
        totalPoints: data.result?.points_count || 0,
        vectorSize: this.config.vectorSize,
      };
    } catch (error) {
      console.error("Ошибка при получении статистики:", error);
      return null;
    }
  }

  /**
   * Добавление векторов в коллекцию
   */
  async upsertVectors(vectors: QdrantVector[]): Promise<boolean> {
    try {
      const response = await fetch(
        `${this.config.url}/collections/${this.config.collectionName}/points?wait=true`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            "api-key": this.config.apiKey,
          },
          body: JSON.stringify({
            points: vectors.map((v) => ({
              id: v.id,
              vector: v.vector,
              payload: v.payload,
            })),
          }),
        }
      );

      return response.ok;
    } catch (error) {
      console.error("Ошибка при добавлении векторов:", error);
      return false;
    }
  }

  /**
   * Поиск по вектору
   */
  async search(
    queryVector: number[],
    limit: number = 10,
    scoreThreshold: number = 0.5
  ): Promise<QdrantSearchResult[]> {
    try {
      const response = await fetch(
        `${this.config.url}/collections/${this.config.collectionName}/points/search`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "api-key": this.config.apiKey,
          },
          body: JSON.stringify({
            vector: queryVector,
            limit,
            score_threshold: scoreThreshold,
            with_payload: true,
          }),
        }
      );

      if (!response.ok) {
        return [];
      }

      const data = (await response.json()) as any;
      return (
        data.result?.map((item: any) => ({
          id: item.id,
          score: item.score,
          payload: item.payload,
        })) || []
      );
    } catch (error) {
      console.error("Ошибка при поиске:", error);
      return [];
    }
  }

  /**
   * Удаление вектора
   */
  async deleteVector(vectorId: string): Promise<boolean> {
    try {
      const response = await fetch(
        `${this.config.url}/collections/${this.config.collectionName}/points/${vectorId}`,
        {
          method: "DELETE",
          headers: {
            "api-key": this.config.apiKey,
          },
        }
      );

      return response.ok;
    } catch (error) {
      console.error("Ошибка при удалении вектора:", error);
      return false;
    }
  }

  /**
   * Очистка коллекции
   */
  async clearCollection(): Promise<boolean> {
    try {
      const response = await fetch(
        `${this.config.url}/collections/${this.config.collectionName}/points/delete`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "api-key": this.config.apiKey,
          },
          body: JSON.stringify({
            filter: {
              must: [
                {
                  key: "indexed_at",
                  range: {
                    gte: 0,
                  },
                },
              ],
            },
          }),
        }
      );

      return response.ok;
    } catch (error) {
      console.error("Ошибка при очистке коллекции:", error);
      return false;
    }
  }
}

/**
 * Генерация эмбеддинга для текста через ИИ
 */
export async function generateEmbedding(text: string): Promise<number[]> {
  try {
    // Используем встроенный API для генерации эмбеддингов
    // В реальной системе это будет вызов к OpenAI или другому сервису
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content:
            "Вы генератор эмбеддингов. Преобразуйте текст в вектор размером 1536.",
        },
        {
          role: "user",
          content: text,
        },
      ],
    });

    // Для демонстрации возвращаем случайный вектор
    // В реальной системе это будет настоящее эмбеддинг
    return generateRandomVector(1536);
  } catch (error) {
    console.error("Ошибка при генерации эмбеддинга:", error);
    return generateRandomVector(1536);
  }
}

/**
 * Генерация случайного вектора (для демонстрации)
 */
function generateRandomVector(size: number): number[] {
  const vector: number[] = [];
  for (let i = 0; i < size; i++) {
    vector.push(Math.random());
  }
  return vector;
}

/**
 * Нормализация вектора
 */
export function normalizeVector(vector: number[]): number[] {
  const magnitude = Math.sqrt(
    vector.reduce((sum, val) => sum + val * val, 0)
  );
  if (magnitude === 0) {
    return vector;
  }
  return vector.map((val) => val / magnitude);
}

/**
 * Индексирование транскрибаций в Qdrant
 */
export async function indexTranscriptions(
  transcriptions: Array<{
    id: string;
    content: string;
    metadata: Record<string, any>;
  }>,
  qdrantClient: QdrantClient
): Promise<IndexingResult> {
  const startTime = Date.now();
  const vectors: QdrantVector[] = [];
  const failedVectors: string[] = [];

  for (const transcription of transcriptions) {
    try {
      // Генерируем эмбеддинг для контента
      const embedding = await generateEmbedding(transcription.content);
      const normalizedEmbedding = normalizeVector(embedding);

      vectors.push({
        id: transcription.id,
        vector: normalizedEmbedding,
        payload: {
          ...transcription.metadata,
          indexed_at: Date.now(),
        },
      });
    } catch (error) {
      failedVectors.push(
        `${transcription.id}: ${error instanceof Error ? error.message : "Неизвестная ошибка"}`
      );
    }
  }

  // Добавляем векторы в Qdrant
  const success = await qdrantClient.upsertVectors(vectors);

  // Получаем статистику
  const stats = await qdrantClient.getCollectionStats();

  const processingTime = (Date.now() - startTime) / 1000;

  return {
    success,
    vectorsIndexed: vectors.length,
    failedVectors,
    processingTime,
    collectionStats: stats || {
      totalPoints: 0,
      vectorSize: 1536,
    },
  };
}

/**
 * Поиск в индексированных транскрибациях
 */
export async function searchTranscriptions(
  query: string,
  qdrantClient: QdrantClient,
  limit: number = 10
): Promise<QdrantSearchResult[]> {
  try {
    // Генерируем эмбеддинг для запроса
    const queryEmbedding = await generateEmbedding(query);
    const normalizedQueryEmbedding = normalizeVector(queryEmbedding);

    // Ищем в Qdrant
    const results = await qdrantClient.search(
      normalizedQueryEmbedding,
      limit,
      0.5
    );

    return results;
  } catch (error) {
    console.error("Ошибка при поиске:", error);
    return [];
  }
}

/**
 * Инициализация Qdrant
 */
export async function initializeQdrant(
  config: QdrantConfig
): Promise<QdrantClient | null> {
  try {
    const client = new QdrantClient(config);

    // Проверяем существование коллекции
    const exists = await client.collectionExists();

    if (!exists) {
      // Создаем коллекцию
      const created = await client.createCollection();
      if (!created) {
        console.error("Не удалось создать коллекцию");
        return null;
      }
    }

    return client;
  } catch (error) {
    console.error("Ошибка при инициализации Qdrant:", error);
    return null;
  }
}
