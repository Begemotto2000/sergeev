/**
 * Тесты для поиска в Qdrant
 * PZ-033: Тестирование поиска и качества результатов
 */

import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { QdrantClient } from "./qdrantIntegration";
import { ArchiveIndexingService } from "./archiveIndexingService";

describe("Qdrant Search Tests", () => {
  let qdrantClient: QdrantClient;
  let indexingService: ArchiveIndexingService;

  beforeAll(() => {
    // Инициализировать Qdrant клиент
    qdrantClient = new QdrantClient({
      url: process.env.QDRANT_URL || "http://localhost:6333",
      apiKey: process.env.QDRANT_API_KEY || "",
      collectionName: "mentorstvo_chunks_test",
      vectorSize: 384,
    });

    indexingService = new ArchiveIndexingService(qdrantClient);
  });

  afterAll(() => {
    // Очистить кэш
    indexingService.clearCache();
  });

  it("should create collection successfully", async () => {
    const created = await qdrantClient.createCollection();
    expect(created).toBe(true);
  });

  it("should check if collection exists", async () => {
    const exists = await qdrantClient.collectionExists();
    expect(exists).toBe(true);
  });

  it("should get collection stats", async () => {
    const stats = await qdrantClient.getCollectionStats();
    expect(stats).not.toBeNull();
    expect(stats?.vectorSize).toBe(384);
  });

  it("should index sample chunks", async () => {
    const sampleChunks = [
      {
        text: "Друзья, всех приветствую, и сейчас мы начинаем модуль 1 по менторству",
        timecode: "00:00 - 00:42",
        start_time: "00:00",
        end_time: "00:42",
        word_count: 12,
        char_count: 70,
        duration_sec: 42,
        source: {
          type: "МЕНТОРСТВО",
          module: 1,
          lesson: 1,
          title: "Техничка для подготовки",
          filename: "МЕНТОРСТВО - М01 Урок 1",
        },
      },
      {
        text: "В этом уроке мы разберём основные концепции и принципы работы",
        timecode: "00:42 - 01:30",
        start_time: "00:42",
        end_time: "01:30",
        word_count: 11,
        char_count: 62,
        duration_sec: 48,
        source: {
          type: "МЕНТОРСТВО",
          module: 1,
          lesson: 1,
          title: "Техничка для подготовки",
          filename: "МЕНТОРСТВО - М01 Урок 1",
        },
      },
    ];

    const result = await indexingService.indexArchive({
      archiveId: "TEST_ARCHIVE",
      chunks: sampleChunks,
      batchSize: 10,
    });

    expect(result.success).toBe(true);
    expect(result.vectorsIndexed).toBe(2);
    expect(result.failedVectors.length).toBe(0);
  });

  it("should search for similar vectors", async () => {
    // Создать тестовый вектор
    const testVector = Array.from({ length: 384 }, () =>
      Math.random() * 2 - 1
    );

    const results = await qdrantClient.search(testVector, 5, 0.3);

    expect(Array.isArray(results)).toBe(true);
    // Результаты могут быть пустыми или содержать векторы
    if (results.length > 0) {
      expect(results[0]).toHaveProperty("id");
      expect(results[0]).toHaveProperty("score");
      expect(results[0]).toHaveProperty("payload");
    }
  });

  it("should handle empty search results gracefully", async () => {
    // Создать очень отличающийся вектор
    const randomVector = Array.from({ length: 384 }, () => 1);

    const results = await qdrantClient.search(randomVector, 5, 0.99);

    expect(Array.isArray(results)).toBe(true);
    // Результаты должны быть пустыми или содержать мало элементов
    expect(results.length).toBeLessThanOrEqual(5);
  });

  it("should validate search result structure", async () => {
    const testVector = Array.from({ length: 384 }, () =>
      Math.random() * 2 - 1
    );

    const results = await qdrantClient.search(testVector, 1, 0.3);

    if (results.length > 0) {
      const result = results[0];

      // Проверить структуру результата
      expect(result).toHaveProperty("id");
      expect(result).toHaveProperty("score");
      expect(result).toHaveProperty("payload");

      // Проверить типы
      expect(typeof result.id).toBe("string");
      expect(typeof result.score).toBe("number");
      expect(typeof result.payload).toBe("object");

      // Проверить payload
      if (result.payload) {
        expect(result.payload).toHaveProperty("text");
        expect(result.payload).toHaveProperty("timecode");
      }
    }
  });

  it("should handle batch uploads correctly", async () => {
    const vectors = [];
    for (let i = 0; i < 10; i++) {
      vectors.push({
        id: `test_vector_${i}`,
        vector: Array.from({ length: 384 }, () => Math.random() * 2 - 1),
        payload: {
          text: `Test chunk ${i}`,
          timecode: `00:${i * 5} - 00:${(i + 1) * 5}`,
          index: i,
        },
      });
    }

    const uploaded = await qdrantClient.upsertVectors(vectors);
    expect(uploaded).toBe(true);
  });

  it("should clear cache without errors", () => {
    expect(() => {
      indexingService.clearCache();
    }).not.toThrow();
  });
});

describe("Search Quality Tests", () => {
  let qdrantClient: QdrantClient;

  beforeAll(() => {
    qdrantClient = new QdrantClient({
      url: process.env.QDRANT_URL || "http://localhost:6333",
      apiKey: process.env.QDRANT_API_KEY || "",
      collectionName: "mentorstvo_chunks_test",
      vectorSize: 384,
    });
  });

  it("should return results with reasonable scores", async () => {
    const testVector = Array.from({ length: 384 }, () =>
      Math.random() * 2 - 1
    );

    const results = await qdrantClient.search(testVector, 10, 0.3);

    // Проверить, что оценки в разумном диапазоне
    results.forEach((result) => {
      expect(result.score).toBeGreaterThanOrEqual(0.3);
      expect(result.score).toBeLessThanOrEqual(1);
    });
  });

  it("should respect limit parameter", async () => {
    const testVector = Array.from({ length: 384 }, () =>
      Math.random() * 2 - 1
    );

    const results = await qdrantClient.search(testVector, 3, 0.3);

    expect(results.length).toBeLessThanOrEqual(3);
  });

  it("should respect score threshold", async () => {
    const testVector = Array.from({ length: 384 }, () =>
      Math.random() * 2 - 1
    );

    const results = await qdrantClient.search(testVector, 100, 0.8);

    results.forEach((result) => {
      expect(result.score).toBeGreaterThanOrEqual(0.8);
    });
  });
});
