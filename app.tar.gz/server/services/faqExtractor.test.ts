import { describe, it, expect } from "vitest";
import { generateFAQId, validateFAQPair } from "./faqExtractor";

/**
 * FAQ Extractor Service Tests
 * PZ-031: FAQ/ЧаВо раздел
 */

describe("FAQ Extractor Service", () => {
  // ============ FAQ ID GENERATION TESTS ============

  it("should generate valid FAQ ID", () => {
    const id = generateFAQId(1, 1, "ТЕХНИКА");
    expect(id).toMatch(/^FAQ-\d{3}-\d{6}-[А-ЯЁ]+-[А-ЯЁ\s]+$/);
  });

  it("should generate sequential FAQ IDs", () => {
    const id1 = generateFAQId(1, 1, "ТЕХНИКА");
    const id2 = generateFAQId(1, 2, "ТЕХНИКА");

    // Extract numbers from IDs
    const num1 = parseInt(id1.split("-")[2]);
    const num2 = parseInt(id2.split("-")[2]);

    expect(num2).toBeGreaterThan(num1);
  });

  it("should include category in FAQ ID", () => {
    const id = generateFAQId(1, 1, "ТЕХНИКА");
    expect(id).toContain("ТЕХНИКА");
  });

  // ============ PAIR VALIDATION TESTS ============

  it("should validate good FAQ pair", () => {
    const pair = {
      question: "Как правильно снимать видео?",
      answer: "Используйте хорошее освещение, микрофон и стабилизатор...",
      category: "ТЕХНИКА",
      confidence: 0.95,
    };

    const result = validateFAQPair(pair);
    expect(result.isValid).toBe(true);
    expect(result.score).toBeGreaterThan(0.7);
  });

  it("should reject pair with short question", () => {
    const pair = {
      question: "Как?",
      answer: "Используйте хорошее освещение...",
      category: "ТЕХНИКА",
      confidence: 0.5,
    };

    const result = validateFAQPair(pair);
    expect(result.isValid).toBe(false);
  });

  it("should reject pair with short answer", () => {
    const pair = {
      question: "Как правильно снимать видео?",
      answer: "Хорошо",
      category: "ТЕХНИКА",
      confidence: 0.5,
    };

    const result = validateFAQPair(pair);
    expect(result.isValid).toBe(false);
  });

  it("should reject pair with low confidence", () => {
    const pair = {
      question: "Как правильно снимать видео?",
      answer: "Используйте хорошее освещение...",
      category: "ТЕХНИКА",
      confidence: 0.2,
    };

    const result = validateFAQPair(pair);
    expect(result.isValid).toBe(false);
  });

  // ============ PATTERN MATCHING TESTS ============

  it("should detect Q&A pattern", () => {
    const text = "Вопрос: Как снимать видео? Ответ: Используйте хорошее освещение.";
    const pattern = /Вопрос:\s*(.+?)\s*Ответ:\s*(.+?)(?=Вопрос:|$)/gs;
    const matches = Array.from(text.matchAll(pattern));

    expect(matches.length).toBeGreaterThan(0);
    expect(matches[0][1]).toContain("Как снимать видео");
  });

  it("should detect Student-Master pattern", () => {
    const text = "Ученик: Как работает Instagram? Мастер: Instagram - это социальная сеть...";
    const pattern = /Ученик:\s*(.+?)\s*(?:Мастер|Наставник):\s*(.+?)(?=Ученик:|$)/gs;
    const matches = Array.from(text.matchAll(pattern));

    expect(matches.length).toBeGreaterThan(0);
  });

  // ============ CATEGORIZATION TESTS ============

  it("should categorize ТЕХНИКА questions", () => {
    const questions = [
      "Как выбрать камеру?",
      "Какой микрофон лучше?",
      "Как настроить свет?",
    ];

    const categoryKeywords = {
      ТЕХНИКА: ["камера", "микрофон", "свет", "видео", "оборудование"],
    };

    questions.forEach((q) => {
      const found = categoryKeywords.ТЕХНИКА.some((keyword) =>
        q.toLowerCase().includes(keyword)
      );
      expect(found).toBe(true);
    });
  });

  it("should categorize INSTAGRAM questions", () => {
    const questions = [
      "Как снимать Reels?",
      "Как работают Stories?",
      "Как получить больше подписчиков?",
    ];

    const categoryKeywords = {
      INSTAGRAM: ["instagram", "reels", "stories", "подписчики", "лайки"],
    };

    questions.forEach((q) => {
      const found = categoryKeywords.INSTAGRAM.some((keyword) =>
        q.toLowerCase().includes(keyword)
      );
      expect(found).toBe(true);
    });
  });

  // ============ DEDUPLICATION TESTS ============

  it("should detect duplicate pairs", () => {
    const pairs = [
      {
        question: "Как снимать видео?",
        answer: "Используйте хорошее освещение...",
      },
      {
        question: "Как правильно снимать видео?",
        answer: "Используйте хорошее освещение и микрофон...",
      },
    ];

    // Simple similarity check (in production, use more sophisticated methods)
    const q1Lower = pairs[0].question.toLowerCase();
    const q2Lower = pairs[1].question.toLowerCase();

    const similarity =
      q1Lower.split(" ").filter((word) => q2Lower.includes(word)).length /
      Math.max(q1Lower.split(" ").length, q2Lower.split(" ").length);

    expect(similarity).toBeGreaterThan(0.5); // Similar questions
  });

  // ============ CHUNKING TESTS ============

  it("should chunk text correctly", () => {
    const text = "word ".repeat(2500); // 2500 words
    const chunkSize = 2000;
    const chunks: string[] = [];

    let currentChunk = "";
    const words = text.split(" ");

    words.forEach((word) => {
      if ((currentChunk + word).split(" ").length > chunkSize) {
        chunks.push(currentChunk);
        currentChunk = word;
      } else {
        currentChunk += word + " ";
      }
    });

    if (currentChunk) chunks.push(currentChunk);

    expect(chunks.length).toBeGreaterThan(1);
    chunks.forEach((chunk) => {
      expect(chunk.split(" ").length).toBeLessThanOrEqual(chunkSize + 1);
    });
  });

  // ============ EXTRACTION STATISTICS TESTS ============

  it("should calculate extraction statistics", () => {
    const results = {
      totalPairs: 50,
      validPairs: 45,
      duplicates: 3,
      errors: 2,
    };

    const successRate = (results.validPairs / results.totalPairs) * 100;
    expect(successRate).toBeGreaterThan(80);
    expect(results.totalPairs).toBe(
      results.validPairs + results.duplicates + results.errors
    );
  });

  // ============ ERROR HANDLING TESTS ============

  it("should handle empty text", () => {
    const text = "";
    expect(text.length).toBe(0);
    expect(() => {
      if (!text || text.trim().length === 0) {
        throw new Error("Text is empty");
      }
    }).toThrow("Text is empty");
  });

  it("should handle text without pairs", () => {
    const text = "This is just regular text without any Q&A pairs.";
    const pattern = /Вопрос:\s*(.+?)\s*Ответ:\s*(.+?)(?=Вопрос:|$)/gs;
    const matches = Array.from(text.matchAll(pattern));

    expect(matches.length).toBe(0);
  });

  // ============ CONFIDENCE SCORING TESTS ============

  it("should calculate confidence score", () => {
    const pair = {
      question: "Как правильно снимать видео?",
      answer: "Используйте хорошее освещение, микрофон и стабилизатор...",
      patternMatch: 0.9,
      categoryMatch: 0.95,
      lengthScore: 1.0,
    };

    const confidence =
      (pair.patternMatch + pair.categoryMatch + pair.lengthScore) / 3;
    expect(confidence).toBeGreaterThan(0.8);
    expect(confidence).toBeLessThanOrEqual(1.0);
  });
});
