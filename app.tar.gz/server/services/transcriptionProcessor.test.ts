import { describe, it, expect } from "vitest";
import {
  validateTranscription,
  cleanAndNormalizeText,
  splitIntoChunks,
  MaterialType,
  MaterialCategory,
  TranscriptionMetadata,
} from "./transcriptionProcessor";

describe("TranscriptionProcessor", () => {
  describe("validateTranscription", () => {
    it("должен отклонить пустой текст", async () => {
      const result = await validateTranscription("", "video");
      expect(result.isValid).toBe(false);
      expect(result.errors).toContain("Текст пуст");
    });

    it("должен отклонить текст с менее чем 50 словами", async () => {
      const shortText = "Это очень короткий текст";
      const result = await validateTranscription(shortText, "video");
      expect(result.isValid).toBe(false);
      expect(result.errors[0]).toContain("Минимум 50 слов");
    });

    it("должен принять валидный текст", async () => {
      const validText =
        "Это длинный текст с достаточным количеством слов для валидации. " +
        "Он содержит информацию о различных аспектах цифрового маркетинга. " +
        "Текст должен быть достаточно большим для прохождения валидации. " +
        "Давайте добавим еще слов чтобы убедиться что все работает правильно. " +
        "Это очень важная информация для нашей системы обработки транскрибаций.";

      const result = await validateTranscription(validText, "video");
      expect(result.isValid).toBe(true);
      expect(result.errors).toHaveLength(0);
      expect(result.stats.wordCount).toBeGreaterThan(50);
    });

    it("должен подсчитать количество слов", async () => {
      const text = "Слово1 слово2 слово3 слово4 слово5 ".repeat(20);
      const result = await validateTranscription(text, "video");
      expect(result.stats.wordCount).toBeGreaterThan(0);
    });

    it("должен подсчитать время чтения", async () => {
      const text = "Слово ".repeat(500); // 500 слов
      const result = await validateTranscription(text, "video");
      expect(result.stats.estimatedReadingTime).toBeGreaterThan(0);
      expect(result.stats.estimatedReadingTime).toBeLessThan(10);
    });
  });

  describe("cleanAndNormalizeText", () => {
    it("должен удалить лишние пробелы", () => {
      const text = "Это   текст   с    лишними    пробелами";
      const cleaned = cleanAndNormalizeText(text);
      expect(cleaned).toBe("Это текст с лишними пробелами");
    });

    it("должен нормализовать кавычки", () => {
      const text = '"Текст в кавычках" и 'текст в апострофах'';
      const cleaned = cleanAndNormalizeText(text);
      expect(cleaned).toContain('"');
      expect(cleaned).toContain("'");
    });

    it("должен удалить дублирующуюся пунктуацию", () => {
      const text = "Это текст!!!!! С множественной пунктуацией????";
      const cleaned = cleanAndNormalizeText(text);
      expect(cleaned).toContain("!");
      expect(cleaned).not.toContain("!!!!!");
    });

    it("должен обработать контрольные символы", () => {
      const text = "Текст\x00с\x01контрольными\x02символами";
      const cleaned = cleanAndNormalizeText(text);
      expect(cleaned).not.toContain("\x00");
      expect(cleaned).not.toContain("\x01");
    });

    it("должен нормализовать переносы строк", () => {
      const text = "Строка1\r\nСтрока2\rСтрока3";
      const cleaned = cleanAndNormalizeText(text);
      expect(cleaned).toContain("\n");
    });
  });

  describe("splitIntoChunks", () => {
    it("должен разбить текст на чанки", () => {
      const text = "слово ".repeat(2500); // 2500 слов
      const chunks = splitIntoChunks(text, 2000);
      expect(chunks.length).toBeGreaterThan(1);
    });

    it("должен создать чанк размером не более чем указано", () => {
      const text = "слово ".repeat(5000);
      const chunks = splitIntoChunks(text, 1000);

      chunks.forEach((chunk) => {
        const wordCount = chunk.split(/\s+/).length;
        expect(wordCount).toBeLessThanOrEqual(1000);
      });
    });

    it("должен сохранить все слова", () => {
      const text = "слово ".repeat(1000);
      const chunks = splitIntoChunks(text, 500);
      const joinedChunks = chunks.join(" ");

      expect(joinedChunks).toContain("слово");
    });

    it("должен обработать маленький текст", () => {
      const text = "Маленький текст";
      const chunks = splitIntoChunks(text, 2000);
      expect(chunks.length).toBe(1);
      expect(chunks[0]).toBe(text);
    });

    it("должен использовать размер чанка по умолчанию", () => {
      const text = "слово ".repeat(3000);
      const chunks = splitIntoChunks(text);
      expect(chunks.length).toBeGreaterThan(1);
    });
  });

  describe("Интеграция", () => {
    it("должен обработать полный цикл валидации и очистки", async () => {
      const rawText =
        "Это   текст!!!!! С   лишними   пробелами   и   пунктуацией. " +
        "Содержит информацию о маркетинге и Instagram. " +
        "Это очень важный контент для нашей базы знаний. " +
        "Давайте добавим еще текста чтобы пройти валидацию. " +
        "Текст должен быть достаточно большим для работы системы. " +
        "Это критически важная информация для обработки.";

      const validation = await validateTranscription(rawText, "video");
      expect(validation.isValid).toBe(true);

      const cleaned = cleanAndNormalizeText(rawText);
      expect(cleaned).not.toContain("!!!!!");
      expect(cleaned).not.toContain("   ");
    });

    it("должен обработать различные типы материалов", async () => {
      const types: MaterialType[] = ["video", "chat", "breakdown", "material"];
      const text = "слово ".repeat(100);

      for (const type of types) {
        const result = await validateTranscription(text, type);
        expect(result.isValid).toBe(true);
      }
    });
  });
});
