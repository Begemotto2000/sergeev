import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { TranscriptionProcessor } from "./transcriptionProcessor";
import { QdrantClient, indexTranscriptions } from "./qdrantIntegration";
import { KnowledgeOrganizer } from "./knowledgeOrganizer";

/**
 * Интеграционные тесты для проверки готовности Базы Знаний
 */
describe("Knowledge Base Integration Tests", () => {
  let processor: TranscriptionProcessor;
  let organizer: KnowledgeOrganizer;

  beforeAll(() => {
    processor = new TranscriptionProcessor();
    organizer = new KnowledgeOrganizer({
      autoOrganize: true,
      maxItemsPerShelf: 1000,
      minConfidenceThreshold: 0.5,
    });
  });

  afterAll(() => {
    organizer.clearAllShelves();
  });

  describe("Полный pipeline обработки транскрибаций", () => {
    it("должен обработать транскрибацию видео", async () => {
      const transcription = {
        id: "video-001",
        content:
          "Это видео о технике Instagram. Вот основные моменты: 1. Использование хэштегов, 2. Качество контента, 3. Время публикации. Все это влияет на охват.",
        type: "video" as const,
        source: "https://youtube.com/watch?v=xxx",
        metadata: {
          title: "Техника Instagram",
          duration: 3600,
          timestamp: "00:15:30",
        },
      };

      const result = await processor.processTranscription(transcription);

      expect(result.success).toBe(true);
      expect(result.chunks.length).toBeGreaterThan(0);
      expect(result.metadata.type).toBe("video");
      expect(result.metadata.category).toBeDefined();
    });

    it("должен обработать транскрибацию чата", async () => {
      const transcription = {
        id: "chat-001",
        content:
          "Ученик: Как увеличить охват? Мастер: Используйте хэштеги и публикуйте в оптимальное время. Ученик: Спасибо! Мастер: Пожалуйста!",
        type: "chat" as const,
        source: "telegram-archive",
        metadata: {
          title: "Чат с учениками",
          date: "2026-05-08",
        },
      };

      const result = await processor.processTranscription(transcription);

      expect(result.success).toBe(true);
      expect(result.chunks.length).toBeGreaterThan(0);
    });

    it("должен обработать транскрибацию разбора", async () => {
      const transcription = {
        id: "breakdown-001",
        content:
          "Разбор кейса: Клиент хотел увеличить продажи. Решение: Мы создали воронку с 5 этапами. Результат: Продажи выросли на 300%.",
        type: "breakdown" as const,
        source: "zoom-recording",
        metadata: {
          title: "Разбор кейса продаж",
          date: "2026-05-07",
        },
      };

      const result = await processor.processTranscription(transcription);

      expect(result.success).toBe(true);
      expect(result.metadata.category).toBeDefined();
    });
  });

  describe("Категоризация и организация", () => {
    it("должен создать полку для видео по технике", () => {
      const shelf = organizer.createShelf("техника", "video", "Видео о технике");

      expect(shelf).toBeDefined();
      expect(shelf.category).toBe("техника");
      expect(shelf.type).toBe("video");
      expect(shelf.items.length).toBe(0);
    });

    it("должен добавить элемент на полку", () => {
      const shelf = organizer.createShelf("техника", "video");

      const item = {
        id: "item-001",
        title: "Основы Instagram",
        content: "Это видео о основах Instagram",
        source: "youtube",
        tags: ["instagram", "техника"],
        confidence: 0.95,
        indexedAt: new Date(),
      };

      const result = organizer.addItemToShelf(shelf.id, item);

      expect(result.success).toBe(true);
      expect(shelf.items.length).toBe(1);
    });

    it("должен получить полки по категории", () => {
      organizer.createShelf("техника", "video");
      organizer.createShelf("техника", "chat");
      organizer.createShelf("instagram", "video");

      const shelvesForTechnika = organizer.getShelvesByCategory("техника");

      expect(shelvesForTechnika.length).toBe(2);
      expect(shelvesForTechnika.every((s) => s.category === "техника")).toBe(
        true
      );
    });

    it("должен получить полки по типу", () => {
      organizer.createShelf("техника", "video");
      organizer.createShelf("instagram", "video");
      organizer.createShelf("техника", "chat");

      const videoShelves = organizer.getShelvesByType("video");

      expect(videoShelves.length).toBe(2);
      expect(videoShelves.every((s) => s.type === "video")).toBe(true);
    });
  });

  describe("Поиск и статистика", () => {
    it("должен найти элементы по запросу", () => {
      const shelf = organizer.createShelf("техника", "video");

      const item1 = {
        id: "item-001",
        title: "Основы Instagram",
        content: "Это видео о основах Instagram",
        source: "youtube",
        tags: ["instagram"],
        confidence: 0.95,
        indexedAt: new Date(),
      };

      const item2 = {
        id: "item-002",
        title: "Воронки продаж",
        content: "Это видео о воронках продаж",
        source: "youtube",
        tags: ["воронки"],
        confidence: 0.9,
        indexedAt: new Date(),
      };

      organizer.addItemToShelf(shelf.id, item1);
      organizer.addItemToShelf(shelf.id, item2);

      const results = organizer.searchItems("instagram");

      expect(results.length).toBe(1);
      expect(results[0].title).toBe("Основы Instagram");
    });

    it("должен получить статистику", () => {
      organizer.clearAllShelves();

      organizer.createShelf("техника", "video");
      organizer.createShelf("instagram", "video");
      organizer.createShelf("техника", "chat");

      const stats = organizer.getStatistics();

      expect(stats.byType.video).toBe(2);
      expect(stats.byType.chat).toBe(1);
      expect(stats.byCategory.техника).toBe(2);
      expect(stats.byCategory.instagram).toBe(1);
    });
  });

  describe("Экспорт и импорт", () => {
    it("должен экспортировать структуру в JSON", () => {
      organizer.clearAllShelves();

      const shelf = organizer.createShelf("техника", "video");
      const item = {
        id: "item-001",
        title: "Тест",
        content: "Тестовое содержимое",
        source: "test",
        tags: [],
        confidence: 0.9,
        indexedAt: new Date(),
      };

      organizer.addItemToShelf(shelf.id, item);

      const json = organizer.exportToJSON();
      const parsed = JSON.parse(json);

      expect(parsed.shelves).toBeDefined();
      expect(parsed.statistics).toBeDefined();
      expect(parsed.hierarchy).toBeDefined();
      expect(parsed.exportedAt).toBeDefined();
    });

    it("должен импортировать структуру из JSON", () => {
      organizer.clearAllShelves();

      const shelf = organizer.createShelf("техника", "video");
      const json = organizer.exportToJSON();

      organizer.clearAllShelves();
      const success = organizer.importFromJSON(json);

      expect(success).toBe(true);
      expect(organizer.getAllShelves().length).toBeGreaterThan(0);
    });
  });

  describe("Готовность к приему архивов", () => {
    it("должен обработать архив с несколькими транскрибациями", async () => {
      const transcriptions = [
        {
          id: "video-001",
          content: "Видео о технике Instagram",
          type: "video" as const,
          source: "youtube",
          metadata: { title: "Видео 1" },
        },
        {
          id: "chat-001",
          content: "Чат с учениками о воронках",
          type: "chat" as const,
          source: "telegram",
          metadata: { title: "Чат 1" },
        },
        {
          id: "breakdown-001",
          content: "Разбор кейса по контенту",
          type: "breakdown" as const,
          source: "zoom",
          metadata: { title: "Разбор 1" },
        },
      ];

      let successCount = 0;
      for (const t of transcriptions) {
        const result = await processor.processTranscription(t);
        if (result.success) {
          successCount++;
        }
      }

      expect(successCount).toBe(3);
    });

    it("должен обработать большой архив (100+ элементов)", async () => {
      const transcriptions = [];

      for (let i = 0; i < 100; i++) {
        transcriptions.push({
          id: `item-${i}`,
          content: `Это транскрибация номер ${i}. Содержит информацию о технике, Instagram, воронках и контенте.`,
          type: (["video", "chat", "breakdown", "material"][i % 4] as any) as
            | "video"
            | "chat"
            | "breakdown"
            | "material",
          source: `source-${i}`,
          metadata: { title: `Элемент ${i}` },
        });
      }

      let successCount = 0;
      for (const t of transcriptions) {
        const result = await processor.processTranscription(t);
        if (result.success) {
          successCount++;
        }
      }

      expect(successCount).toBeGreaterThanOrEqual(90);
    });
  });

  describe("Валидация данных", () => {
    it("должен отклонить пустую транскрибацию", async () => {
      const result = await processor.validateTranscription({
        id: "test",
        content: "",
        type: "video",
        source: "test",
        metadata: {},
      });

      expect(result.valid).toBe(false);
    });

    it("должен отклонить очень большую транскрибацию", async () => {
      const largeContent = "a".repeat(1000001); // > 1MB

      const result = await processor.validateTranscription({
        id: "test",
        content: largeContent,
        type: "video",
        source: "test",
        metadata: {},
      });

      expect(result.valid).toBe(false);
    });

    it("должен принять валидную транскрибацию", async () => {
      const result = await processor.validateTranscription({
        id: "test",
        content: "Это валидная транскрибация с нормальным размером",
        type: "video",
        source: "test",
        metadata: {},
      });

      expect(result.valid).toBe(true);
    });
  });
});
