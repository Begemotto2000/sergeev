import { invokeLLM } from "../_core/llm";

/**
 * FAQ Extractor Service
 * Extracts question-answer pairs from large text documents (transcriptions, chat histories, разборы)
 * PZ-031: FAQ/ЧаВо раздел
 */

export interface ExtractedFAQPair {
  question: string;
  answer: string;
  category?: string;
  tags?: string[];
  confidence: number; // 0-1
  sourceContext?: string; // Original context from the text
}

export interface FAQExtractionResult {
  totalPairs: number;
  pairs: ExtractedFAQPair[];
  categorized: Record<string, ExtractedFAQPair[]>;
  errors?: string[];
}

/**
 * Main extraction function
 * Processes large text documents and extracts question-answer pairs
 */
export async function extractFAQPairsFromText(
  text: string,
  sourceTitle?: string,
  chunkSize: number = 2000
): Promise<FAQExtractionResult> {
  try {
    // Split large text into manageable chunks
    const chunks = splitTextIntoChunks(text, chunkSize);
    
    const allPairs: ExtractedFAQPair[] = [];
    const errors: string[] = [];

    // Process each chunk
    for (let i = 0; i < chunks.length; i++) {
      try {
        console.log(`Processing chunk ${i + 1}/${chunks.length}...`);
        const chunkPairs = await extractPairsFromChunk(chunks[i], sourceTitle);
        allPairs.push(...chunkPairs);
      } catch (error) {
        const errorMsg = `Error processing chunk ${i + 1}: ${error instanceof Error ? error.message : String(error)}`;
        console.error(errorMsg);
        errors.push(errorMsg);
      }
    }

    // Deduplicate and group pairs
    const uniquePairs = deduplicatePairs(allPairs);
    const categorized = categorizePairs(uniquePairs);

    return {
      totalPairs: uniquePairs.length,
      pairs: uniquePairs,
      categorized,
      errors: errors.length > 0 ? errors : undefined,
    };
  } catch (error) {
    console.error("FAQ extraction failed:", error);
    throw new Error(`FAQ extraction failed: ${error instanceof Error ? error.message : String(error)}`);
  }
}

/**
 * Extract FAQ pairs from a single text chunk
 */
async function extractPairsFromChunk(
  chunkText: string,
  sourceTitle?: string
): Promise<ExtractedFAQPair[]> {
  const systemPrompt = `You are an expert at extracting question-answer pairs from educational content.

Your task is to identify and extract ALL question-answer pairs from the provided text.

Look for patterns like:
- "Вопрос: ... Ответ: ..."
- "Q: ... A: ..."
- "Ученик: ... Мастер/Наставник: ..."
- "Вопрос от учеников: ... Ответ: ..."
- Direct Q&A exchanges in chat format
- Clarifying questions and their answers

For each pair found:
1. Extract the exact question text
2. Extract the exact answer text
3. Identify the category (if obvious)
4. Extract relevant tags
5. Assign confidence (0-1) based on clarity

Return a JSON array with this structure:
[
  {
    "question": "Exact question text",
    "answer": "Exact answer text",
    "category": "ТЕХНИКА|INSTAGRAM|ВОРОНКИ|КОНТЕНТ|АНАЛИТИКА|МЕНТОРСТВО|БИЗНЕС|ДРУГОЕ",
    "tags": ["tag1", "tag2"],
    "confidence": 0.95,
    "sourceContext": "Brief context where this pair appears"
  }
]

IMPORTANT:
- Extract ALL pairs, even if they seem simple or obvious
- Keep answers complete and well-formatted
- If confidence is below 0.7, still include but mark lower confidence
- Return only valid JSON array, no other text`;

  const userPrompt = `Extract all question-answer pairs from this text${sourceTitle ? ` (Source: ${sourceTitle})` : ""}:

${chunkText}

Return ONLY a valid JSON array of extracted pairs.`;

  try {
    const response = await invokeLLM({
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
    });

    const contentArray = response.choices[0]?.message?.content;
    if (!contentArray) {
      throw new Error("No response from LLM");
    }

    // Handle content as array of content objects
    let content = "";
    if (Array.isArray(contentArray)) {
      content = contentArray
        .map((c: any) => (typeof c === "string" ? c : c.text || ""))
        .join("");
    } else {
      content = String(contentArray);
    }

    // Parse JSON response
    const jsonMatch = content.match(/\[[\s\S]*\]/);
    if (!jsonMatch) {
      console.warn("No JSON array found in LLM response");
      return [];
    }

    const pairs: ExtractedFAQPair[] = JSON.parse(jsonMatch[0]);
    return Array.isArray(pairs) ? pairs : [];
  } catch (error) {
    console.error("Chunk extraction error:", error);
    throw error;
  }
}

/**
 * Split text into chunks for processing
 */
function splitTextIntoChunks(text: string, chunkSize: number): string[] {
  const chunks: string[] = [];
  const words = text.split(/\s+/);
  let currentChunk = "";

  for (const word of words) {
    if ((currentChunk + " " + word).length > chunkSize) {
      if (currentChunk) chunks.push(currentChunk);
      currentChunk = word;
    } else {
      currentChunk += (currentChunk ? " " : "") + word;
    }
  }

  if (currentChunk) chunks.push(currentChunk);
  return chunks;
}

/**
 * Deduplicate similar pairs
 */
function deduplicatePairs(pairs: ExtractedFAQPair[]): ExtractedFAQPair[] {
  const seen = new Set<string>();
  const unique: ExtractedFAQPair[] = [];

  for (const pair of pairs) {
    // Create a normalized key for comparison
    const key = normalizeText(pair.question).substring(0, 100);
    
    if (!seen.has(key)) {
      seen.add(key);
      unique.push(pair);
    }
  }

  return unique;
}

/**
 * Normalize text for comparison
 */
function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Categorize pairs by category
 */
function categorizePairs(
  pairs: ExtractedFAQPair[]
): Record<string, ExtractedFAQPair[]> {
  const categories: Record<string, ExtractedFAQPair[]> = {
    ТЕХНИКА: [],
    INSTAGRAM: [],
    ВОРОНКИ: [],
    КОНТЕНТ: [],
    АНАЛИТИКА: [],
    МЕНТОРСТВО: [],
    БИЗНЕС: [],
    ДРУГОЕ: [],
  };

  for (const pair of pairs) {
    const category = pair.category || "ДРУГОЕ";
    if (category in categories) {
      categories[category].push(pair);
    } else {
      categories.ДРУГОЕ.push(pair);
    }
  }

  return categories;
}

/**
 * Generate FAQ ID mask: FAQ-[CATEGORY_ID]-[NUMBER]-[SHORT_TITLE]
 */
export function generateFAQId(
  categoryId: number,
  questionNumber: number,
  shortTitle: string
): string {
  const formattedCategoryId = String(categoryId).padStart(3, "0");
  const formattedNumber = String(questionNumber).padStart(6, "0");
  const cleanTitle = shortTitle
    .toUpperCase()
    .replace(/[^\w\s-]/g, "")
    .replace(/\s+/g, "-")
    .substring(0, 30);

  return `FAQ-${formattedCategoryId}-${formattedNumber}-${cleanTitle}`;
}

/**
 * Validate FAQ pair quality
 */
export function validateFAQPair(pair: ExtractedFAQPair): {
  isValid: boolean;
  issues: string[];
} {
  const issues: string[] = [];

  if (!pair.question || pair.question.trim().length < 5) {
    issues.push("Question too short (minimum 5 characters)");
  }

  if (!pair.answer || pair.answer.trim().length < 10) {
    issues.push("Answer too short (minimum 10 characters)");
  }

  if (pair.confidence < 0.5) {
    issues.push("Confidence too low (< 0.5)");
  }

  if (pair.question.length > 500) {
    issues.push("Question too long (maximum 500 characters)");
  }

  if (pair.answer.length > 5000) {
    issues.push("Answer too long (maximum 5000 characters)");
  }

  return {
    isValid: issues.length === 0,
    issues,
  };
}

/**
 * Batch process multiple documents
 */
export async function extractFAQFromMultipleDocuments(
  documents: Array<{ title: string; content: string }>
): Promise<FAQExtractionResult> {
  const allPairs: ExtractedFAQPair[] = [];
  const allCategorized: Record<string, ExtractedFAQPair[]> = {
    ТЕХНИКА: [],
    INSTAGRAM: [],
    ВОРОНКИ: [],
    КОНТЕНТ: [],
    АНАЛИТИКА: [],
    МЕНТОРСТВО: [],
    БИЗНЕС: [],
    ДРУГОЕ: [],
  };
  const errors: string[] = [];

  for (const doc of documents) {
    try {
      console.log(`Processing document: ${doc.title}`);
      const result = await extractFAQPairsFromText(doc.content, doc.title);
      allPairs.push(...result.pairs);

      // Merge categorized results
      for (const [category, pairs] of Object.entries(result.categorized)) {
        allCategorized[category].push(...pairs);
      }

      if (result.errors) {
        errors.push(...result.errors);
      }
    } catch (error) {
      const errorMsg = `Error processing document "${doc.title}": ${error instanceof Error ? error.message : String(error)}`;
      console.error(errorMsg);
      errors.push(errorMsg);
    }
  }

  // Deduplicate across all documents
  const uniquePairs = deduplicatePairs(allPairs);

  return {
    totalPairs: uniquePairs.length,
    pairs: uniquePairs,
    categorized: allCategorized,
    errors: errors.length > 0 ? errors : undefined,
  };
}

/**
 * Extract related questions for a given FAQ pair
 */
export function findRelatedQuestions(
  targetPair: ExtractedFAQPair,
  allPairs: ExtractedFAQPair[],
  threshold: number = 0.6
): ExtractedFAQPair[] {
  const related: ExtractedFAQPair[] = [];
  const targetKeywords = extractKeywords(targetPair.question);

  for (const pair of allPairs) {
    if (pair === targetPair) continue;

    const pairKeywords = extractKeywords(pair.question);
    const similarity = calculateSimilarity(targetKeywords, pairKeywords);

    if (similarity >= threshold) {
      related.push(pair);
    }
  }

  return related.sort((a, b) => b.confidence - a.confidence);
}

/**
 * Extract keywords from text
 */
function extractKeywords(text: string): Set<string> {
  const stopWords = new Set([
    "что",
    "как",
    "где",
    "когда",
    "почему",
    "какой",
    "какая",
    "какое",
    "это",
    "то",
    "и",
    "или",
    "но",
    "а",
    "в",
    "на",
    "по",
    "для",
    "от",
    "к",
    "с",
    "у",
    "о",
    "об",
  ]);

  const words = text
    .toLowerCase()
    .split(/\s+/)
    .filter((word) => word.length > 2 && !stopWords.has(word));

  return new Set(words);
}

/**
 * Calculate similarity between two keyword sets
 */
function calculateSimilarity(set1: Set<string>, set2: Set<string>): number {
  if (set1.size === 0 || set2.size === 0) return 0;

  const set1Array = Array.from(set1);
  const set2Array = Array.from(set2);
  
  const intersection = new Set(set1Array.filter((x) => set2.has(x)));
  const union = new Set([...set1Array, ...set2Array]);

  return intersection.size / union.size;
}
