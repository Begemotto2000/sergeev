/**
 * Система категоризации и организации Базы Знаний
 * Разлагает материалы по полочкам (категориям, типам, темам)
 */

export type MaterialType = "video" | "chat" | "breakdown" | "material";
export type MaterialCategory =
  | "техника"
  | "instagram"
  | "воронки"
  | "контент"
  | "аналитика"
  | "менторство"
  | "бизнес"
  | "другое";

/**
 * Структура полки (категория материалов)
 */
export interface Shelf {
  id: string;
  name: string;
  category: MaterialCategory;
  type: MaterialType;
  description: string;
  items: ShelfItem[];
  metadata: {
    createdAt: Date;
    updatedAt: Date;
    totalItems: number;
    totalSize: number; // в словах
  };
}

/**
 * Элемент на полке
 */
export interface ShelfItem {
  id: string;
  title: string;
  content: string;
  source: string;
  timestamp?: string; // для видео
  date?: Date; // для чатов
  tags: string[];
  confidence: number;
  indexedAt: Date;
}

/**
 * Иерархия организации
 */
export interface KnowledgeHierarchy {
  root: "Материалы";
  levels: {
    level1: MaterialType; // видео, чаты, разборы, материалы
    level2: MaterialCategory; // техника, instagram, воронки и т.д.
    level3: string; // темы, подкатегории
  };
}

/**
 * Результат организации
 */
export interface OrganizationResult {
  totalItems: number;
  shelves: Shelf[];
  hierarchy: KnowledgeHierarchy;
  stats: {
    byType: Record<string, number>;
    byCategory: Record<string, number>;
    totalSize: number;
  };
}

/**
 * Конфигурация организации
 */
export interface OrganizationConfig {
  autoOrganize: boolean;
  maxItemsPerShelf: number;
  minConfidenceThreshold: number;
  enableHierarchy: boolean;
}

/**
 * Класс для организации Базы Знаний
 */
export class KnowledgeOrganizer {
  private shelves: Map<string, Shelf> = new Map();
  private config: OrganizationConfig;

  constructor(config: Partial<OrganizationConfig> = {}) {
    this.config = {
      autoOrganize: config.autoOrganize ?? true,
      maxItemsPerShelf: config.maxItemsPerShelf ?? 1000,
      minConfidenceThreshold: config.minConfidenceThreshold ?? 0.5,
      enableHierarchy: config.enableHierarchy ?? true,
    };
  }

  /**
   * Создание полки
   */
  createShelf(
    category: MaterialCategory,
    type: MaterialType,
    description: string = ""
  ): Shelf {
    const id = `shelf-${type}-${category}-${Date.now()}`;
    const shelf: Shelf = {
      id,
      name: `${type.toUpperCase()} - ${category.toUpperCase()}`,
      category,
      type,
      description,
      items: [],
      metadata: {
        createdAt: new Date(),
        updatedAt: new Date(),
        totalItems: 0,
        totalSize: 0,
      },
    };

    this.shelves.set(id, shelf);
    return shelf;
  }

  /**
   * Добавление элемента на полку
   */
  addItemToShelf(
    shelfId: string,
    item: ShelfItem
  ): { success: boolean; message: string } {
    const shelf = this.shelves.get(shelfId);

    if (!shelf) {
      return { success: false, message: "Полка не найдена" };
    }

    // Проверка лимита элементов
    if (shelf.items.length >= this.config.maxItemsPerShelf) {
      return {
        success: false,
        message: `Полка переполнена (максимум ${this.config.maxItemsPerShelf} элементов)`,
      };
    }

    // Проверка порога уверенности
    if (item.confidence < this.config.minConfidenceThreshold) {
      return {
        success: false,
        message: `Уверенность ниже порога (${item.confidence} < ${this.config.minConfidenceThreshold})`,
      };
    }

    shelf.items.push(item);
    shelf.metadata.totalItems++;
    shelf.metadata.totalSize += item.content.split(/\s+/).length;
    shelf.metadata.updatedAt = new Date();

    return { success: true, message: "Элемент добавлен на полку" };
  }

  /**
   * Получение полки по ID
   */
  getShelf(shelfId: string): Shelf | undefined {
    return this.shelves.get(shelfId);
  }

  /**
   * Получение всех полок
   */
  getAllShelves(): Shelf[] {
    return Array.from(this.shelves.values());
  }

  /**
   * Получение полок по категории
   */
  getShelvesByCategory(category: MaterialCategory): Shelf[] {
    return Array.from(this.shelves.values()).filter(
      (shelf) => shelf.category === category
    );
  }

  /**
   * Получение полок по типу
   */
  getShelvesByType(type: MaterialType): Shelf[] {
    return Array.from(this.shelves.values()).filter(
      (shelf) => shelf.type === type
    );
  }

  /**
   * Поиск элемента на полках
   */
  searchItems(query: string): ShelfItem[] {
    const results: ShelfItem[] = [];
    const queryLower = query.toLowerCase();

    const shelvesArray = Array.from(this.shelves.values());
    for (const shelf of shelvesArray) {
      for (const item of shelf.items) {
        if (
          item.title.toLowerCase().includes(queryLower) ||
          item.content.toLowerCase().includes(queryLower) ||
          item.tags.some((tag: string) => tag.toLowerCase().includes(queryLower))
        ) {
          results.push(item);
        }
      }
    }

    return results;
  }

  /**
   * Получение статистики
   */
  getStatistics(): OrganizationResult["stats"] {
    const byType: Record<string, number> = {
      video: 0,
      chat: 0,
      breakdown: 0,
      material: 0,
    };
    const byCategory: Record<string, number> = {
      техника: 0,
      instagram: 0,
      воронки: 0,
      контент: 0,
      аналитика: 0,
      менторство: 0,
      бизнес: 0,
      другое: 0,
    };

    let totalSize = 0;

    const shelvesArray = Array.from(this.shelves.values());
    for (const shelf of shelvesArray) {
      byType[shelf.type]++;
      byCategory[shelf.category]++;
      totalSize += shelf.metadata.totalSize;
    }

    return { byType, byCategory, totalSize };
  }

  /**
   * Получение полной иерархии
   */
  getHierarchy(): KnowledgeHierarchy {
    return {
      root: "Материалы",
      levels: {
        level1: "video", // пример
        level2: "техника", // пример
        level3: "оборудование", // пример
      },
    };
  }

  /**
   * Получение результата организации
   */
  getOrganizationResult(): OrganizationResult {
    return {
      totalItems: this.shelves.size,
      shelves: this.getAllShelves(),
      hierarchy: this.getHierarchy(),
      stats: this.getStatistics(),
    };
  }

  /**
   * Удаление полки
   */
  removeShelf(shelfId: string): boolean {
    return this.shelves.delete(shelfId);
  }

  /**
   * Удаление элемента с полки
   */
  removeItemFromShelf(shelfId: string, itemId: string): boolean {
    const shelf = this.shelves.get(shelfId);
    if (!shelf) {
      return false;
    }

    const index = shelf.items.findIndex((item) => item.id === itemId);
    if (index === -1) {
      return false;
    }

    const item = shelf.items[index];
    shelf.items.splice(index, 1);
    shelf.metadata.totalItems--;
    shelf.metadata.totalSize -= item.content.split(/\s+/).length;
    shelf.metadata.updatedAt = new Date();

    return true;
  }

  /**
   * Очистка всех полок
   */
  clearAllShelves(): void {
    this.shelves.clear();
  }

  /**
   * Экспорт структуры в JSON
   */
  exportToJSON(): string {
    const data = {
      shelves: this.getAllShelves(),
      statistics: this.getStatistics(),
      hierarchy: this.getHierarchy(),
      exportedAt: new Date().toISOString(),
    };

    return JSON.stringify(data, null, 2);
  }

  /**
   * Импорт структуры из JSON
   */
  importFromJSON(jsonData: string): boolean {
    try {
      const data = JSON.parse(jsonData);

      if (!data.shelves || !Array.isArray(data.shelves)) {
        return false;
      }

      this.clearAllShelves();

      for (const shelf of data.shelves) {
        this.shelves.set(shelf.id, shelf);
      }

      return true;
    } catch (error) {
      console.error("Ошибка при импорте JSON:", error);
      return false;
    }
  }
}

/**
 * Автоматическая организация материалов
 */
export async function autoOrganizeMaterials(
  materials: Array<{
    id: string;
    title: string;
    content: string;
    type: MaterialType;
    category: MaterialCategory;
    source: string;
    confidence: number;
  }>,
  config: Partial<OrganizationConfig> = {}
): Promise<OrganizationResult> {
  const organizer = new KnowledgeOrganizer(config);

  // Группируем материалы по типу и категории
  const grouped = new Map<string, (typeof materials)[0][]>();

  for (const material of materials) {
    const key = `${material.type}-${material.category}`;
    if (!grouped.has(key)) {
      grouped.set(key, []);
    }
    grouped.get(key)!.push(material);
  }

  // Создаем полки и добавляем материалы
  const groupedArray = Array.from(grouped.entries());
  for (const [key, items] of groupedArray) {
    const parts = key.split("-");
    const type = parts[0] as MaterialType;
    const category = parts.slice(1).join("-") as MaterialCategory;

    const shelf = organizer.createShelf(
      category,
      type,
      `Полка для ${type} материалов по категории ${category}`
    );

    for (const material of items) {
      const item: ShelfItem = {
        id: material.id,
        title: material.title,
        content: material.content,
        source: material.source,
        tags: [],
        confidence: material.confidence,
        indexedAt: new Date(),
      };

      organizer.addItemToShelf(shelf.id, item);
    }
  }

  return organizer.getOrganizationResult();
}

/**
 * Создание иерархической структуры
 */
export function createHierarchicalStructure(): Record<
  MaterialType,
  Record<MaterialCategory, string[]>
> {
  const types: MaterialType[] = ["video", "chat", "breakdown", "material"];
  const categories: MaterialCategory[] = [
    "техника",
    "instagram",
    "воронки",
    "контент",
    "аналитика",
    "менторство",
    "бизнес",
    "другое",
  ];

  const structure: Record<
    MaterialType,
    Record<MaterialCategory, string[]>
  > = {
    video: {} as Record<MaterialCategory, string[]>,
    chat: {} as Record<MaterialCategory, string[]>,
    breakdown: {} as Record<MaterialCategory, string[]>,
    material: {} as Record<MaterialCategory, string[]>,
  };

  for (const type of types) {
    structure[type] = {} as Record<MaterialCategory, string[]>;
    for (const category of categories) {
      structure[type][category] = [];
    }
  }

  return structure;
}
