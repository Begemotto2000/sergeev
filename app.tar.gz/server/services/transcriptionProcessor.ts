import { invokeLLM } from "../_core/llm";

/**
 * Типы материалов в Базе Знаний
 */
export type MaterialType = "video" | "chat" | "breakdown" | "material";

/**
 * Категории материалов
 */
export type MaterialCategory =
  | "техника"
  | "instagram"
  | "воронки"
  | "контент"
  | "аналитика"
  | "менторство"
  | "бизнес"
  | "другое";

/**
 * Структура обработанной транскрибации
 */
export interface ProcessedTranscription {
  id: string; // KB-VIDEO-001-ТЕХНИКА-20260508
  type: MaterialType;
  category: MaterialCategory;
  title: string;
  content: string;
  chunks: TranscriptionChunk[];
  metadata: TranscriptionMetadata;
  status: "draft" | "indexed" | "published";
  confidence: number; // 0-1
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Чанк транскрибации
 */
export interface TranscriptionChunk {
  id: string;
  index: number;
  text: string;
  wordCount: number;
  category: MaterialCategory;
  keywords: string[];
  summary: string;
  confidence: number;
}

/**
 * Метаданные транскрибации
 */
export interface TranscriptionMetadata {
  source: string; // "YouTube", "Telegram", "Discord", "GetCourse"
  sourceUrl?: string;
  timestamp?: string; // для видео: "12:34"
  date?: Date; // для чатов: дата сообщения
  duration?: string; // для видео: "45:30"
  author?: string;
  tags: string[];
  version: number;
}

/**
 * Результат валидации
 */
export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  stats: {
    wordCount: number;
    charCount: number;
    estimatedReadingTime: number; // в минутах
  };
}

/**
 * Результат обработки архива
 */
export interface ArchiveProcessingResult {
  totalFiles: number;
  successfullyProcessed: number;
  failedFiles: string[];
  transcriptions: ProcessedTranscription[];
  processingTime: number; // в секундах
  stats: {
    totalWords: number;
    totalChunks: number;
    averageConfidence: number;
  };
}

/**
 * Валидация транскрибации
 */
export async function validateTranscription(
  text: string,
  type: MaterialType
): Promise<ValidationResult> {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Проверка пустого текста
  if (!text || text.trim().length === 0) {
    errors.push("Текст пуст");
  }

  // Проверка минимального размера
  const wordCount = text.split(/\s+/).length;
  if (wordCount < 50) {
    errors.push(`Минимум 50 слов, получено ${wordCount}`);
  }

  // Проверка максимального размера
  if (wordCount > 1000000) {
    warnings.push(`Очень большой текст: ${wordCount} слов`);
  }

  // Проверка кодировки
  try {
    const encoded = new TextEncoder().encode(text);
    if (encoded.length === 0) {
      errors.push("Ошибка кодирования текста");
    }
  } catch (e) {
    errors.push("Ошибка при кодировании текста");
  }

  // Проверка наличия повторяющихся фрагментов
  const lines = text.split("\n");
  const uniqueLines = new Set(lines);
  if (uniqueLines.size < lines.length * 0.5) {
    warnings.push("Обнаружены повторяющиеся строки");
  }

  const charCount = text.length;
  const estimatedReadingTime = Math.ceil(wordCount / 200); // 200 слов в минуту

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
    stats: {
      wordCount,
      charCount,
      estimatedReadingTime,
    },
  };
}

/**
 * Очистка и нормализация текста
 */
export function cleanAndNormalizeText(text: string): string {
  // Удаление лишних пробелов
  let cleaned = text.replace(/\s+/g, " ").trim();

  // Удаление контрольных символов
  cleaned = cleaned.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, "");

  // Нормализация кавычек
  cleaned = cleaned.replace(/[""]/g, '"').replace(/['']/g, "'");

  // Удаление дублирующихся пунктуации
  cleaned = cleaned.replace(/([.!?])\1+/g, "$1");

  // Нормализация переносов строк
  cleaned = cleaned.replace(/\r\n/g, "\n").replace(/\r/g, "\n");

  return cleaned;
}

/**
 * Разбиение текста на чанки
 */
export function splitIntoChunks(
  text: string,
  chunkSize: number = 2000
): string[] {
  const words = text.split(/\s+/);
  const chunks: string[] = [];
  let currentChunk: string[] = [];
  let currentWordCount = 0;

  for (const word of words) {
    currentChunk.push(word);
    currentWordCount++;

    if (currentWordCount >= chunkSize) {
      chunks.push(currentChunk.join(" "));
      currentChunk = [];
      currentWordCount = 0;
    }
  }

  if (currentChunk.length > 0) {
    chunks.push(currentChunk.join(" "));
  }

  return chunks;
}

/**
 * Категоризация текста через ИИ
 */
export async function categorizeText(text: string): Promise<{
  category: MaterialCategory;
  confidence: number;
  keywords: string[];
}> {
  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: `Вы эксперт по категоризации контента о цифровом маркетинге и Instagram.
Категории: техника, instagram, воронки, контент, аналитика, менторство, бизнес, другое.
Ответьте JSON: {"category": "...", "confidence": 0.95, "keywords": ["...", "..."]}`,
        },
        {
          role: "user",
          content: `Категоризируй этот текст:\n\n${text.substring(0, 500)}...`,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "categorization",
          strict: true,
          schema: {
            type: "object",
            properties: {
              category: {
                type: "string",
                enum: [
                  "техника",
                  "instagram",
                  "воронки",
                  "контент",
                  "аналитика",
                  "менторство",
                  "бизнес",
                  "другое",
                ],
              },
              confidence: { type: "number", minimum: 0, maximum: 1 },
              keywords: { type: "array", items: { type: "string" } },
            },
            required: ["category", "confidence", "keywords"],
            additionalProperties: false,
          },
        },
      },
    });

    const content = response.choices[0].message.content;
    if (typeof content === "string") {
      const parsed = JSON.parse(content);
      return {
        category: parsed.category as MaterialCategory,
        confidence: parsed.confidence,
        keywords: parsed.keywords,
      };
    }

    return {
      category: "другое",
      confidence: 0.5,
      keywords: [],
    };
  } catch (error) {
    console.error("Ошибка при категоризации:", error);
    return {
      category: "другое",
      confidence: 0.3,
      keywords: [],
    };
  }
}

/**
 * Генерация краткого резюме чанка
 */
export async function generateChunkSummary(text: string): Promise<string> {
  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content:
            "Ты эксперт по суммаризации. Создай краткое резюме (1-2 предложения) основной идеи текста.",
        },
        {
          role: "user",
          content: `Суммаризируй этот текст:\n\n${text}`,
        },
      ],
    });

    const content = response.choices[0].message.content;
    if (typeof content === "string") {
      return content.trim();
    }

    return "";
  } catch (error) {
    console.error("Ошибка при генерации резюме:", error);
    return "";
  }
}

/**
 * Обработка одной транскрибации
 */
export async function processTranscription(
  text: string,
  type: MaterialType,
  metadata: TranscriptionMetadata,
  title: string
): Promise<ProcessedTranscription> {
  // 1. Валидация
  const validation = await validateTranscription(text, type);
  if (!validation.isValid) {
    throw new Error(`Валидация не пройдена: ${validation.errors.join(", ")}`);
  }

  // 2. Очистка и нормализация
  const cleanedText = cleanAndNormalizeText(text);

  // 3. Категоризация
  const categorization = await categorizeText(cleanedText);

  // 4. Разбиение на чанки
  const textChunks = splitIntoChunks(cleanedText, 2000);

  // 5. Обработка каждого чанка
  const chunks: TranscriptionChunk[] = [];
  for (let i = 0; i < textChunks.length; i++) {
    const chunkText = textChunks[i];
    const summary = await generateChunkSummary(chunkText);

    chunks.push({
      id: `${title}-chunk-${i + 1}`,
      index: i + 1,
      text: chunkText,
      wordCount: chunkText.split(/\s+/).length,
      category: categorization.category,
      keywords: categorization.keywords,
      summary,
      confidence: categorization.confidence,
    });
  }

  // 6. Генерация ID
  const date = new Date().toISOString().split("T")[0];
  const typeCode = {
    video: "VIDEO",
    chat: "CHAT",
    breakdown: "BREAKDOWN",
    material: "MATERIAL",
  }[type];
  const categoryCode = categorization.category.toUpperCase();
  const id = `KB-${typeCode}-${chunks.length}-${categoryCode}-${date}`;

  // 7. Создание объекта транскрибации
  const transcription: ProcessedTranscription = {
    id,
    type,
    category: categorization.category,
    title,
    content: cleanedText,
    chunks,
    metadata,
    status: "draft",
    confidence: categorization.confidence,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  return transcription;
}

/**
 * Обработка архива транскрибаций
 */
export async function processTranscriptionArchive(
  files: Array<{
    name: string;
    content: string;
    type: MaterialType;
    metadata: TranscriptionMetadata;
  }>
): Promise<ArchiveProcessingResult> {
  const startTime = Date.now();
  const transcriptions: ProcessedTranscription[] = [];
  const failedFiles: string[] = [];

  let totalWords = 0;
  let totalChunks = 0;
  let totalConfidence = 0;

  for (const file of files) {
    try {
      const transcription = await processTranscription(
        file.content,
        file.type,
        file.metadata,
        file.name
      );

      transcriptions.push(transcription);
      totalWords += transcription.chunks.reduce(
        (sum, chunk) => sum + chunk.wordCount,
        0
      );
      totalChunks += transcription.chunks.length;
      totalConfidence += transcription.confidence;
    } catch (error) {
      failedFiles.push(
        `${file.name}: ${error instanceof Error ? error.message : "Неизвестная ошибка"}`
      );
    }
  }

  const processingTime = (Date.now() - startTime) / 1000;

  return {
    totalFiles: files.length,
    successfullyProcessed: transcriptions.length,
    failedFiles,
    transcriptions,
    processingTime,
    stats: {
      totalWords,
      totalChunks,
      averageConfidence:
        transcriptions.length > 0
          ? totalConfidence / transcriptions.length
          : 0,
    },
  };
}

/**
 * Экспорт ID для Qdrant
 */
export function generateQdrantId(transcription: ProcessedTranscription): string {
  return `${transcription.id}-${Date.now()}`;
}

/**
 * Создание вектора для Qdrant
 */
export function createQdrantVector(
  transcription: ProcessedTranscription,
  embedding: number[]
) {
  return {
    id: generateQdrantId(transcription),
    vector: embedding,
    payload: {
      transcriptionId: transcription.id,
      type: transcription.type,
      category: transcription.category,
      title: transcription.title,
      content: transcription.content.substring(0, 1000), // первые 1000 символов
      metadata: transcription.metadata,
      status: transcription.status,
      confidence: transcription.confidence,
      createdAt: transcription.createdAt.toISOString(),
      updatedAt: transcription.updatedAt.toISOString(),
    },
  };
}
