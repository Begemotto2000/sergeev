/**
 * Rate Limiter Tests
 */

import { describe, it, expect } from 'vitest';
import {
  getPriorityRateLimit,
  getRateLimitHeaders,
  shouldRateLimit,
  getEndpointRateLimit,
} from './rateLimiter';

describe('Rate Limiter', () => {
  describe('Rate Limit Checks', () => {
    it('should track requests within limit', () => {
      const limit = 100;
      let current = 0;
      current++;
      expect(current).toBeLessThanOrEqual(limit);
    });

    it('should detect when limit is exceeded', () => {
      const limit = 100;
      const current = 101;
      const isLimited = current > limit;
      expect(isLimited).toBe(true);
    });

    it('should calculate remaining requests', () => {
      const limit = 100;
      const current = 30;
      const remaining = limit - current;
      expect(remaining).toBe(70);
    });

    it('should handle zero remaining requests', () => {
      const limit = 100;
      const current = 100;
      const remaining = Math.max(0, limit - current);
      expect(remaining).toBe(0);
    });
  });

  describe('Adaptive Rate Limits', () => {
    it('should reduce limit under high system load', () => {
      const baseLimit = 100;
      const systemLoad = 90;
      const threshold = 80;

      if (systemLoad > threshold) {
        const reductionFactor = (systemLoad - threshold) / 100;
        const reducedLimit = Math.max(10, Math.floor(baseLimit * (1 - reductionFactor * 0.1)));
        expect(reducedLimit).toBeLessThan(baseLimit);
      }
    });

    it('should increase limit under low system load', () => {
      const baseLimit = 100;
      const systemLoad = 30;

      const capacityFactor = (100 - systemLoad) / 100;
      const increasedLimit = Math.min(500, Math.floor(baseLimit * (1 + capacityFactor * 0.1 * 0.5)));
      expect(increasedLimit).toBeGreaterThanOrEqual(baseLimit);
    });

    it('should maintain limit within bounds', () => {
      const minLimit = 10;
      const maxLimit = 500;
      const adaptiveLimit = 250;

      expect(adaptiveLimit).toBeGreaterThanOrEqual(minLimit);
      expect(adaptiveLimit).toBeLessThanOrEqual(maxLimit);
    });
  });

  describe('Priority-Based Limits', () => {
    it('should give admin highest limit', () => {
      const adminLimit = getPriorityRateLimit('admin');
      const userLimit = getPriorityRateLimit('user');
      expect(adminLimit).toBeGreaterThan(userLimit);
    });

    it('should give premium higher limit than regular user', () => {
      const premiumLimit = getPriorityRateLimit('premium');
      const userLimit = getPriorityRateLimit('user');
      expect(premiumLimit).toBeGreaterThan(userLimit);
    });

    it('should give guest lowest limit', () => {
      const guestLimit = getPriorityRateLimit('guest');
      const userLimit = getPriorityRateLimit('user');
      expect(guestLimit).toBeLessThan(userLimit);
    });

    it('should default to user limit for unknown role', () => {
      const unknownLimit = getPriorityRateLimit('unknown');
      const userLimit = getPriorityRateLimit('user');
      expect(unknownLimit).toBe(userLimit);
    });
  });

  describe('Rate Limit Headers', () => {
    it('should include limit header', () => {
      const status = {
        limit: 100,
        current: 30,
        remaining: 70,
        resetTime: Date.now() + 60000,
        isLimited: false,
      };

      const headers = getRateLimitHeaders(status);
      expect(headers['X-RateLimit-Limit']).toBe('100');
    });

    it('should include remaining header', () => {
      const status = {
        limit: 100,
        current: 30,
        remaining: 70,
        resetTime: Date.now() + 60000,
        isLimited: false,
      };

      const headers = getRateLimitHeaders(status);
      expect(headers['X-RateLimit-Remaining']).toBe('70');
    });

    it('should include reset time header', () => {
      const resetTime = Date.now() + 60000;
      const status = {
        limit: 100,
        current: 30,
        remaining: 70,
        resetTime,
        isLimited: false,
      };

      const headers = getRateLimitHeaders(status);
      expect(headers['X-RateLimit-Reset']).toBe(resetTime.toString());
    });
  });

  describe('Endpoint Configuration', () => {
    it('should identify rate limited endpoints', () => {
      const endpoints = [
        '/api/trpc/knowledgeBase.answerQuery',
        '/api/trpc/transcriptionIntake.uploadTranscription',
      ];

      endpoints.forEach((endpoint) => {
        expect(shouldRateLimit(endpoint)).toBe(true);
      });
    });

    it('should not rate limit health endpoints', () => {
      const endpoint = '/api/health';
      expect(shouldRateLimit(endpoint)).toBe(false);
    });

    it('should get endpoint-specific rate limit', () => {
      const config = getEndpointRateLimit('/api/trpc/knowledgeBase.answerQuery');
      expect(config.maxRequests).toBe(30);
      expect(config.windowMs).toBe(60 * 1000);
    });

    it('should get default config for unknown endpoint', () => {
      const config = getEndpointRateLimit('/api/unknown');
      expect(config.maxRequests).toBe(100);
    });
  });

  describe('Rate Limit Statistics', () => {
    it('should calculate limit percentage', () => {
      const allowed = 70;
      const limited = 30;
      const total = allowed + limited;
      const limitPercentage = (limited / total) * 100;

      expect(limitPercentage).toBeCloseTo(30, 1);
    });

    it('should handle zero events', () => {
      const total = 0;
      const limited = 0;
      const limitPercentage = total > 0 ? (limited / total) * 100 : 0;

      expect(limitPercentage).toBe(0);
    });

    it('should track request counts', () => {
      const stats = {
        allowedCount: 100,
        limitedCount: 5,
        totalEvents: 105,
        limitPercentage: 4.76,
      };

      expect(stats.totalEvents).toBe(stats.allowedCount + stats.limitedCount);
    });
  });

  describe('Window Management', () => {
    it('should track window start time', () => {
      const windowStart = Date.now();
      const windowMs = 60000;
      const windowEnd = windowStart + windowMs;

      expect(windowEnd).toBeGreaterThan(windowStart);
    });

    it('should detect expired windows', () => {
      const windowStart = Date.now() - 70000;
      const windowMs = 60000;
      const now = Date.now();
      const isExpired = now - windowStart > windowMs;

      expect(isExpired).toBe(true);
    });

    it('should reset on window expiration', () => {
      const windowStart = Date.now() - 70000;
      const windowMs = 60000;
      const now = Date.now();

      if (now - windowStart > windowMs) {
        const newWindowStart = now;
        const newCount = 1;

        expect(newCount).toBe(1);
        expect(newWindowStart).toBeGreaterThan(windowStart);
      }
    });
  });

  describe('Burst Allowance', () => {
    it('should allow burst requests', () => {
      const baseLimit = 100;
      const burstAllowance = 20;
      const totalAllowance = baseLimit + burstAllowance;

      expect(totalAllowance).toBe(120);
    });

    it('should track burst usage', () => {
      const baseLimit = 100;
      const burstAllowance = 20;
      const requestsInBurst = 15;
      const remainingBurst = burstAllowance - requestsInBurst;

      expect(remainingBurst).toBe(5);
    });

    it('should deplete burst before normal limit', () => {
      const baseLimit = 100;
      const burstAllowance = 20;
      const requests = 110;

      const burstUsed = Math.min(requests, burstAllowance);
      const normalUsed = requests - burstAllowance;

      expect(burstUsed).toBe(20);
      expect(normalUsed).toBe(90);
    });
  });

  describe('Error Handling', () => {
    it('should fail open when Redis is unavailable', () => {
      const isLimited = false; // Default to allowing request
      expect(isLimited).toBe(false);
    });

    it('should log errors without throwing', () => {
      const errors: string[] = [];
      try {
        // Simulate error
        errors.push('Rate limit check failed');
      } catch (error) {
        expect(error).toBeDefined();
      }
      expect(errors).toHaveLength(1);
    });
  });
});
