/**
 * Rate Limit Monitoring Tests
 */

import { describe, it, expect } from 'vitest';
import { shouldTriggerAlert, generateAlertMessage } from './rateLimitMonitoring';

describe('Rate Limit Monitoring', () => {
  describe('Alert Triggering', () => {
    it('should trigger critical alert at 100%', () => {
      const { shouldAlert, severity } = shouldTriggerAlert(100, 100);
      expect(shouldAlert).toBe(true);
      expect(severity).toBe('critical');
    });

    it('should trigger critical alert at 95%', () => {
      const { shouldAlert, severity } = shouldTriggerAlert(95, 100);
      expect(shouldAlert).toBe(true);
      expect(severity).toBe('critical');
    });

    it('should trigger warning alert at 80%', () => {
      const { shouldAlert, severity } = shouldTriggerAlert(80, 100);
      expect(shouldAlert).toBe(true);
      expect(severity).toBe('warning');
    });

    it('should not trigger alert below 80%', () => {
      const { shouldAlert, severity } = shouldTriggerAlert(75, 100);
      expect(shouldAlert).toBe(false);
      expect(severity).toBeNull();
    });

    it('should respect custom thresholds', () => {
      const { shouldAlert, severity } = shouldTriggerAlert(50, 100, {
        warningThreshold: 40,
        criticalThreshold: 70,
      });
      expect(shouldAlert).toBe(true);
      expect(severity).toBe('warning');
    });
  });

  describe('Alert Recording', () => {
    it('should create alert with unique ID', () => {
      const alertId1 = `alert_${Date.now()}_${Math.random().toString(36).substring(7)}`;
      const alertId2 = `alert_${Date.now()}_${Math.random().toString(36).substring(7)}`;

      expect(alertId1).not.toBe(alertId2);
    });

    it('should include alert metadata', () => {
      const alert = {
        userId: 123,
        timestamp: Date.now(),
        severity: 'warning' as const,
        message: 'Rate limit warning',
        endpoint: '/api/test',
        limitPercentage: 85,
      };

      expect(alert.userId).toBe(123);
      expect(alert.severity).toBe('warning');
    });
  });

  describe('Violation Tracking', () => {
    it('should track violation count', () => {
      let violationCount = 0;
      violationCount++;
      violationCount++;
      violationCount++;

      expect(violationCount).toBe(3);
    });

    it('should identify blocked users', () => {
      const violationCount = 10;
      const threshold = 10;
      const shouldBlock = violationCount >= threshold;

      expect(shouldBlock).toBe(true);
    });

    it('should not block users below threshold', () => {
      const violationCount = 5;
      const threshold = 10;
      const shouldBlock = violationCount >= threshold;

      expect(shouldBlock).toBe(false);
    });

    it('should track violation history', () => {
      const violations = [
        { timestamp: Date.now() - 3600000, endpoint: '/api/test1' },
        { timestamp: Date.now() - 1800000, endpoint: '/api/test2' },
        { timestamp: Date.now(), endpoint: '/api/test3' },
      ];

      expect(violations).toHaveLength(3);
      expect(violations[2].timestamp).toBeGreaterThan(violations[0].timestamp);
    });
  });

  describe('Alert Messages', () => {
    it('should generate critical alert message', () => {
      const message = generateAlertMessage('/api/test', 95, 'critical');
      expect(message).toContain('CRITICAL');
      expect(message).toContain('95');
    });

    it('should generate warning alert message', () => {
      const message = generateAlertMessage('/api/test', 80, 'warning');
      expect(message).toContain('WARNING');
      expect(message).toContain('80');
    });

    it('should include endpoint in message', () => {
      const message = generateAlertMessage('/api/test', 85, 'warning');
      expect(message).toContain('/api/test');
    });
  });

  describe('Monitoring Status', () => {
    it('should track total alerts', () => {
      const status = {
        totalAlerts: 50,
        criticalAlerts: 10,
        warningAlerts: 40,
        totalViolations: 100,
        blockedUsers: 2,
        topViolators: [],
      };

      expect(status.totalAlerts).toBe(50);
      expect(status.criticalAlerts + status.warningAlerts).toBe(50);
    });

    it('should identify top violators', () => {
      const topViolators = [
        { userId: 123, violationCount: 15 },
        { userId: 456, violationCount: 10 },
        { userId: 789, violationCount: 5 },
      ];

      expect(topViolators[0].violationCount).toBeGreaterThan(topViolators[1].violationCount);
    });

    it('should track blocked users', () => {
      const blockedUsers = 5;
      expect(blockedUsers).toBeGreaterThan(0);
    });
  });

  describe('Alert Thresholds', () => {
    it('should use default thresholds', () => {
      const thresholds = {
        warningThreshold: 80,
        criticalThreshold: 95,
        violationThreshold: 100,
      };

      expect(thresholds.warningThreshold).toBe(80);
      expect(thresholds.criticalThreshold).toBe(95);
    });

    it('should allow custom thresholds', () => {
      const customThresholds = {
        warningThreshold: 60,
        criticalThreshold: 80,
        violationThreshold: 100,
      };

      expect(customThresholds.warningThreshold).toBe(60);
      expect(customThresholds.criticalThreshold).toBe(80);
    });
  });

  describe('Alert Cleanup', () => {
    it('should identify old alerts', () => {
      const now = Date.now();
      const olderThanHours = 24;
      const cutoffTime = now - olderThanHours * 60 * 60 * 1000;

      const alerts = [
        { timestamp: now - 48 * 60 * 60 * 1000 }, // 48 hours old
        { timestamp: now - 12 * 60 * 60 * 1000 }, // 12 hours old
        { timestamp: now }, // Just now
      ];

      const oldAlerts = alerts.filter((a) => a.timestamp < cutoffTime);
      expect(oldAlerts).toHaveLength(1);
    });
  });

  describe('Statistics', () => {
    it('should calculate alerts per hour', () => {
      const totalAlerts = 120;
      const hours = 24;
      const alertsPerHour = totalAlerts / hours;

      expect(alertsPerHour).toBe(5);
    });

    it('should identify most common endpoint', () => {
      const alerts = [
        { endpoint: '/api/test1', count: 5 },
        { endpoint: '/api/test2', count: 10 },
        { endpoint: '/api/test3', count: 3 },
      ];

      const mostCommon = alerts.reduce((max, current) =>
        current.count > max.count ? current : max
      );

      expect(mostCommon.endpoint).toBe('/api/test2');
    });

    it('should calculate average severity', () => {
      const alerts = [
        { severity: 'critical' },
        { severity: 'critical' },
        { severity: 'warning' },
      ];

      const criticalCount = alerts.filter((a) => a.severity === 'critical').length;
      const isMostlyCritical = criticalCount > alerts.length / 2;

      expect(isMostlyCritical).toBe(true);
    });
  });

  describe('User Blocking', () => {
    it('should block user after threshold violations', () => {
      const violationCount = 10;
      const blockThreshold = 10;
      const shouldBlock = violationCount >= blockThreshold;

      expect(shouldBlock).toBe(true);
    });

    it('should not block user below threshold', () => {
      const violationCount = 5;
      const blockThreshold = 10;
      const shouldBlock = violationCount >= blockThreshold;

      expect(shouldBlock).toBe(false);
    });

    it('should track blocked user list', () => {
      const blockedUsers = [123, 456, 789];
      expect(blockedUsers).toHaveLength(3);
      expect(blockedUsers).toContain(123);
    });
  });
});
