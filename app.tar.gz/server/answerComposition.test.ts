import { describe, it, expect } from 'vitest';
import { generateFollowUpQuestions, validateAnswerQuality } from './answerComposition';
import type { SourceChunk } from './answerComposition';

describe('Answer Composition', () => {
  const mockSources: SourceChunk[] = [
    {
      id: '1',
      content: 'Иван Сергеев - известный блогер и эксперт по личному развитию.',
      videoId: 'video_1',
      timecode: '00:00:10',
      score: 0.95,
      moduleNumber: 1,
    },
    {
      id: '2',
      content: 'Его основной канал на YouTube имеет более 300 миллионов просмотров.',
      videoId: 'video_1',
      timecode: '00:01:20',
      score: 0.92,
      moduleNumber: 1,
    },
    {
      id: '3',
      content: 'Сергеев создает контент о саморазвитии, бизнесе и психологии.',
      videoId: 'video_2',
      timecode: '00:05:00',
      score: 0.88,
      moduleNumber: 2,
    },
  ];

  describe('generateFollowUpQuestions', () => {
    it('should generate follow-up questions from answer', () => {
      const answer = 'Иван Сергеев - это блогер. Он создает контент о саморазвитии и бизнесе. **Основные направления**: маркетинг, психология, саморазвитие.';
      const questions = generateFollowUpQuestions(answer, 'Кто такой Иван Сергеев?');

      expect(Array.isArray(questions)).toBe(true);
      expect(questions.length).toBeLessThanOrEqual(3);
    });

    it('should return empty array for short answers', () => {
      const answer = 'Блогер.';
      const questions = generateFollowUpQuestions(answer, 'Кто это?');

      expect(Array.isArray(questions)).toBe(true);
      expect(questions.length).toBeLessThanOrEqual(3);
    });
  });

  describe('validateAnswerQuality', () => {
    it('should identify short answers', () => {
      const answer = {
        answer: 'Короткий.',
        sources: mockSources,
        confidence: 0.9,
        synthesisMethod: 'direct' as const,
        keyThemes: ['тема1'],
      };

      const validation = validateAnswerQuality(answer);
      expect(validation.issues.length).toBeGreaterThan(0);
    });

    it('should identify low confidence answers', () => {
      const answer = {
        answer: 'Это очень длинный ответ, который содержит много информации, но имеет низкую уверенность.',
        sources: mockSources,
        confidence: 0.3,
        synthesisMethod: 'synthesis' as const,
        keyThemes: ['тема1'],
      };

      const validation = validateAnswerQuality(answer);
      expect(validation.issues.length).toBeGreaterThan(0);
    });

    it('should identify answers without sources', () => {
      const answer = {
        answer: 'Это очень длинный ответ, который содержит много информации.',
        sources: [],
        confidence: 0.9,
        synthesisMethod: 'direct' as const,
        keyThemes: ['тема1'],
      };

      const validation = validateAnswerQuality(answer);
      expect(validation.issues.some(i => i.includes('sources'))).toBe(true);
    });

    it('should identify answers without themes', () => {
      const answer = {
        answer: 'Это очень длинный ответ, который содержит много информации.',
        sources: mockSources,
        confidence: 0.9,
        synthesisMethod: 'direct' as const,
        keyThemes: [],
      };

      const validation = validateAnswerQuality(answer);
      expect(validation.issues.some(i => i.includes('themes'))).toBe(true);
    });
  });
});
