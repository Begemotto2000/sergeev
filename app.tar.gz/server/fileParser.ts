/**
 * File Parser Module
 * Handles parsing of PDF, DOCX, and TXT transcription files
 */

import * as fs from 'fs';
import * as path from 'path';
import * as mammoth from 'mammoth';
import { TranscriptionSegment } from './transcription';

/**
 * Parse PDF file to text
 */
export async function parsePDF(filePath: string): Promise<string> {
  try {
    // PDF parsing requires external service in ES modules
    // Return placeholder for now
    const fileName = path.basename(filePath);
    return `[PDF Content from ${fileName}]`;
  } catch (error) {
    console.error('PDF parsing error:', error);
    throw new Error(`Failed to parse PDF: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Parse DOCX file to text
 */
export async function parseDOCX(filePath: string): Promise<string> {
  try {
    const fileBuffer = fs.readFileSync(filePath);
    const result = await mammoth.extractRawText({ buffer: fileBuffer });
    return result.value;
  } catch (error) {
    console.error('DOCX parsing error:', error);
    throw new Error(`Failed to parse DOCX: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Parse TXT file to text
 */
export async function parseTXT(filePath: string): Promise<string> {
  try {
    return fs.readFileSync(filePath, 'utf-8');
  } catch (error) {
    console.error('TXT parsing error:', error);
    throw new Error(`Failed to parse TXT: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Parse file based on extension
 */
export async function parseFile(filePath: string): Promise<string> {
  const ext = path.extname(filePath).toLowerCase();

  switch (ext) {
    case '.pdf':
      return parsePDF(filePath);
    case '.docx':
      return parseDOCX(filePath);
    case '.txt':
      return parseTXT(filePath);
    default:
      throw new Error(`Unsupported file format: ${ext}`);
  }
}

/**
 * Convert plain text to transcription segments
 * Splits text into paragraphs and creates segments
 */
export function convertTextToSegments(text: string, videoId?: string): TranscriptionSegment[] {
  const segments: TranscriptionSegment[] = [];
  
  // Split by double newlines (paragraphs)
  const paragraphs = text.split(/\n\n+/).filter(p => p.trim());

  paragraphs.forEach((paragraph, index) => {
    // Split long paragraphs into smaller segments (roughly 200 chars each)
    const lines = paragraph.split('\n').filter(l => l.trim());
    let currentSegment = '';

    lines.forEach((line) => {
      if ((currentSegment + line).length > 200 && currentSegment) {
        segments.push({
          id: `seg_${index}_${segments.length}`,
          startTime: '00:00:00',
          endTime: '00:00:00',
          text: currentSegment.trim(),
        });
        currentSegment = line;
      } else {
        currentSegment += (currentSegment ? ' ' : '') + line;
      }
    });

    if (currentSegment.trim()) {
      segments.push({
        id: `seg_${index}_${segments.length}`,
        startTime: '00:00:00',
        endTime: '00:00:00',
        text: currentSegment.trim(),
      });
    }
  });

  return segments;
}

/**
 * Extract timecode patterns from text
 * Looks for HH:MM:SS or MM:SS patterns
 */
export function extractTimecodes(text: string): Array<{ timecode: string; context: string }> {
  const timecodePattern = /(\d{1,2}):(\d{2}):(\d{2})|(\d{1,2}):(\d{2})/g;
  const results: Array<{ timecode: string; context: string }> = [];

  let match;
  while ((match = timecodePattern.exec(text)) !== null) {
    const start = Math.max(0, match.index - 50);
    const end = Math.min(text.length, match.index + match[0].length + 50);
    const context = text.substring(start, end);

    results.push({
      timecode: match[0],
      context: context.trim(),
    });
  }

  return results;
}

/**
 * Validate transcription file size
 * Max 50MB for PDF/DOCX, 10MB for TXT
 */
export function validateFileSize(filePath: string, fileType: string): boolean {
  const stats = fs.statSync(filePath);
  const maxSizeBytes = fileType === 'txt' ? 10 * 1024 * 1024 : 50 * 1024 * 1024;

  return stats.size <= maxSizeBytes;
}

/**
 * Get file type from extension
 */
export function getFileType(filename: string): string {
  const ext = path.extname(filename).toLowerCase().replace('.', '');
  return ext;
}
