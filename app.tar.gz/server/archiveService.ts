/**
 * Archive Processing Service
 * Handles: extraction, parsing, chunking, indexing
 */

import fs from 'fs';
import path from 'path';
import { createReadStream } from 'fs';
import { createGunzip } from 'zlib';
import { Transform } from 'stream';

interface Chunk {
  id: string;
  content: string;
  metadata: {
    source_file: string;
    chunk_index: number;
    word_count: number;
    char_count: number;
  };
}

/**
 * Extract ZIP archive
 */
export async function extractZip(zipPath: string, extractDir: string): Promise<string[]> {
  // Note: In production, use 'unzipper' or 'adm-zip' package
  // For now, using system unzip command
  return new Promise((resolve, reject) => {
    const { exec } = require('child_process');
    exec(`unzip -q "${zipPath}" -d "${extractDir}"`, (error: any) => {
      if (error) {
        reject(error);
      } else {
        // List extracted files
        const files = fs.readdirSync(extractDir, { recursive: true }) as string[];
        resolve(files.filter(f => !fs.statSync(path.join(extractDir, f)).isDirectory()));
      }
    });
  });
}

/**
 * Parse text file
 */
export async function parseTextFile(filePath: string): Promise<string[]> {
  const content = fs.readFileSync(filePath, 'utf-8');
  return content.split('\n').filter(line => line.trim().length > 0);
}

/**
 * Parse SRT subtitle file
 */
export async function parseSrtFile(filePath: string): Promise<string[]> {
  const content = fs.readFileSync(filePath, 'utf-8');
  const blocks = content.split('\n\n').filter(block => block.trim().length > 0);
  
  return blocks.map(block => {
    const lines = block.split('\n');
    // SRT format: index, timestamp, text
    return lines.slice(2).join(' ').trim();
  }).filter(text => text.length > 0);
}

/**
 * Parse JSON file
 */
export async function parseJsonFile(filePath: string): Promise<string[]> {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    
    if (Array.isArray(data)) {
      return data.map(item => {
        if (typeof item === 'string') return item;
        if (typeof item === 'object') {
          // Extract text from common fields
          return [item.text, item.content, item.title, item.description]
            .filter(v => typeof v === 'string')
            .join(' ');
        }
        return String(item);
      }).filter(text => text.length > 0);
    } else if (typeof data === 'object') {
      // Handle single object
      const texts: string[] = [];
      const traverse = (obj: any) => {
        for (const key in obj) {
          if (typeof obj[key] === 'string') {
            texts.push(obj[key]);
          } else if (typeof obj[key] === 'object' && obj[key] !== null) {
            traverse(obj[key]);
          }
        }
      };
      traverse(data);
      return texts.filter(text => text.length > 0);
    }
    return [];
  } catch (error) {
    console.error('Error parsing JSON file:', error);
    return [];
  }
}

/**
 * Parse CSV file
 */
export async function parseCsvFile(filePath: string): Promise<string[]> {
  const content = fs.readFileSync(filePath, 'utf-8');
  const lines = content.split('\n').filter(line => line.trim().length > 0);
  
  // Simple CSV parsing (skip header)
  return lines.slice(1).map(line => {
    // Remove quotes and split by comma
    return line.split(',').map(cell => cell.replace(/^"|"$/g, '').trim()).join(' ');
  }).filter(text => text.length > 0);
}

/**
 * Parse file based on extension
 */
export async function parseFile(filePath: string): Promise<string[]> {
  const ext = path.extname(filePath).toLowerCase();
  
  try {
    switch (ext) {
      case '.txt':
        return await parseTextFile(filePath);
      case '.srt':
        return await parseSrtFile(filePath);
      case '.json':
        return await parseJsonFile(filePath);
      case '.csv':
        return await parseCsvFile(filePath);
      default:
        // Try as text
        return await parseTextFile(filePath);
    }
  } catch (error) {
    console.error(`Error parsing ${filePath}:`, error);
    return [];
  }
}

/**
 * Split text into chunks (50 words / 300 characters max)
 */
export function chunkText(text: string, maxWords: number = 50, maxChars: number = 300): string[] {
  const chunks: string[] = [];
  const words = text.split(/\s+/).filter(w => w.length > 0);
  
  let currentChunk = '';
  
  for (const word of words) {
    const testChunk = currentChunk ? `${currentChunk} ${word}` : word;
    
    if (testChunk.length > maxChars || testChunk.split(/\s+/).length > maxWords) {
      if (currentChunk) {
        chunks.push(currentChunk);
      }
      currentChunk = word;
    } else {
      currentChunk = testChunk;
    }
  }
  
  if (currentChunk) {
    chunks.push(currentChunk);
  }
  
  return chunks.filter(c => c.length > 0);
}

/**
 * Process archive and return chunks
 */
export async function processArchive(
  zipPath: string,
  extractDir: string,
  onProgress?: (message: string) => void
): Promise<Chunk[]> {
  const chunks: Chunk[] = [];
  let chunkId = 0;
  
  try {
    // Extract archive
    onProgress?.('Extracting archive...');
    const files = await extractZip(zipPath, extractDir);
    onProgress?.(`Found ${files.length} files`);
    
    // Process each file
    for (const file of files) {
      const filePath = path.join(extractDir, file);
      
      if (!fs.existsSync(filePath)) continue;
      
      const stat = fs.statSync(filePath);
      if (!stat.isFile()) continue;
      
      onProgress?.(`Parsing ${path.basename(file)}...`);
      
      // Parse file
      const lines = await parseFile(filePath);
      
      // Chunk each line
      for (const line of lines) {
        const textChunks = chunkText(line);
        
        for (const text of textChunks) {
          chunks.push({
            id: `chunk_${chunkId++}`,
            content: text,
            metadata: {
              source_file: file,
              chunk_index: chunks.length,
              word_count: text.split(/\s+/).length,
              char_count: text.length
            }
          });
        }
      }
      
      onProgress?.(`Processed ${path.basename(file)}: ${textChunks.length} chunks`);
    }
    
    onProgress?.(`Total chunks created: ${chunks.length}`);
    return chunks;
  } catch (error) {
    onProgress?.(`Error: ${error instanceof Error ? error.message : String(error)}`);
    throw error;
  }
}

/**
 * Get supported file types
 */
export function getSupportedFileTypes(): string[] {
  return ['.txt', '.srt', '.json', '.csv', '.zip', '.tar', '.gz'];
}

/**
 * Validate archive file
 */
export function validateArchive(filePath: string): boolean {
  const ext = path.extname(filePath).toLowerCase();
  return ['.zip', '.tar', '.gz'].includes(ext);
}
