import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';
import * as schema from '../drizzle/schema';

let db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (db) {
    return db;
  }

  try {
    const connection = await mysql.createConnection({
      host: process.env.DATABASE_HOST || 'localhost',
      user: process.env.DATABASE_USER || 'root',
      password: process.env.DATABASE_PASSWORD || '',
      database: process.env.DATABASE_NAME || 'sergeev_db',
    });

    db = drizzle(connection, { schema, mode: 'default' });
    console.log('✅ Database connected successfully');
    return db;
  } catch (error) {
    console.error('❌ Failed to connect to database:', error);
    // For development without MySQL, return a mock database
    if (process.env.NODE_ENV !== 'production') {
      console.log('⚠️ Using mock database for development');
      return {
        query: async () => [],
        select: () => ({ from: () => ({ where: async () => [] }) }),
        insert: () => ({ values: () => ({ execute: async () => [] }) }),
        update: () => ({ set: () => ({ where: async () => [] }) }),
        delete: () => ({ from: () => ({ where: async () => [] }) }),
      } as any;
    }
    return null;
  }
}

// Helper functions for common queries
export async function saveJob(jobData: any) {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  // TODO: Implement saveJob
  return null;
}

export async function getJob(jobId: string) {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  // TODO: Implement getJob
  return null;
}

export async function updateJobStatus(jobId: string, status: string) {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  // TODO: Implement updateJobStatus
  return null;
}

// Upload log helpers
export async function saveUploadLog(data: any) {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  // TODO: Implement saveUploadLog
  return { insertId: 1 };
}

export async function getUploadLog(logId: number) {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  // TODO: Implement getUploadLog
  return null;
}

export async function updateUploadStage(logId: number, stageName: string, data: any) {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  // TODO: Implement updateUploadStage
  return null;
}

// FAQ helpers
export async function getFAQItems(limit: number = 100) {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  // TODO: Implement getFAQItems
  return [];
}

export async function searchFAQ(query: string) {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  // TODO: Implement searchFAQ
  return [];
}

// Search history helpers
export async function getUserSearchHistory(userId: number, limit: number = 100) {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  // TODO: Implement getUserSearchHistory
  return [];
}

// User helpers
export async function upsertUser(data: any) {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  // TODO: Implement upsertUser
  return { id: 1 };
}

export async function updateUploadLogStats(logId: number, stats: any) {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  // TODO: Implement updateUploadLogStats
  return null;
}

export async function getDashboardStats(userId: number) {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  
  try {
    // Get upload logs statistics
    const uploadLogs = await database
      .select()
      .from(schema.uploadLogs)
      .where((table) => table.userId === userId);
    
    // Get indexed transcriptions statistics
    const indexedTranscriptions = await database
      .select()
      .from(schema.indexedTranscriptions);
    
    // Calculate statistics
    const totalUploads = uploadLogs.length;
    const successfulUploads = uploadLogs.filter(log => log.status === 'completed').length;
    const failedUploads = uploadLogs.filter(log => log.status === 'failed').length;
    const processingUploads = uploadLogs.filter(log => log.status === 'processing').length;
    
    const successRate = totalUploads > 0 ? Math.round((successfulUploads / totalUploads) * 100) : 0;
    const avgProcessingTime = uploadLogs.length > 0 
      ? Math.round(
          uploadLogs.reduce((sum, log) => {
            if (log.endTime && log.startTime) {
              return sum + (new Date(log.endTime).getTime() - new Date(log.startTime).getTime());
            }
            return sum;
          }, 0) / uploadLogs.length / 1000
        )
      : 0;
    
    return {
      totalUploads,
      successfulUploads,
      failedUploads,
      processingUploads,
      successRate,
      avgProcessingTime,
      totalChunks: indexedTranscriptions.length,
      recentUploads: uploadLogs.slice(0, 10),
    };
  } catch (error) {
    console.error('Error fetching dashboard stats:', error);
    throw error;
  }
}

export async function getUserUploadLogs(userId: number, limit: number = 100) {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  
  try {
    // Get upload logs from upload_logs table
    const logs = await database
      .select()
      .from(schema.uploadLogs)
      .where((table) => table.userId === userId)
      .orderBy((table) => table.createdAt, 'desc')
      .limit(limit);
    
    return logs;
  } catch (error) {
    console.error('Error fetching user upload logs:', error);
    throw error;
  }
}

export async function getUploadLogsByStatus(status: string, limit: number = 100) {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  // TODO: Implement getUploadLogsByStatus
  return [];
}


// Error Report functions
export async function createErrorReport(data: {
  userId: number;
  title: string;
  description: string;
  email?: string;
  screenshotUrl?: string;
  screenshotKey?: string;
  priority?: string;
}) {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  
  try {
    const result = await database.insert(schema.errorReports).values({
      userId: data.userId,
      title: data.title,
      description: data.description,
      email: data.email,
      screenshotUrl: data.screenshotUrl,
      screenshotKey: data.screenshotKey,
      priority: data.priority || 'medium',
      status: 'new',
    });
    
    return result;
  } catch (error) {
    console.error('Error creating error report:', error);
    throw error;
  }
}

export async function getErrorReports(userId: number) {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  
  try {
    const reports = await database
      .select()
      .from(schema.errorReports)
      .where((table) => table.userId === userId)
      .orderBy((table) => table.createdAt);
    
    return reports;
  } catch (error) {
    console.error('Error fetching error reports:', error);
    throw error;
  }
}

export async function updateErrorReportStatus(reportId: number, status: string) {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  
  try {
    const result = await database
      .update(schema.errorReports)
      .set({ status, updatedAt: new Date() })
      .where((table) => table.id === reportId);
    
    return result;
  } catch (error) {
    console.error('Error updating error report:', error);
    throw error;
  }
}

export async function getAllErrorReports() {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  
  try {
    const reports = await database
      .select()
      .from(schema.errorReports)
      .orderBy((table) => table.createdAt);
    
    return reports;
  } catch (error) {
    console.error('Error fetching all error reports:', error);
    throw error;
  }
}


// User lookup by OpenID
export async function getUserByOpenId(openId: string) {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  
  try {
    const users = await database
      .select()
      .from(schema.users)
      .where((table) => table.openId === openId)
      .limit(1);
    
    return users[0] || null;
  } catch (error) {
    console.error('Error fetching user by OpenID:', error);
    throw error;
  }
}

// Delete upload log
export async function deleteUploadLog(logId: number) {
  const database = await getDb();
  if (!database) throw new Error('Database not available');
  
  try {
    const result = await database
      .delete(schema.uploadLogs)
      .where((table) => table.id === logId);
    
    return result;
  } catch (error) {
    console.error('Error deleting upload log:', error);
    throw error;
  }
}
