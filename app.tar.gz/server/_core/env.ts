export const ENV = {
  appId: process.env.VITE_APP_ID ?? "sergeev-digitization",
  cookieSecret: process.env.JWT_SECRET ?? "sergeev-default-secret-key-2026",
  databaseUrl: process.env.DATABASE_URL ?? "file:./data/sergeev.db",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "owner-sergey-001",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "http://localhost:8100/api",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "local-api-key",
};
