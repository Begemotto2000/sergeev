/**
 * Local Authentication Service
 * Provides JWT-based authentication without external OAuth provider
 * Used when OAUTH_SERVER_URL is not configured
 */

import { SignJWT, jwtVerify } from "jose";
import { ENV } from "./env";

export interface LocalUser {
  id: string;
  name: string;
  email: string;
  role: "admin" | "user";
  createdAt: Date;
}

export interface LocalAuthToken {
  token: string;
  expiresAt: Date;
  user: LocalUser;
}

const JWT_SECRET = new TextEncoder().encode(
  ENV.cookieSecret || "sergeev-local-secret-key-2026"
);

const TOKEN_EXPIRY_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

/**
 * Create a JWT token for a user
 */
export async function createLocalAuthToken(user: LocalUser): Promise<string> {
  const now = new Date();
  const expiresAt = new Date(now.getTime() + TOKEN_EXPIRY_MS);

  const token = await new SignJWT({
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    createdAt: user.createdAt.toISOString(),
  })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(Math.floor(expiresAt.getTime() / 1000))
    .sign(JWT_SECRET);

  return token;
}

/**
 * Verify and decode a JWT token
 */
export async function verifyLocalAuthToken(
  token: string
): Promise<LocalUser | null> {
  try {
    const verified = await jwtVerify(token, JWT_SECRET);
    const payload = verified.payload as any;

    return {
      id: payload.id,
      name: payload.name,
      email: payload.email,
      role: payload.role,
      createdAt: new Date(payload.createdAt),
    };
  } catch (error) {
    console.error("[LocalAuth] Token verification failed:", error);
    return null;
  }
}

/**
 * Create a demo user for testing
 */
export function createDemoUser(
  id: string = "demo-user-001",
  name: string = "Demo User",
  email: string = "demo@sergeev.local"
): LocalUser {
  return {
    id,
    name,
    email,
    role: "user",
    createdAt: new Date(),
  };
}

/**
 * Create an admin user
 */
export function createAdminUser(
  id: string = "admin-001",
  name: string = "Administrator",
  email: string = "admin@sergeev.local"
): LocalUser {
  return {
    id,
    name,
    email,
    role: "admin",
    createdAt: new Date(),
  };
}
