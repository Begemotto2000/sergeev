// Load .env only in development
if (process.env.NODE_ENV !== "production") {
  try {
    // Use dynamic import to avoid bundling dotenv in production
    const dotenv = await import("dotenv");
    dotenv.config();
  } catch (e) {
    // dotenv not available
  }
}
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { registerUploadRoutes } from "../uploadHandler";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { createProductionApp } from "../productionApp";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  let app: any;
  let server: any;
  
  if (process.env.NODE_ENV === "production") {
    app = createProductionApp();
    server = createServer(app);
  } else {
    app = express();
    server = createServer(app);
    // Configure body parser with larger size limit for file uploads
    app.use(express.json({ limit: "50mb" }));
    app.use(express.urlencoded({ limit: "50mb", extended: true }));
    registerStorageProxy(app);
    registerOAuthRoutes(app);
    registerUploadRoutes(app);
    // tRPC API
    app.use(
      "/api/trpc",
      createExpressMiddleware({
        router: appRouter,
        createContext,
      })
    );
  }
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else if (process.env.NODE_ENV !== "production") {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = process.env.NODE_ENV === "production" 
    ? 3000 
    : await findAvailablePort(preferredPort);

  if (port !== preferredPort && process.env.NODE_ENV !== "production") {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`[${process.env.NODE_ENV || 'development'}] Server running on http://localhost:${port}/`);
  });
  
  if (process.env.NODE_ENV === "production") {
    console.log("🚀 Production Server Started - Archive Processing System");
    console.log("📊 Dashboard: http://localhost:3000/dashboard");
    console.log("🔌 API: http://localhost:3000/api/");
  }
}

startServer().catch(console.error);
