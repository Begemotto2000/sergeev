import express, { type Express } from "express";
import fs from "fs";
import { type Server } from "http";
import { nanoid } from "nanoid";
import path from "path";
import { createServer as createViteServer } from "vite";

export async function setupVite(app: Express, server: Server) {
  // Only used in development - import vite.config dynamically
  if (process.env.NODE_ENV === "production") {
    // In production, use serveStatic instead
    serveStatic(app);
    return;
  }

  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true as const,
  };

  // Dynamically import vite.config to avoid bundling it with esbuild
  // This import is only executed in development mode, so it won't be bundled
  let viteConfig: any = {};
  try {
    // Use a path-based import that esbuild won't bundle
    const viteConfigPath = path.resolve(import.meta.dirname, "../../vite.config.ts");
    const imported = await import(viteConfigPath);
    viteConfig = imported.default || {};
  } catch (e) {
    console.warn("Could not load vite.config, using defaults");
    // Fallback to minimal config - vite will use defaults
  }

  const vite = await createViteServer({
    ...viteConfig,
    configFile: false,
    server: serverOptions,
    appType: "custom",
  });

  app.use(vite.middlewares);
  app.use("*", async (req, res, next) => {
    const url = req.originalUrl;

    try {
      const clientTemplate = path.resolve(
        import.meta.dirname,
        "../..",
        "client",
        "index.html"
      );

      // always reload the index.html file from disk incase it changes
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e as Error);
      next(e);
    }
  });
}

export function serveStatic(app: Express) {
  // In production, dist is in the current working directory
  // The server is started from /opt/sergeev_digitization_system
  // So dist is at /opt/sergeev_digitization_system/dist
  const distPath = path.resolve(process.cwd(), "dist");
  
  console.log(`[serveStatic] Attempting to serve from: ${distPath}`);
  console.log(`[serveStatic] Current working directory: ${process.cwd()}`);
  
  if (!fs.existsSync(distPath)) {
    console.error(
      `[serveStatic] ERROR: Could not find the build directory: ${distPath}`
    );
    
    // Try alternative paths
    const altPaths = [
      path.resolve(process.cwd(), "dist"),
      path.resolve("/opt/sergeev_digitization_system", "dist"),
      path.resolve("/opt/sergeev_digitization_system/dist"),
    ];
    
    for (const altPath of altPaths) {
      if (fs.existsSync(altPath)) {
        console.log(`[serveStatic] Found dist at: ${altPath}`);
        app.use(express.static(altPath));
        app.use("*", (_req, res) => {
          const indexPath = path.resolve(altPath, "index.html");
          if (fs.existsSync(indexPath)) {
            res.sendFile(indexPath);
          } else {
            res.status(404).json({ error: "index.html not found" });
          }
        });
        return;
      }
    }
    
    // Last resort: serve 404
    app.use("*", (_req, res) => {
      res.status(404).json({ error: "dist directory not found" });
    });
    return;
  }

  console.log(`[serveStatic] Serving static files from: ${distPath}`);
  app.use(express.static(distPath));

  // fall through to index.html if the file doesn't exist
  app.use("*", (_req, res) => {
    const indexPath = path.resolve(distPath, "index.html");
    if (fs.existsSync(indexPath)) {
      res.sendFile(indexPath);
    } else {
      res.status(404).json({ error: "index.html not found" });
    }
  });
}
