/**
 * Simple Local Authentication
 * 3 built-in accounts for local use
 * No external OAuth required
 */

import { SignJWT, jwtVerify } from "jose";
import { ENV } from "./env";

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: "admin" | "user";
}

export interface AuthSession {
  token: string;
  user: AuthUser;
  expiresAt: Date;
}

// Built-in users database
const USERS_DB: Record<string, { name: string; email: string; password: string; role: "admin" | "user" }> = {
  andrey: {
    name: "Andrey",
    email: "andrey@sergeev.local",
    password: "Nokia3310",
    role: "admin",
  },
  masha: {
    name: "Masha",
    email: "masha@sergeev.local",
    password: "Nokia3310",
    role: "user",
  },
  andreyka: {
    name: "Andreyka",
    email: "andreyka@sergeev.local",
    password: "Nokia3310",
    role: "user",
  },
};

const JWT_SECRET = new TextEncoder().encode(
  ENV.cookieSecret || "sergeev-local-secret-key-2026"
);

const TOKEN_EXPIRY_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

/**
 * Authenticate user with username and password
 */
export async function authenticateUser(
  username: string,
  password: string
): Promise<AuthSession | null> {
  const user = USERS_DB[username.toLowerCase()];

  if (!user) {
    console.warn(`[Auth] Login failed: user "${username}" not found`);
    return null;
  }

  if (user.password !== password) {
    console.warn(`[Auth] Login failed: invalid password for user "${username}"`);
    return null;
  }

  const authUser: AuthUser = {
    id: username.toLowerCase(),
    name: user.name,
    email: user.email,
    role: user.role,
  };

  const token = await createJWT(authUser);
  const expiresAt = new Date(Date.now() + TOKEN_EXPIRY_MS);

  console.log(`[Auth] User "${username}" authenticated successfully`);

  return {
    token,
    user: authUser,
    expiresAt,
  };
}

/**
 * Create JWT token
 */
export async function createJWT(user: AuthUser): Promise<string> {
  const expiresAt = new Date(Date.now() + TOKEN_EXPIRY_MS);

  const token = await new SignJWT({
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
  })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(Math.floor(expiresAt.getTime() / 1000))
    .sign(JWT_SECRET);

  return token;
}

/**
 * Verify JWT token
 */
export async function verifyJWT(token: string): Promise<AuthUser | null> {
  try {
    const verified = await jwtVerify(token, JWT_SECRET);
    const payload = verified.payload as any;

    return {
      id: payload.id,
      name: payload.name,
      email: payload.email,
      role: payload.role,
    };
  } catch (error) {
    console.error("[Auth] Token verification failed:", error);
    return null;
  }
}

/**
 * Get all available usernames
 */
export function getAvailableUsers(): string[] {
  return Object.keys(USERS_DB);
}

/**
 * Check if user exists
 */
export function userExists(username: string): boolean {
  return username.toLowerCase() in USERS_DB;
}
