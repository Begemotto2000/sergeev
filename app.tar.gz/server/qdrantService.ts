/**
 * Qdrant Vector Database Service
 * Handles: vectorization, indexing, search
 */

interface VectorPayload {
  id: string;
  text: string;
  source_file: string;
  chunk_index: number;
  word_count: number;
  char_count: number;
  created_at: string;
}

interface SearchResult {
  id: string;
  score: number;
  text: string;
  source_file: string;
}

/**
 * Generate embedding using OpenAI API or fallback to deterministic hash
 */
export async function generateEmbedding(text: string): Promise<number[]> {
  // Try to use OpenAI API if available
  const apiKey = process.env.OPENAI_API_KEY || process.env.VITE_FRONTEND_FORGE_API_KEY;
  const apiUrl = process.env.OPENAI_API_URL || process.env.VITE_FRONTEND_FORGE_API_URL || 'https://api.openai.com/v1';
  
  if (apiKey && text.length > 0) {
    try {
      const response = await fetch(`${apiUrl}/embeddings`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'text-embedding-3-small',
          input: text,
          encoding_format: 'float'
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.data && data.data[0] && data.data[0].embedding) {
          console.log(`Generated embedding for text (${text.length} chars)`);
          return data.data[0].embedding;
        }
      } else {
        console.warn('OpenAI API error:', response.statusText);
      }
    } catch (error) {
      console.warn('OpenAI embedding failed, using fallback:', error);
    }
  }
  
  // Fallback: deterministic hash-based embedding
  const embedding: number[] = [];
  const dimension = 384; // Common embedding dimension
  
  // Hash each character and create embedding
  for (let i = 0; i < dimension; i++) {
    let hash = 0;
    for (let j = 0; j < text.length; j++) {
      const char = text.charCodeAt(j);
      hash = ((hash << 5) - hash) + char + i;
      hash = hash & hash; // Convert to 32bit integer
    }
    // Normalize to [-1, 1]
    embedding.push((hash % 1000) / 500 - 1);
  }
  
  return embedding;
}

/**
 * Initialize Qdrant collection
 */
export async function initializeCollection(
  collectionName: string,
  qdrantUrl: string = 'http://qdrant:6333'
): Promise<boolean> {
  try {
    // Check if collection exists
    const response = await fetch(`${qdrantUrl}/collections/${collectionName}`);
    
    if (response.ok) {
      console.log(`Collection ${collectionName} already exists`);
      return true;
    }
    
    // Create collection
    const createResponse = await fetch(`${qdrantUrl}/collections`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: collectionName,
        vectors: {
          size: 384,
          distance: 'Cosine'
        }
      })
    });
    
    if (createResponse.ok) {
      console.log(`Collection ${collectionName} created`);
      return true;
    }
    
    console.error('Failed to create collection:', createResponse.statusText);
    return false;
  } catch (error) {
    console.error('Error initializing collection:', error);
    return false;
  }
}

/**
 * Index chunks into Qdrant
 */
export async function indexChunks(
  collectionName: string,
  chunks: Array<{
    id: string;
    content: string;
    metadata: {
      source_file: string;
      chunk_index: number;
      word_count: number;
      char_count: number;
    };
  }>,
  qdrantUrl: string = 'http://qdrant:6333'
): Promise<number> {
  try {
    let indexed = 0;
    
    // Generate embeddings for all chunks
    const points = await Promise.all(chunks.map(async (chunk, idx) => ({
      id: idx,
      vector: await generateEmbedding(chunk.content),
      payload: {
        id: chunk.id,
        text: chunk.content,
        source_file: chunk.metadata.source_file,
        chunk_index: chunk.metadata.chunk_index,
        word_count: chunk.metadata.word_count,
        char_count: chunk.metadata.char_count,
        created_at: new Date().toISOString()
      } as VectorPayload
    })));
    
    // Insert in batches of 100
    for (let i = 0; i < points.length; i += 100) {
      const batch = points.slice(i, i + 100);
      
      const response = await fetch(`${qdrantUrl}/collections/${collectionName}/points?wait=true`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          points: batch
        })
      });
      
      if (response.ok) {
        indexed += batch.length;
        console.log(`Indexed ${indexed}/${points.length} chunks`);
      } else {
        console.error('Failed to index batch:', response.statusText);
      }
    }
    
    return indexed;
  } catch (error) {
    console.error('Error indexing chunks:', error);
    return 0;
  }
}

/**
 * Search in Qdrant
 */
export async function searchChunks(
  collectionName: string,
  query: string,
  limit: number = 10,
  qdrantUrl: string = 'http://qdrant:6333'
): Promise<SearchResult[]> {
  try {
    const queryVector = await generateEmbedding(query);
    
    const response = await fetch(`${qdrantUrl}/collections/${collectionName}/points/search`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        vector: queryVector,
        limit,
        with_payload: true
      })
    });
    
    if (!response.ok) {
      console.error('Search failed:', response.statusText);
      return [];
    }
    
    const data = await response.json();
    
    return (data.result || []).map((result: any) => ({
      id: result.payload.id,
      score: result.score,
      text: result.payload.text,
      source_file: result.payload.source_file
    }));
  } catch (error) {
    console.error('Error searching chunks:', error);
    return [];
  }
}

/**
 * Get collection stats
 */
export async function getCollectionStats(
  collectionName: string,
  qdrantUrl: string = 'http://qdrant:6333'
): Promise<any> {
  try {
    const response = await fetch(`${qdrantUrl}/collections/${collectionName}`);
    
    if (!response.ok) {
      return null;
    }
    
    const data = await response.json();
    return {
      points_count: data.result.points_count,
      vectors_count: data.result.vectors_count,
      status: data.result.status
    };
  } catch (error) {
    console.error('Error getting collection stats:', error);
    return null;
  }
}

/**
 * Delete collection
 */
export async function deleteCollection(
  collectionName: string,
  qdrantUrl: string = 'http://qdrant:6333'
): Promise<boolean> {
  try {
    const response = await fetch(`${qdrantUrl}/collections/${collectionName}`, {
      method: 'DELETE'
    });
    
    return response.ok;
  } catch (error) {
    console.error('Error deleting collection:', error);
    return false;
  }
}
