/**
 * Quotas & Billing Tests
 */

import { describe, it, expect, beforeEach } from 'vitest';
import {
  getUserQuota,
  hasQuota,
  deductQuota,
  calculateOperationCost,
  chargeUser,
  getQuotaUsagePercentage,
  resetUserQuota,
  upgradeUserTier,
} from './quotas';

describe('User Quotas & Billing', () => {
  const testUserId = 12345;

  beforeEach(async () => {
    await resetUserQuota(testUserId);
  });

  describe('Quota Management', () => {
    it('should get user quota', async () => {
      const quota = await getUserQuota(testUserId);

      expect(quota).toHaveProperty('userId');
      expect(quota).toHaveProperty('apiCallsLimit');
      expect(quota).toHaveProperty('apiCallsUsed');
      expect(quota).toHaveProperty('tier');
    });

    it('should have free tier by default', async () => {
      const quota = await getUserQuota(testUserId);

      expect(quota.tier).toBe('free');
      expect(quota.apiCallsLimit).toBe(1000);
      expect(quota.storageLimit).toBe(100);
      expect(quota.creditsLimit).toBe(100);
    });

    it('should check quota availability', async () => {
      const hasApi = await hasQuota(testUserId, 'api_calls', 1);

      expect(hasApi).toBe(true);
    });

    it('should deduct quota', async () => {
      const deducted = await deductQuota(testUserId, 'api_calls', 10);

      expect(deducted).toBe(true);

      const quota = await getUserQuota(testUserId);
      expect(quota.apiCallsUsed).toBeGreaterThanOrEqual(10);
    });

    it('should prevent quota overrun', async () => {
      const quota = await getUserQuota(testUserId);
      const deducted = await deductQuota(testUserId, 'api_calls', quota.apiCallsLimit + 1);

      expect(deducted).toBe(false);
    });
  });

  describe('Operation Costs', () => {
    it('should calculate API call cost', () => {
      const cost = calculateOperationCost('api_call');

      expect(cost).toBe(1);
    });

    it('should calculate search cost', () => {
      const cost = calculateOperationCost('search');

      expect(cost).toBe(5);
    });

    it('should calculate transcription cost', () => {
      const cost = calculateOperationCost('transcription');

      expect(cost).toBe(50);
    });
  });

  describe('User Charging', () => {
    it('should charge user for operation', async () => {
      const charged = await chargeUser(testUserId, 'api_call');

      expect(charged).toBe(true);
    });

    it('should prevent charge on insufficient credits', async () => {
      // First, use up credits
      const quota = await getUserQuota(testUserId);
      for (let i = 0; i < quota.creditsLimit; i++) {
        await deductQuota(testUserId, 'credits', 1);
      }

      // Try to charge
      const charged = await chargeUser(testUserId, 'search');

      expect(charged).toBe(false);
    });
  });

  describe('Quota Usage Percentage', () => {
    it('should calculate usage percentage', async () => {
      await deductQuota(testUserId, 'api_calls', 100);

      const usage = await getQuotaUsagePercentage(testUserId);

      expect(usage.apiCalls).toBeGreaterThan(0);
      expect(usage.apiCalls).toBeLessThanOrEqual(100);
    });

    it('should show 0% for unused quota', async () => {
      const usage = await getQuotaUsagePercentage(testUserId);

      expect(usage.apiCalls).toBe(0);
      expect(usage.storage).toBe(0);
      expect(usage.credits).toBe(0);
    });
  });

  describe('Tier Upgrades', () => {
    it('should upgrade user tier', async () => {
      await upgradeUserTier(testUserId, 'pro');

      const quota = await getUserQuota(testUserId);

      expect(quota.tier).toBe('pro');
      expect(quota.apiCallsLimit).toBe(100000);
    });

    it('should reset quota on upgrade', async () => {
      await deductQuota(testUserId, 'api_calls', 50);
      await upgradeUserTier(testUserId, 'pro');

      const quota = await getUserQuota(testUserId);

      expect(quota.apiCallsUsed).toBe(0);
    });

    it('should support enterprise tier', async () => {
      await upgradeUserTier(testUserId, 'enterprise');

      const quota = await getUserQuota(testUserId);

      expect(quota.tier).toBe('enterprise');
      expect(quota.apiCallsLimit).toBe(Infinity);
    });
  });

  describe('Quota Reset', () => {
    it('should reset user quota', async () => {
      await deductQuota(testUserId, 'api_calls', 100);
      await resetUserQuota(testUserId);

      const quota = await getUserQuota(testUserId);

      expect(quota.apiCallsUsed).toBe(0);
    });

    it('should reset all quota types', async () => {
      await deductQuota(testUserId, 'api_calls', 50);
      await deductQuota(testUserId, 'storage', 30);
      await deductQuota(testUserId, 'credits', 20);

      await resetUserQuota(testUserId);

      const quota = await getUserQuota(testUserId);

      expect(quota.apiCallsUsed).toBe(0);
      expect(quota.storageUsed).toBe(0);
      expect(quota.creditsUsed).toBe(0);
    });
  });
});
