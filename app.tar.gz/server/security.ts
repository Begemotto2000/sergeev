/**
 * Production Hardening & Security
 * Implements security best practices and hardening measures
 */

import crypto from 'crypto';
import { getCacheKey, setCounter, getCounter } from './redis';

export interface SecurityConfig {
  enableRateLimiting: boolean;
  enableCSRFProtection: boolean;
  enableCORS: boolean;
  enableHSTS: boolean;
  enableContentSecurityPolicy: boolean;
  enableXFrameOptions: boolean;
  enableXContentTypeOptions: boolean;
  enableXXSSProtection: boolean;
  enableSecureHeaders: boolean;
}

export interface SecurityEvent {
  id: string;
  type: 'suspicious_activity' | 'rate_limit_violation' | 'auth_failure' | 'sql_injection_attempt' | 'xss_attempt';
  severity: 'low' | 'medium' | 'high' | 'critical';
  userId?: number;
  ipAddress: string;
  userAgent?: string;
  details: Record<string, any>;
  timestamp: number;
}

/**
 * Default security configuration
 */
export const DEFAULT_SECURITY_CONFIG: SecurityConfig = {
  enableRateLimiting: true,
  enableCSRFProtection: true,
  enableCORS: true,
  enableHSTS: true,
  enableContentSecurityPolicy: true,
  enableXFrameOptions: true,
  enableXContentTypeOptions: true,
  enableXXSSProtection: true,
  enableSecureHeaders: true,
};

/**
 * Generate CSRF token
 */
export function generateCSRFToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

/**
 * Validate CSRF token
 */
export function validateCSRFToken(token: string, sessionToken: string): boolean {
  try {
    return crypto.timingSafeEqual(Buffer.from(token), Buffer.from(sessionToken));
  } catch (error) {
    return false;
  }
}

/**
 * Hash password
 */
export async function hashPassword(password: string): Promise<string> {
  try {
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
    return `${salt}:${hash}`;
  } catch (error) {
    console.error('Failed to hash password:', error);
    return '';
  }
}

/**
 * Verify password
 */
export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  try {
    const [salt, storedHash] = hash.split(':');
    const computedHash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
    return crypto.timingSafeEqual(Buffer.from(computedHash), Buffer.from(storedHash));
  } catch (error) {
    console.error('Failed to verify password:', error);
    return false;
  }
}

/**
 * Sanitize input
 */
export function sanitizeInput(input: string): string {
  // Remove potentially dangerous characters
  return input
    .replace(/[<>\"']/g, '')
    .trim()
    .substring(0, 1000);
}

/**
 * Validate email
 */
export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email) && email.length <= 255;
}

/**
 * Validate URL
 */
export function validateURL(url: string): boolean {
  try {
    new URL(url);
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Detect SQL injection attempt
 */
export function detectSQLInjection(input: string): boolean {
  const sqlKeywords = ['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'DROP', 'UNION', 'EXEC', 'EXECUTE'];
  const upperInput = input.toUpperCase();

  for (const keyword of sqlKeywords) {
    if (upperInput.includes(keyword)) {
      return true;
    }
  }

  return false;
}

/**
 * Detect XSS attempt
 */
export function detectXSSAttempt(input: string): boolean {
  const xssPatterns = [/<script[^>]*>.*?<\/script>/gi, /on\w+\s*=/gi, /<iframe/gi, /javascript:/gi];

  for (const pattern of xssPatterns) {
    if (pattern.test(input)) {
      return true;
    }
  }

  return false;
}

/**
 * Record security event
 */
export async function recordSecurityEvent(event: Omit<SecurityEvent, 'id' | 'timestamp'>): Promise<SecurityEvent> {
  try {
    const securityEvent: SecurityEvent = {
      ...event,
      id: `sec_${Date.now()}_${Math.random().toString(36).substring(7)}`,
      timestamp: Date.now(),
    };

    const key = getCacheKey('security_events', event.severity);
    // Would push to database

    // Log critical security events
    if (event.severity === 'critical') {
      console.error(`CRITICAL SECURITY EVENT: ${event.type}`, event);
    }

    return securityEvent;
  } catch (error) {
    console.error('Failed to record security event:', error);
    return {
      id: '',
      type: 'suspicious_activity',
      severity: 'low',
      ipAddress: '',
      details: {},
      timestamp: 0,
    };
  }
}

/**
 * Check for suspicious activity
 */
export async function checkSuspiciousActivity(userId: number, ipAddress: string): Promise<boolean> {
  try {
    const key = getCacheKey('user_ips', userId.toString());
    // Would check if IP is new or unusual

    return false;
  } catch (error) {
    console.error('Failed to check suspicious activity:', error);
    return false;
  }
}

/**
 * Get security headers
 */
export function getSecurityHeaders(): Record<string, string> {
  return {
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'",
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'geolocation=(), microphone=(), camera=()',
  };
}

/**
 * Generate API key
 */
export function generateAPIKey(): string {
  return crypto.randomBytes(32).toString('hex');
}

/**
 * Hash API key
 */
export function hashAPIKey(apiKey: string): string {
  return crypto.createHash('sha256').update(apiKey).digest('hex');
}

/**
 * Validate API key format
 */
export function validateAPIKeyFormat(apiKey: string): boolean {
  return /^[a-f0-9]{64}$/.test(apiKey);
}

/**
 * Encrypt sensitive data
 */
export function encryptData(data: string, key: string): string {
  try {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(key, 'hex'), iv);
    let encrypted = cipher.update(data, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return iv.toString('hex') + ':' + encrypted;
  } catch (error) {
    console.error('Failed to encrypt data:', error);
    return '';
  }
}

/**
 * Decrypt sensitive data
 */
export function decryptData(encryptedData: string, key: string): string {
  try {
    const [iv, encrypted] = encryptedData.split(':');
    const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(key, 'hex'), Buffer.from(iv, 'hex'));
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (error) {
    console.error('Failed to decrypt data:', error);
    return '';
  }
}

/**
 * Get security audit log
 */
export async function getSecurityAuditLog(limit: number = 100): Promise<SecurityEvent[]> {
  try {
    // Placeholder - would fetch from database
    return [];
  } catch (error) {
    console.error('Failed to get security audit log:', error);
    return [];
  }
}

/**
 * Check security compliance
 */
export async function checkSecurityCompliance(): Promise<{
  compliant: boolean;
  issues: string[];
  score: number;
}> {
  try {
    const issues: string[] = [];
    let score = 100;

    // Check for SSL/TLS
    // Check for secure headers
    // Check for rate limiting
    // Check for authentication

    return {
      compliant: issues.length === 0,
      issues,
      score,
    };
  } catch (error) {
    console.error('Failed to check security compliance:', error);
    return {
      compliant: false,
      issues: ['Security check failed'],
      score: 0,
    };
  }
}

/**
 * Generate security report
 */
export async function generateSecurityReport(): Promise<{
  timestamp: number;
  totalEvents: number;
  criticalEvents: number;
  highSeverityEvents: number;
  topThreats: Array<{ type: string; count: number }>;
  recommendations: string[];
}> {
  try {
    return {
      timestamp: Date.now(),
      totalEvents: 0,
      criticalEvents: 0,
      highSeverityEvents: 0,
      topThreats: [],
      recommendations: [],
    };
  } catch (error) {
    console.error('Failed to generate security report:', error);
    return {
      timestamp: Date.now(),
      totalEvents: 0,
      criticalEvents: 0,
      highSeverityEvents: 0,
      topThreats: [],
      recommendations: ['Security report generation failed'],
    };
  }
}
