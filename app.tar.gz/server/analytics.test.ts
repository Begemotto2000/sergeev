import { describe, it, expect } from 'vitest';
import {
  getModeStatistics,
  getTrendingQueries,
  getModeEffectivenessScore,
  compareModesEffectiveness,
} from './analytics';
import type { QueryAnalytics, ModeStatistics } from './analytics';

describe('Analytics Module', () => {
  const mockAnalyticsData: QueryAnalytics[] = [
    {
      queryId: '1',
      query: 'Как начать блог?',
      mode: 'ОТВЕТ',
      resultCount: 5,
      responseTime: 800,
      confidence: 0.95,
      timestamp: new Date(),
    },
    {
      queryId: '2',
      query: 'Как начать блог?',
      mode: 'ОТВЕТ',
      resultCount: 5,
      responseTime: 750,
      confidence: 0.93,
      timestamp: new Date(),
    },
    {
      queryId: '3',
      query: 'Таймкод про маркетинг',
      mode: 'ТАЙМКОД',
      resultCount: 3,
      responseTime: 1200,
      confidence: 0.88,
      timestamp: new Date(),
    },
    {
      queryId: '4',
      query: 'Глубокое исследование',
      mode: 'DEEP RESEARCH',
      resultCount: 8,
      responseTime: 2500,
      confidence: 0.92,
      timestamp: new Date(),
    },
    {
      queryId: '5',
      query: 'Идеи для контента',
      mode: 'ИМИГО',
      resultCount: 4,
      responseTime: 3000,
      confidence: 0.85,
      timestamp: new Date(),
    },
    {
      queryId: '6',
      query: 'Как начать блог?',
      mode: 'ОТВЕТ',
      resultCount: 0,
      responseTime: 600,
      confidence: 0.2,
      timestamp: new Date(),
    },
  ];

  describe('getModeStatistics', () => {
    it('should calculate statistics for each mode', () => {
      const stats = getModeStatistics(mockAnalyticsData);

      expect(stats).toBeDefined();
      expect(stats.length).toBeGreaterThan(0);
      expect(stats[0]).toHaveProperty('mode');
      expect(stats[0]).toHaveProperty('count');
      expect(stats[0]).toHaveProperty('percentage');
      expect(stats[0]).toHaveProperty('avgResponseTime');
      expect(stats[0]).toHaveProperty('avgConfidence');
      expect(stats[0]).toHaveProperty('successRate');
    });

    it('should sort modes by count descending', () => {
      const stats = getModeStatistics(mockAnalyticsData);

      for (let i = 0; i < stats.length - 1; i++) {
        expect(stats[i].count).toBeGreaterThanOrEqual(stats[i + 1].count);
      }
    });

    it('should calculate correct percentages', () => {
      const stats = getModeStatistics(mockAnalyticsData);
      const totalPercentage = stats.reduce((sum, s) => sum + s.percentage, 0);

      expect(totalPercentage).toBeCloseTo(100, 1);
    });

    it('should calculate success rate correctly', () => {
      const stats = getModeStatistics(mockAnalyticsData);

      for (const stat of stats) {
        expect(stat.successRate).toBeGreaterThanOrEqual(0);
        expect(stat.successRate).toBeLessThanOrEqual(100);
      }
    });

    it('should calculate average response time correctly', () => {
      const stats = getModeStatistics(mockAnalyticsData);
      const ответStats = stats.find(s => s.mode === 'ОТВЕТ');

      if (ответStats) {
        const expectedAvg = (800 + 750 + 600) / 3;
        expect(ответStats.avgResponseTime).toBeCloseTo(expectedAvg, 0);
      }
    });
  });

  describe('getTrendingQueries', () => {
    it('should return trending queries sorted by frequency', () => {
      const trending = getTrendingQueries(mockAnalyticsData, 5);

      expect(Array.isArray(trending)).toBe(true);
      expect(trending[0]).toBe('Как начать блог?');
    });

    it('should respect limit parameter', () => {
      const trending = getTrendingQueries(mockAnalyticsData, 2);

      expect(trending.length).toBeLessThanOrEqual(2);
    });

    it('should return empty array for empty data', () => {
      const trending = getTrendingQueries([], 5);

      expect(trending).toHaveLength(0);
    });
  });

  describe('getModeEffectivenessScore', () => {
    it('should calculate effectiveness score', () => {
      const stat: ModeStatistics = {
        mode: 'ОТВЕТ',
        count: 3,
        percentage: 50,
        avgResponseTime: 800,
        avgConfidence: 0.93,
        successRate: 100,
      };

      const score = getModeEffectivenessScore(stat);

      expect(score).toBeGreaterThan(0);
      expect(score).toBeLessThanOrEqual(100);
    });

    it('should give higher scores to faster modes', () => {
      const fastStat: ModeStatistics = {
        mode: 'ОТВЕТ',
        count: 1,
        percentage: 25,
        avgResponseTime: 500,
        avgConfidence: 0.9,
        successRate: 100,
      };

      const slowStat: ModeStatistics = {
        mode: 'DEEP RESEARCH',
        count: 1,
        percentage: 25,
        avgResponseTime: 3000,
        avgConfidence: 0.9,
        successRate: 100,
      };

      const fastScore = getModeEffectivenessScore(fastStat);
      const slowScore = getModeEffectivenessScore(slowStat);

      expect(fastScore).toBeGreaterThan(slowScore);
    });

    it('should give higher scores to modes with better success rates', () => {
      const goodStat: ModeStatistics = {
        mode: 'ОТВЕТ',
        count: 1,
        percentage: 25,
        avgResponseTime: 800,
        avgConfidence: 0.9,
        successRate: 100,
      };

      const badStat: ModeStatistics = {
        mode: 'ТАЙМКОД',
        count: 1,
        percentage: 25,
        avgResponseTime: 800,
        avgConfidence: 0.9,
        successRate: 50,
      };

      const goodScore = getModeEffectivenessScore(goodStat);
      const badScore = getModeEffectivenessScore(badStat);

      expect(goodScore).toBeGreaterThan(badScore);
    });
  });

  describe('compareModesEffectiveness', () => {
    it('should compare effectiveness of all modes', () => {
      const stats = getModeStatistics(mockAnalyticsData);
      const comparison = compareModesEffectiveness(stats);

      expect(comparison.size).toBe(stats.length);

      for (const stat of stats) {
        expect(comparison.has(stat.mode)).toBe(true);
        const score = comparison.get(stat.mode);
        expect(score).toBeGreaterThan(0);
        expect(score).toBeLessThanOrEqual(100);
      }
    });

    it('should return Map with mode names as keys', () => {
      const stats = getModeStatistics(mockAnalyticsData);
      const comparison = compareModesEffectiveness(stats);

      for (const mode of comparison.keys()) {
        expect(['ОТВЕТ', 'ТАЙМКОД', 'DEEP RESEARCH', 'ИМИГО']).toContain(mode);
      }
    });
  });
});
