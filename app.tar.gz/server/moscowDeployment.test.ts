import { describe, expect, it } from "vitest";
import { AUTH_NOT_CONFIGURED_HREF, buildLoginUrl } from "../client/src/const";

describe("Moscow deployment auth URL fallback", () => {
  it("keeps the public /100 build renderable when OAuth portal URL is not configured", () => {
    expect(
      buildLoginUrl({
        oauthPortalUrl: "",
        appId: "app_123",
        origin: "http://46.8.255.137",
        basePath: "/100",
      }),
    ).toBe(AUTH_NOT_CONFIGURED_HREF);
  });

  it("keeps the public /100 build renderable when OAuth app id is not configured", () => {
    expect(
      buildLoginUrl({
        oauthPortalUrl: "https://manus.example",
        appId: "",
        origin: "http://46.8.255.137",
        basePath: "/100",
      }),
    ).toBe(AUTH_NOT_CONFIGURED_HREF);
  });

  it("builds an OAuth URL with the /100 callback path when OAuth is configured", () => {
    const result = buildLoginUrl({
      oauthPortalUrl: "https://manus.example",
      appId: "app_123",
      origin: "http://46.8.255.137",
      basePath: "/100/",
    });

    const url = new URL(result);
    const redirectUri = "http://46.8.255.137/100/api/oauth/callback";

    expect(url.origin).toBe("https://manus.example");
    expect(url.pathname).toBe("/app-auth");
    expect(url.searchParams.get("appId")).toBe("app_123");
    expect(url.searchParams.get("redirectUri")).toBe(redirectUri);
    expect(url.searchParams.get("state")).toBe(btoa(redirectUri));
    expect(url.searchParams.get("type")).toBe("signIn");
  });
});
