/**
 * Redis Cache Module
 * Provides distributed caching layer for the application
 */

// Use mock redis for production
let RedisClientType: any;
let createClient: any;

async function initializeRedisClient() {
  try {
    const redis = await import('redis');
    createClient = redis.createClient;
  } catch (e) {
    // Fallback to mock redis if package not found
    const redisMock = await import('./redis-mock');
    createClient = redisMock.createClient;
  }
}

// Initialize on module load
initializeRedisClient().catch(console.error);

let redisClient: RedisClientType | null = null;

/**
 * Initialize Redis connection
 */
export async function initializeRedis(): Promise<RedisClientType> {
  if (redisClient) {
    return redisClient;
  }

  const redisUrl = process.env.REDIS_URL || 'redis://localhost:6379';

  try {
    redisClient = createClient({
      url: redisUrl,
      socket: {
        reconnectStrategy: (retries) => Math.min(retries * 50, 500),
      },
    });

    redisClient.on('error', (err) => {
      console.error('Redis Client Error:', err);
    });

    redisClient.on('connect', () => {
      console.log('Redis connected successfully');
    });

    await redisClient.connect();
    return redisClient;
  } catch (error) {
    console.error('Failed to initialize Redis:', error);
    throw error;
  }
}

/**
 * Get Redis client instance
 */
export async function getRedisClient(): Promise<RedisClientType> {
  if (!redisClient) {
    return initializeRedis();
  }
  return redisClient;
}

/**
 * Cache key generator
 */
export function getCacheKey(prefix: string, ...args: (string | number)[]): string {
  return `${prefix}:${args.join(':')}`;
}

/**
 * Set cache value with TTL
 */
export async function setCache(
  key: string,
  value: any,
  ttlSeconds: number = 300
): Promise<void> {
  try {
    const client = await getRedisClient();
    const serialized = JSON.stringify(value);
    await client.setEx(key, ttlSeconds, serialized);
  } catch (error) {
    console.error('Redis set error:', error);
    // Gracefully handle Redis failures - fall back to in-memory
  }
}

/**
 * Get cache value
 */
export async function getCache<T>(key: string): Promise<T | null> {
  try {
    const client = await getRedisClient();
    const value = await client.get(key);
    if (!value) return null;
    return JSON.parse(value) as T;
  } catch (error) {
    console.error('Redis get error:', error);
    return null;
  }
}

/**
 * Delete cache key
 */
export async function deleteCache(key: string): Promise<void> {
  try {
    const client = await getRedisClient();
    await client.del(key);
  } catch (error) {
    console.error('Redis delete error:', error);
  }
}

/**
 * Delete cache keys by pattern
 */
export async function deleteCachePattern(pattern: string): Promise<number> {
  try {
    const client = await getRedisClient();
    const keys = await client.keys(pattern);
    if (keys.length === 0) return 0;
    return await client.del(keys);
  } catch (error) {
    console.error('Redis delete pattern error:', error);
    return 0;
  }
}

/**
 * Clear all cache
 */
export async function clearAllCache(): Promise<void> {
  try {
    const client = await getRedisClient();
    await client.flushDb();
  } catch (error) {
    console.error('Redis flush error:', error);
  }
}

/**
 * Get cache statistics
 */
export async function getCacheStats(): Promise<{
  dbSize: number;
  memoryUsage: string;
  connectedClients: number;
}> {
  try {
    const client = await getRedisClient();
    const dbSize = await client.dbSize();
    const info = await client.info('memory');
    const memoryLines = info.split('\r\n');
    const memoryUsage = memoryLines.find((line) => line.startsWith('used_memory_human'));

    return {
      dbSize,
      memoryUsage: memoryUsage ? memoryUsage.split(':')[1] : 'N/A',
      connectedClients: 1,
    };
  } catch (error) {
    console.error('Redis stats error:', error);
    return { dbSize: 0, memoryUsage: 'N/A', connectedClients: 0 };
  }
}

/**
 * Increment counter
 */
export async function incrementCounter(key: string, increment: number = 1): Promise<number> {
  try {
    const client = await getRedisClient();
    return await client.incrBy(key, increment);
  } catch (error) {
    console.error('Redis increment error:', error);
    return 0;
  }
}

/**
 * Set counter with expiration
 */
export async function setCounter(key: string, value: number, ttlSeconds: number = 3600): Promise<void> {
  try {
    const client = await getRedisClient();
    await client.setEx(key, ttlSeconds, value.toString());
  } catch (error) {
    console.error('Redis set counter error:', error);
  }
}

/**
 * Get counter value
 */
export async function getCounter(key: string): Promise<number> {
  try {
    const client = await getRedisClient();
    const value = await client.get(key);
    return value ? parseInt(value, 10) : 0;
  } catch (error) {
    console.error('Redis get counter error:', error);
    return 0;
  }
}

/**
 * Push to list
 */
export async function pushToList(key: string, values: any[], maxLength: number = 1000): Promise<void> {
  try {
    const client = await getRedisClient();
    for (const value of values) {
      await client.rPush(key, JSON.stringify(value));
    }
    // Keep list size under control
    const length = await client.lLen(key);
    if (length > maxLength) {
      await client.lTrim(key, length - maxLength, -1);
    }
  } catch (error) {
    console.error('Redis push to list error:', error);
  }
}

/**
 * Get list values
 */
export async function getList<T>(key: string, start: number = 0, stop: number = -1): Promise<T[]> {
  try {
    const client = await getRedisClient();
    const values = await client.lRange(key, start, stop);
    return values.map((v) => JSON.parse(v) as T);
  } catch (error) {
    console.error('Redis get list error:', error);
    return [];
  }
}

/**
 * Add to set
 */
export async function addToSet(key: string, members: string[]): Promise<void> {
  try {
    const client = await getRedisClient();
    await client.sAdd(key, members);
  } catch (error) {
    console.error('Redis add to set error:', error);
  }
}

/**
 * Get set members
 */
export async function getSetMembers(key: string): Promise<string[]> {
  try {
    const client = await getRedisClient();
    return await client.sMembers(key);
  } catch (error) {
    console.error('Redis get set members error:', error);
    return [];
  }
}

/**
 * Check if member exists in set
 */
export async function isSetMember(key: string, member: string): Promise<boolean> {
  try {
    const client = await getRedisClient();
    return (await client.sIsMember(key, member)) === 1;
  } catch (error) {
    console.error('Redis is set member error:', error);
    return false;
  }
}

/**
 * Publish message to channel
 */
export async function publishMessage(channel: string, message: any): Promise<void> {
  try {
    const client = await getRedisClient();
    await client.publish(channel, JSON.stringify(message));
  } catch (error) {
    console.error('Redis publish error:', error);
  }
}

/**
 * Close Redis connection
 */
export async function closeRedis(): Promise<void> {
  if (redisClient) {
    await redisClient.quit();
    redisClient = null;
  }
}
