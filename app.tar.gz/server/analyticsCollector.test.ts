/**
 * Analytics Collector Tests
 */

import { describe, it, expect } from 'vitest';
import { calculatePercentile } from './analyticsCollector';

describe('Analytics Collector', () => {
  describe('Percentile Calculation', () => {
    it('should calculate 50th percentile (median)', () => {
      const data = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
      const p50 = calculatePercentile(data, 50);
      expect(p50).toBeGreaterThanOrEqual(40);
      expect(p50).toBeLessThanOrEqual(60);
    });

    it('should calculate 95th percentile', () => {
      const data = Array.from({ length: 100 }, (_, i) => i + 1);
      const p95 = calculatePercentile(data, 95);
      expect(p95).toBeGreaterThanOrEqual(90);
    });

    it('should calculate 99th percentile', () => {
      const data = Array.from({ length: 100 }, (_, i) => i + 1);
      const p99 = calculatePercentile(data, 99);
      expect(p99).toBeGreaterThanOrEqual(95);
    });

    it('should handle empty array', () => {
      const data: number[] = [];
      const p50 = calculatePercentile(data, 50);
      expect(p50).toBe(0);
    });

    it('should handle single element', () => {
      const data = [42];
      const p50 = calculatePercentile(data, 50);
      expect(p50).toBe(42);
    });
  });

  describe('Query Analytics', () => {
    it('should track query metrics', () => {
      const query = {
        timestamp: Date.now(),
        queryTime: 250,
        cacheHit: true,
        queryMode: 'ОТВЕТ',
        resultCount: 5,
        userId: 1,
      };

      expect(query.queryTime).toBe(250);
      expect(query.cacheHit).toBe(true);
    });

    it('should aggregate query statistics', () => {
      const queries = [
        { queryTime: 100, cacheHit: true },
        { queryTime: 200, cacheHit: false },
        { queryTime: 150, cacheHit: true },
      ];

      const avgTime = queries.reduce((sum, q) => sum + q.queryTime, 0) / queries.length;
      const cacheHits = queries.filter((q) => q.cacheHit).length;

      expect(avgTime).toBe(150);
      expect(cacheHits).toBe(2);
    });

    it('should calculate cache hit rate', () => {
      const queries = [
        { cacheHit: true },
        { cacheHit: true },
        { cacheHit: false },
        { cacheHit: true },
      ];

      const hitRate = (queries.filter((q) => q.cacheHit).length / queries.length) * 100;
      expect(hitRate).toBe(75);
    });
  });

  describe('Performance Metrics', () => {
    it('should track query modes', () => {
      const modes: Record<string, number> = {
        ОТВЕТ: 100,
        ТАЙМКОД: 50,
        DEEP_RESEARCH: 30,
        ИМИГО: 20,
      };

      expect(modes.ОТВЕТ).toBe(100);
      expect(Object.keys(modes)).toHaveLength(4);
    });

    it('should calculate mode distribution', () => {
      const modes: Record<string, number> = {
        ОТВЕТ: 100,
        ТАЙМКОД: 50,
      };

      const total = Object.values(modes).reduce((a, b) => a + b, 0);
      const distribution = {
        ОТВЕТ: (modes.ОТВЕТ / total) * 100,
        ТАЙМКОД: (modes.ТАЙМКОД / total) * 100,
      };

      expect(distribution.ОТВЕТ).toBeCloseTo(66.67, 1);
      expect(distribution.ТАЙМКОД).toBeCloseTo(33.33, 1);
    });
  });

  describe('System Metrics', () => {
    it('should track memory usage', () => {
      const metrics = {
        memoryUsage: 512, // MB
        cpuUsage: 25, // %
        activeConnections: 42,
        uptime: 86400, // seconds
      };

      expect(metrics.memoryUsage).toBe(512);
      expect(metrics.activeConnections).toBe(42);
    });

    it('should calculate average metrics', () => {
      const samples = [
        { memory: 400, cpu: 20 },
        { memory: 500, cpu: 30 },
        { memory: 600, cpu: 40 },
      ];

      const avgMemory = samples.reduce((sum, s) => sum + s.memory, 0) / samples.length;
      const avgCpu = samples.reduce((sum, s) => sum + s.cpu, 0) / samples.length;

      expect(avgMemory).toBe(500);
      expect(avgCpu).toBe(30);
    });
  });

  describe('Hourly Statistics', () => {
    it('should aggregate hourly data', () => {
      const hourlyStats = [
        { hour: '10:00', queryCount: 100, avgTime: 250 },
        { hour: '11:00', queryCount: 150, avgTime: 300 },
        { hour: '12:00', queryCount: 120, avgTime: 280 },
      ];

      const totalQueries = hourlyStats.reduce((sum, h) => sum + h.queryCount, 0);
      expect(totalQueries).toBe(370);
    });

    it('should identify peak hours', () => {
      const hourlyStats = [
        { hour: '10:00', queryCount: 100 },
        { hour: '11:00', queryCount: 500 },
        { hour: '12:00', queryCount: 200 },
      ];

      const peakHour = hourlyStats.reduce((max, h) => (h.queryCount > max.queryCount ? h : max));
      expect(peakHour.hour).toBe('11:00');
      expect(peakHour.queryCount).toBe(500);
    });
  });

  describe('Slow Query Detection', () => {
    it('should identify slow queries', () => {
      const queries = [
        { queryTime: 100 },
        { queryTime: 200 },
        { queryTime: 5000 },
        { queryTime: 150 },
      ];

      const avgTime = queries.reduce((sum, q) => sum + q.queryTime, 0) / queries.length;
      const slowQueries = queries.filter((q) => q.queryTime > avgTime * 2);

      expect(slowQueries).toHaveLength(1);
      expect(slowQueries[0].queryTime).toBe(5000);
    });

    it('should rank slow queries', () => {
      const queries = [
        { id: 1, queryTime: 100 },
        { id: 2, queryTime: 5000 },
        { id: 3, queryTime: 200 },
        { id: 4, queryTime: 3000 },
      ];

      const sorted = [...queries].sort((a, b) => b.queryTime - a.queryTime);
      expect(sorted[0].queryTime).toBe(5000);
      expect(sorted[1].queryTime).toBe(3000);
    });
  });

  describe('Data Retention', () => {
    it('should maintain data retention window', () => {
      const retentionHours = 24;
      const now = Date.now();
      const cutoff = now - retentionHours * 60 * 60 * 1000;

      const data = [
        { timestamp: now - 1000 }, // Recent
        { timestamp: cutoff + 1000 }, // Within window
        { timestamp: cutoff - 1000 }, // Outside window
      ];

      const retained = data.filter((d) => d.timestamp >= cutoff);
      expect(retained).toHaveLength(2);
    });
  });
});
