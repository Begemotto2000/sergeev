
import { getSessionCookieOptions } from "./_core/cookies";
import { publicProcedure, router } from "./_core/trpc";
import { authenticateUser } from "./_core/simpleAuth";
import { z } from "zod";
// Knowledge base routers removed
import { telegramRouter } from "./routers/telegram";
import { analyticsRouter } from "./routers/analytics";
import { analyticsAdvancedRouter } from "./routers/analyticsAdvanced";
import { transcriptionIntakeRouter } from "./routers/transcriptionIntake";
import { healthRouter } from "./routers/health";
import { rateLimitingRouter } from "./routers/rateLimiting";
import { webhookRouter } from "./routers/webhooks";
import { techSupportRouter } from "./routers/techSupport";
import { archiveIndexingRouter } from "./routers/archiveIndexing";

const COOKIE_NAME = "session";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  // system router removed - all processes moved to Production Server (46.8.255.137)
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
    login: publicProcedure
      .input(z.object({
        username: z.string().min(1),
        password: z.string().min(1),
      }))
      .mutation(async ({ input, ctx }) => {
        const session = await authenticateUser(input.username, input.password);
        
        if (!session) {
          throw new Error("Invalid username or password");
        }

        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, session.token, {
          ...cookieOptions,
          maxAge: 30 * 24 * 60 * 60 * 1000,
        });

        return {
          success: true,
          user: session.user,
          token: session.token,
        };
      }),
  }),

  telegram: telegramRouter,
  analytics: analyticsRouter,
  analyticsAdvanced: analyticsAdvancedRouter,
  transcriptionIntake: transcriptionIntakeRouter,
  health: healthRouter,
  rateLimiting: rateLimitingRouter,
  webhooks: webhookRouter,
  techSupport: techSupportRouter,
  archiveIndexing: archiveIndexingRouter,

});

export type AppRouter = typeof appRouter;
