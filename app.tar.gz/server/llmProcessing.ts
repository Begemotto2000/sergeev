/**
 * LLM Text Processing Module
 * Implements 3 text generation modes: Выжиматор, Саммари, Анализатор
 * STANDARD: ЧеЧиЧе (Четко, Чисто, Честно) - только реальные вызовы GPT-4o
 */

import { invokeLLM } from './_core/llm';

export interface ProcessingResult {
  mode: 'vyzhimator' | 'sammari' | 'analizator';
  originalText: string;
  processedText: string;
  metadata: {
    originalLength: number;
    processedLength: number;
    compressionRatio: number;
    tokensUsed: number;
    generatedAt: Date;
  };
}

/**
 * Vyzhimator (Выжиматор) - Squeeze out the essence
 * Extracts key facts, dates, names, and critical information
 * Compression: 70-80% reduction
 * ЧЕСТНО: Используется реальный GPT-4o, все вызовы логируются
 */
export async function vyzhimator(text: string): Promise<ProcessingResult> {
  const startTime = Date.now();
  
  try {
    console.log(`[VYZHIMATOR] Начало обработки (${text.length} символов)`);
    
    if (!text || text.trim().length === 0) {
      throw new Error('Текст не может быть пустым');
    }

    const response = await invokeLLM({
      messages: [
        {
          role: 'system',
          content: `You are a professional text condenser. Your task is to extract ONLY the most critical facts, dates, names, and key information from the text.
          
Rules:
1. Extract ONLY essential facts (dates, names, numbers, key decisions)
2. Remove all explanations, examples, and elaborations
3. Use bullet points or numbered list format
4. Keep the original language (Russian if input is Russian)
5. Maximum 20-30% of original length
6. Focus on: WHO, WHAT, WHEN, WHERE, WHY (critical facts only)

Format your response as a structured list of key facts.`,
        },
        {
          role: 'user',
          content: `Extract key facts from this text:\n\n${text}`,
        },
      ],
    });

    const processedText =
      typeof response.choices[0].message.content === 'string'
        ? response.choices[0].message.content
        : '';

    if (!processedText || processedText.trim().length === 0) {
      throw new Error('GPT-4o вернул пустой ответ');
    }

    const result: ProcessingResult = {
      mode: 'vyzhimator',
      originalText: text,
      processedText,
      metadata: {
        originalLength: text.length,
        processedLength: processedText.length,
        compressionRatio: (processedText.length / text.length) * 100,
        tokensUsed: Math.ceil(text.length / 4),
        generatedAt: new Date(),
      },
    };

    const duration = Date.now() - startTime;
    console.log(`[VYZHIMATOR] ✅ Успешно (${duration}ms): сжато с ${text.length} до ${processedText.length} символов`);
    
    return result;
  } catch (error) {
    const duration = Date.now() - startTime;
    console.error(`[VYZHIMATOR] ❌ КРИТИЧЕСКАЯ ОШИБКА (${duration}ms):`, error);
    throw error;
  }
}

/**
 * Sammari (Саммари) - Summary generation
 * Creates a coherent summary maintaining context and flow
 * Compression: 30-50% reduction
 * ЧЕСТНО: Используется реальный GPT-4o
 */
export async function sammari(text: string): Promise<ProcessingResult> {
  const startTime = Date.now();
  
  try {
    console.log(`[SAMMARI] Начало обработки (${text.length} символов)`);
    
    if (!text || text.trim().length === 0) {
      throw new Error('Текст не может быть пустым');
    }

    const response = await invokeLLM({
      messages: [
        {
          role: 'system',
          content: `You are a professional summarizer. Your task is to create a coherent, well-structured summary that maintains the main ideas and flow of the original text.

Rules:
1. Preserve the main narrative and key points
2. Maintain logical flow and connections between ideas
3. Keep important context and examples
4. Use clear, concise language
5. Target length: 40-60% of original
6. Make the summary readable and comprehensive

Write the summary in the same language as the input.`,
        },
        {
          role: 'user',
          content: `Create a summary of this text:\n\n${text}`,
        },
      ],
    });

    const processedText =
      typeof response.choices[0].message.content === 'string'
        ? response.choices[0].message.content
        : '';

    if (!processedText || processedText.trim().length === 0) {
      throw new Error('GPT-4o вернул пустой ответ');
    }

    const result: ProcessingResult = {
      mode: 'sammari',
      originalText: text,
      processedText,
      metadata: {
        originalLength: text.length,
        processedLength: processedText.length,
        compressionRatio: (processedText.length / text.length) * 100,
        tokensUsed: Math.ceil(text.length / 4),
        generatedAt: new Date(),
      },
    };

    const duration = Date.now() - startTime;
    console.log(`[SAMMARI] ✅ Успешно (${duration}ms): саммари ${processedText.length} символов`);
    
    return result;
  } catch (error) {
    const duration = Date.now() - startTime;
    console.error(`[SAMMARI] ❌ КРИТИЧЕСКАЯ ОШИБКА (${duration}ms):`, error);
    throw error;
  }
}

/**
 * Analizator (Анализатор) - Deep analysis and insights
 * Provides comprehensive analysis with insights and recommendations
 * ЧЕСТНО: Используется реальный GPT-4o
 */
export async function analizator(text: string): Promise<ProcessingResult> {
  const startTime = Date.now();
  
  try {
    console.log(`[ANALIZATOR] Начало обработки (${text.length} символов)`);
    
    if (!text || text.trim().length === 0) {
      throw new Error('Текст не может быть пустым');
    }

    const response = await invokeLLM({
      messages: [
        {
          role: 'system',
          content: `You are an expert analyst. Your task is to provide deep analysis of the given text with insights, patterns, and recommendations.

Structure your analysis as follows:
1. ОСНОВНЫЕ ИДЕИ (Main Ideas) - Key concepts and themes
2. АНАЛИЗ (Analysis) - Deep dive into the content
3. ЗАКОНОМЕРНОСТИ (Patterns) - Recurring themes and patterns
4. ВЫВОДЫ (Conclusions) - Key takeaways
5. РЕКОМЕНДАЦИИ (Recommendations) - Actionable insights

Be thorough, analytical, and provide valuable insights.
Write in the same language as the input.`,
        },
        {
          role: 'user',
          content: `Analyze this text:\n\n${text}`,
        },
      ],
    });

    const processedText =
      typeof response.choices[0].message.content === 'string'
        ? response.choices[0].message.content
        : '';

    if (!processedText || processedText.trim().length === 0) {
      throw new Error('GPT-4o вернул пустой ответ');
    }

    const result: ProcessingResult = {
      mode: 'analizator',
      originalText: text,
      processedText,
      metadata: {
        originalLength: text.length,
        processedLength: processedText.length,
        compressionRatio: (processedText.length / text.length) * 100,
        tokensUsed: Math.ceil(text.length / 4),
        generatedAt: new Date(),
      },
    };

    const duration = Date.now() - startTime;
    console.log(`[ANALIZATOR] ✅ Успешно (${duration}ms): анализ ${processedText.length} символов`);
    
    return result;
  } catch (error) {
    const duration = Date.now() - startTime;
    console.error(`[ANALIZATOR] ❌ КРИТИЧЕСКАЯ ОШИБКА (${duration}ms):`, error);
    throw error;
  }
}

/**
 * Validate processing result
 */
export function validateProcessingResult(result: ProcessingResult): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!result.mode || !['vyzhimator', 'sammari', 'analizator'].includes(result.mode)) {
    errors.push('Invalid mode');
  }

  if (!result.originalText || result.originalText.trim().length === 0) {
    errors.push('Original text is required');
  }

  if (!result.processedText || result.processedText.trim().length === 0) {
    errors.push('Processed text is required');
  }

  if (result.metadata.compressionRatio < 0 || result.metadata.compressionRatio > 100) {
    errors.push('Compression ratio must be between 0 and 100');
  }

  if (result.metadata.processedLength < 0) {
    errors.push('Processed length cannot be negative');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Calculate quality metrics
 */
export function calculateQualityMetrics(result: ProcessingResult): {
  readability: number;
  compression: number;
  efficiency: number;
} {
  const readability = Math.min(100, (result.processedText.length / result.originalText.length) * 100);
  const compression = 100 - readability;
  const efficiency = compression > 0 ? (result.processedText.length / result.originalText.length) * 100 : 0;

  return {
    readability,
    compression,
    efficiency,
  };
}

/**
 * Compare results from different modes
 */
export function compareResults(results: ProcessingResult[]): {
  mostCompressed: ProcessingResult;
  mostDetailed: ProcessingResult;
  averageCompression: number;
} {
  const sorted = [...results].sort((a, b) => a.metadata.compressionRatio - b.metadata.compressionRatio);

  return {
    mostCompressed: sorted[0],
    mostDetailed: sorted[sorted.length - 1],
    averageCompression: results.reduce((sum, r) => sum + r.metadata.compressionRatio, 0) / results.length,
  };
}
