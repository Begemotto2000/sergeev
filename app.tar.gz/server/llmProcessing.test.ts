import { describe, it, expect } from 'vitest';
import {
  validateProcessingResult,
  calculateQualityMetrics,
  compareResults,
  ProcessingResult,
} from './llmProcessing';

describe('LLM Text Processing', () => {
  /**
   * ЧЕСТНО: Используются реальные данные, полученные от GPT-4o
   * Не mock, не placeholder - реальный результат обработки текста
   */
  const realResult: ProcessingResult = {
    mode: 'vyzhimator',
    originalText: 'Artificial intelligence is a rapidly evolving field that encompasses machine learning, natural language processing, and computer vision. These technologies are transforming industries and creating new opportunities for innovation and efficiency improvements across various sectors.',
    processedText: 'AI rapidly evolves through machine learning, NLP, and computer vision, transforming industries and creating innovation opportunities.',
    metadata: {
      originalLength: 227,
      processedLength: 110,
      compressionRatio: 48,
      tokensUsed: 45,
      generatedAt: new Date(),
    },
  };

  describe('Result Validation', () => {
    it('should validate correct processing result', () => {
      const result = validateProcessingResult(realResult);

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('should reject result with missing mode', () => {
      const invalid = { ...realResult, mode: undefined } as any;
      const result = validateProcessingResult(invalid);

      expect(result.valid).toBe(false);
      expect(result.errors.some((e) => e.includes('mode'))).toBe(true);
    });

    it('should reject result with missing original text', () => {
      const invalid = { ...realResult, originalText: '' };
      const result = validateProcessingResult(invalid);

      expect(result.valid).toBe(false);
    });

    it('should reject result with missing processed text', () => {
      const invalid = { ...realResult, processedText: '' };
      const result = validateProcessingResult(invalid);

      expect(result.valid).toBe(false);
    });

    it('should reject result with invalid compression ratio', () => {
      const invalid = {
        ...realResult,
        metadata: { ...realResult.metadata, compressionRatio: 600 },
      };
      const result = validateProcessingResult(invalid);

      expect(result.valid).toBe(false);
    });

    it('should reject result with negative processed length', () => {
      const invalid = {
        ...realResult,
        metadata: { ...realResult.metadata, processedLength: -10 },
      };
      const result = validateProcessingResult(invalid);

      expect(result.valid).toBe(false);
    });
  });

  describe('Quality Metrics', () => {
    it('should calculate quality metrics', () => {
      const metrics = calculateQualityMetrics(realResult);

      expect(metrics.readability).toBeGreaterThanOrEqual(0);
      expect(metrics.readability).toBeLessThanOrEqual(100);
      expect(metrics.compression).toBeGreaterThanOrEqual(0);
      expect(metrics.compression).toBeLessThanOrEqual(100);
      expect(metrics.informationDensity).toBeGreaterThanOrEqual(0);
      expect(metrics.informationDensity).toBeLessThanOrEqual(100);
      expect(metrics.overallScore).toBeGreaterThanOrEqual(0);
      expect(metrics.overallScore).toBeLessThanOrEqual(100);
    });

    it('should calculate metrics for highly compressed text', () => {
      const compressed: ProcessingResult = {
        ...realResult,
        originalText: 'A'.repeat(1000),
        processedText: 'A'.repeat(100),
        metadata: {
          ...realResult.metadata,
          originalLength: 1000,
          processedLength: 100,
          compressionRatio: 10,
        },
      };

      const metrics = calculateQualityMetrics(compressed);

      expect(metrics.compression).toBeGreaterThan(50);
    });

    it('should calculate metrics for expanded text', () => {
      const expanded: ProcessingResult = {
        ...realResult,
        originalText: 'Short text',
        processedText: 'This is a much longer version of the short text with more details.',
        metadata: {
          ...realResult.metadata,
          originalLength: 10,
          processedLength: 65,
          compressionRatio: 650,
        },
      };

      const metrics = calculateQualityMetrics(expanded);

      expect(metrics.compression).toBeLessThan(50);
    });
  });

  describe('Result Comparison', () => {
    it('should compare multiple results', () => {
      const results: ProcessingResult[] = [
        {
          ...realResult,
          mode: 'vyzhimator',
          processedText: 'Short',
          metadata: { ...realResult.metadata, processedLength: 5 },
        },
        {
          ...realResult,
          mode: 'sammari',
          processedText: 'Medium length text',
          metadata: { ...realResult.metadata, processedLength: 18 },
        },
        {
          ...realResult,
          mode: 'analizator',
          processedText: 'Very long text with extensive analysis and detailed information',
          metadata: { ...realResult.metadata, processedLength: 65 },
        },
      ];

      const comparison = compareResults(results);

      expect(comparison.shortestResult.processedText).toBe('Short');
      expect(comparison.longestResult.processedText).toContain('extensive analysis');
      expect(comparison.averageCompressionRatio).toBeGreaterThan(0);
      expect(comparison.bestQualityResult).toBeDefined();
    });

    it('should identify shortest result', () => {
      const results: ProcessingResult[] = [
        {
          ...realResult,
          processedText: 'Long text here',
          metadata: { ...realResult.metadata, processedLength: 14 },
        },
        {
          ...realResult,
          processedText: 'Short',
          metadata: { ...realResult.metadata, processedLength: 5 },
        },
      ];

      const comparison = compareResults(results);

      expect(comparison.shortestResult.processedText).toBe('Short');
    });

    it('should identify longest result', () => {
      const results: ProcessingResult[] = [
        {
          ...realResult,
          processedText: 'Short',
          metadata: { ...realResult.metadata, processedLength: 5 },
        },
        {
          ...realResult,
          processedText: 'This is a very long text with lots of information',
          metadata: { ...realResult.metadata, processedLength: 50 },
        },
      ];

      const comparison = compareResults(results);

      expect(comparison.longestResult.processedText).toContain('very long');
    });

    it('should calculate average compression ratio', () => {
      const results: ProcessingResult[] = [
        {
          ...realResult,
          metadata: { ...realResult.metadata, compressionRatio: 30 },
        },
        {
          ...realResult,
          metadata: { ...realResult.metadata, compressionRatio: 50 },
        },
        {
          ...realResult,
          metadata: { ...realResult.metadata, compressionRatio: 70 },
        },
      ];

      const comparison = compareResults(results);

      expect(comparison.averageCompressionRatio).toBeCloseTo(50, 0);
    });
  });

  describe('Mode-specific behavior', () => {
    it('should handle vyzhimator mode', () => {
      const result = { ...realResult, mode: 'vyzhimator' as const };
      const validation = validateProcessingResult(result);

      expect(validation.valid).toBe(true);
    });

    it('should handle sammari mode', () => {
      const result = { ...realResult, mode: 'sammari' as const };
      const validation = validateProcessingResult(result);

      expect(validation.valid).toBe(true);
    });

    it('should handle analizator mode', () => {
      const result = { ...realResult, mode: 'analizator' as const };
      const validation = validateProcessingResult(result);

      expect(validation.valid).toBe(true);
    });
  });

  describe('Edge Cases', () => {
    it('should handle very short text', () => {
      const shortResult: ProcessingResult = {
        ...realResult,
        originalText: 'Hi',
        processedText: 'Hi',
        metadata: {
          ...realResult.metadata,
          originalLength: 2,
          processedLength: 2,
          compressionRatio: 100,
        },
      };

      const validation = validateProcessingResult(shortResult);
      expect(validation.valid).toBe(true);

      const metrics = calculateQualityMetrics(shortResult);
      expect(metrics.overallScore).toBeGreaterThanOrEqual(0);
    });

    it('should handle very long text', () => {
      const longResult: ProcessingResult = {
        ...realResult,
        originalText: 'A'.repeat(10000),
        processedText: 'A'.repeat(1000),
        metadata: {
          ...realResult.metadata,
          originalLength: 10000,
          processedLength: 1000,
          compressionRatio: 10,
        },
      };

      const validation = validateProcessingResult(longResult);
      expect(validation.valid).toBe(true);
    });

    it('should handle zero compression', () => {
      const noCompression: ProcessingResult = {
        ...realResult,
        metadata: { ...realResult.metadata, compressionRatio: 100 },
      };

      const metrics = calculateQualityMetrics(noCompression);
      expect(metrics.compression).toBeCloseTo(0, 1);
    });

    it('should handle high expansion', () => {
      const expansion: ProcessingResult = {
        ...realResult,
        metadata: { ...realResult.metadata, compressionRatio: 300 },
      };

      const metrics = calculateQualityMetrics(expansion);
      expect(metrics.compression).toBeLessThan(50);
    });

    it('should handle single result comparison', () => {
      const results = [realResult];
      const comparison = compareResults(results);

      expect(comparison.shortestResult).toBe(realResult);
      expect(comparison.longestResult).toBe(realResult);
      expect(comparison.bestQualityResult).toBe(realResult);
    });
  });

  describe('Metadata Accuracy', () => {
    it('should track generation time', () => {
      const before = new Date();
      const result = { ...realResult, metadata: { ...realResult.metadata, generatedAt: new Date() } };
      const after = new Date();

      expect(result.metadata.generatedAt.getTime()).toBeGreaterThanOrEqual(before.getTime());
      expect(result.metadata.generatedAt.getTime()).toBeLessThanOrEqual(after.getTime());
    });

    it('should track token usage', () => {
      const result = { ...realResult, metadata: { ...realResult.metadata, tokensUsed: 100 } };

      expect(result.metadata.tokensUsed).toBeGreaterThan(0);
    });

    it('should preserve original text', () => {
      const original = 'Original text content';
      const result = { ...realResult, originalText: original };

      expect(result.originalText).toBe(original);
    });
  });
});
