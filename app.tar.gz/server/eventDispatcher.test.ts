/**
 * Event Dispatcher Tests
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import {
  emit,
  on,
  off,
  getEventHistory,
  getEventsByUser,
  getEventStats,
  clearEventHistory,
  getListenerCount,
  emitTranscriptionEvent,
  emitSearchEvent,
  emitRateLimitEvent,
  emitUserEvent,
  getAllEventTypes,
} from './eventDispatcher';

describe('Event Dispatcher', () => {
  beforeEach(() => {
    clearEventHistory();
  });

  afterEach(() => {
    clearEventHistory();
  });

  describe('Event Emission', () => {
    it('should emit event', async () => {
      const event = await emit('transcription.completed', 1, { transcriptionId: 'tr_123' });

      expect(event.id).toBeTruthy();
      expect(event.type).toBe('transcription.completed');
      expect(event.userId).toBe(1);
      expect(event.data.transcriptionId).toBe('tr_123');
    });

    it('should generate unique event IDs', async () => {
      const event1 = await emit('transcription.completed', 1, {});
      const event2 = await emit('transcription.completed', 1, {});

      expect(event1.id).not.toBe(event2.id);
    });

    it('should store event in history', async () => {
      await emit('transcription.completed', 1, {});
      const history = getEventHistory();

      expect(history.length).toBe(1);
    });

    it('should include timestamp', async () => {
      const before = Date.now();
      const event = await emit('transcription.completed', 1, {});
      const after = Date.now();

      expect(event.timestamp).toBeGreaterThanOrEqual(before);
      expect(event.timestamp).toBeLessThanOrEqual(after);
    });
  });

  describe('Event Listeners', () => {
    it('should register event listener', async () => {
      const handler = async () => {};
      on('transcription.completed', handler);

      expect(getListenerCount('transcription.completed')).toBe(1);
    });

    it('should call event listener', async () => {
      let called = false;
      const handler = async () => {
        called = true;
      };

      on('transcription.completed', handler);
      await emit('transcription.completed', 1, {});

      expect(called).toBe(true);
    });

    it('should unregister event listener', async () => {
      const handler = async () => {};
      on('transcription.completed', handler);
      off('transcription.completed', handler);

      expect(getListenerCount('transcription.completed')).toBe(0);
    });

    it('should support multiple listeners', async () => {
      let count = 0;
      const handler1 = async () => { count++; };
      const handler2 = async () => { count++; };

      on('transcription.completed', handler1);
      on('transcription.completed', handler2);
      await emit('transcription.completed', 1, {});

      expect(count).toBe(2);
    });
  });

  describe('Event History', () => {
    it('should get all events', async () => {
      await emit('transcription.completed', 1, {});
      await emit('search.completed', 1, {});

      const history = getEventHistory();
      expect(history.length).toBe(2);
    });

    it('should filter events by type', async () => {
      await emit('transcription.completed', 1, {});
      await emit('transcription.completed', 1, {});
      await emit('search.completed', 1, {});

      const history = getEventHistory('transcription.completed');
      expect(history.length).toBe(2);
    });

    it('should get events by user', async () => {
      await emit('transcription.completed', 1, {});
      await emit('transcription.completed', 2, {});

      const userEvents = getEventsByUser(1);
      expect(userEvents.length).toBe(1);
      expect(userEvents[0].userId).toBe(1);
    });

    it('should filter events by user and type', async () => {
      await emit('transcription.completed', 1, {});
      await emit('search.completed', 1, {});
      await emit('transcription.completed', 2, {});

      const userEvents = getEventsByUser(1, 'transcription.completed');
      expect(userEvents.length).toBe(1);
    });

    it('should clear event history', async () => {
      await emit('transcription.completed', 1, {});
      clearEventHistory();

      const history = getEventHistory();
      expect(history.length).toBe(0);
    });
  });

  describe('Event Statistics', () => {
    it('should calculate event statistics', async () => {
      await emit('transcription.completed', 1, {});
      await emit('transcription.completed', 1, {});
      await emit('search.completed', 2, {});

      const stats = getEventStats();
      expect(stats.totalEvents).toBe(3);
      expect(stats.eventsByType['transcription.completed']).toBe(2);
      expect(stats.eventsByType['search.completed']).toBe(1);
    });

    it('should track events by user', async () => {
      await emit('transcription.completed', 1, {});
      await emit('transcription.completed', 2, {});
      await emit('search.completed', 1, {});

      const stats = getEventStats();
      expect(stats.eventsByUser[1]).toBe(2);
      expect(stats.eventsByUser[2]).toBe(1);
    });

    it('should provide last event', async () => {
      const event1 = await emit('transcription.completed', 1, {});
      const event2 = await emit('search.completed', 1, {});

      const stats = getEventStats();
      expect(stats.lastEvent?.id).toBe(event2.id);
    });
  });

  describe('Specific Event Emitters', () => {
    it('should emit transcription event', async () => {
      const event = await emitTranscriptionEvent(1, 'tr_123', 'completed');

      expect(event.type).toBe('transcription.completed');
      expect(event.data.transcriptionId).toBe('tr_123');
      expect(event.data.status).toBe('completed');
    });

    it('should emit search event', async () => {
      const event = await emitSearchEvent(1, 'q_123', 'completed');

      expect(event.type).toBe('search.completed');
      expect(event.data.queryId).toBe('q_123');
      expect(event.data.status).toBe('completed');
    });

    it('should emit rate limit event', async () => {
      const event = await emitRateLimitEvent(1, 'critical');

      expect(event.type).toBe('rate_limit.critical');
      expect(event.data.severity).toBe('critical');
    });

    it('should emit user event', async () => {
      const event = await emitUserEvent(1, 'created');

      expect(event.type).toBe('user.created');
      expect(event.data.action).toBe('created');
    });
  });

  describe('Event Types', () => {
    it('should list all event types', () => {
      const types = getAllEventTypes();

      expect(types).toContain('transcription.completed');
      expect(types).toContain('search.completed');
      expect(types).toContain('rate_limit.warning');
      expect(types).toContain('user.created');
    });

    it('should have at least 11 event types', () => {
      const types = getAllEventTypes();
      expect(types.length).toBeGreaterThanOrEqual(11);
    });
  });

  describe('Event Data', () => {
    it('should preserve event data', async () => {
      const data = { transcriptionId: 'tr_123', duration: 3600, language: 'en' };
      const event = await emit('transcription.completed', 1, data);

      expect(event.data).toEqual(data);
    });

    it('should support nested data', async () => {
      const data = {
        transcriptionId: 'tr_123',
        metadata: { duration: 3600, language: 'en' },
      };
      const event = await emit('transcription.completed', 1, data);

      expect(event.data.metadata.duration).toBe(3600);
    });
  });

  describe('Listener Management', () => {
    it('should get total listener count', () => {
      const handler1 = async () => {};
      const handler2 = async () => {};

      on('transcription.completed', handler1);
      on('search.completed', handler2);

      expect(getListenerCount()).toBe(2);
    });

    it('should handle listener errors gracefully', async () => {
      const errorHandler = async () => {
        throw new Error('Handler error');
      };

      on('transcription.completed', errorHandler);

      // Should not throw
      const event = await emit('transcription.completed', 1, {});
      expect(event).toBeTruthy();
    });
  });

  describe('Event Ordering', () => {
    it('should maintain event order', async () => {
      const event1 = await emit('transcription.completed', 1, { order: 1 });
      const event2 = await emit('transcription.completed', 1, { order: 2 });
      const event3 = await emit('transcription.completed', 1, { order: 3 });

      const history = getEventHistory();
      expect(history[0].data.order).toBe(1);
      expect(history[1].data.order).toBe(2);
      expect(history[2].data.order).toBe(3);
    });
  });

  describe('Event Limits', () => {
    it('should maintain history limit', async () => {
      // Emit many events
      for (let i = 0; i < 100; i++) {
        await emit('transcription.completed', 1, { index: i });
      }

      const history = getEventHistory();
      expect(history.length).toBeLessThanOrEqual(10000);
    });
  });
});
