/**
 * Analytics Data Collector
 * Collects performance metrics and analytics for dashboard visualization
 */

import { setCache, getCache, pushToList, getList, getCacheKey } from './redis';

export interface AnalyticsData {
  timestamp: number;
  queryTime: number;
  cacheHit: boolean;
  queryMode: string;
  resultCount: number;
  userId: number;
}

export interface PerformanceMetrics {
  avgQueryTime: number;
  p95QueryTime: number;
  p99QueryTime: number;
  cacheHitRate: number;
  totalQueries: number;
  queriesByMode: Record<string, number>;
}

export interface SystemMetrics {
  memoryUsage: number;
  cpuUsage: number;
  activeConnections: number;
  uptime: number;
}

const ANALYTICS_RETENTION_HOURS = 24;
const METRICS_UPDATE_INTERVAL = 60000; // 1 minute

/**
 * Record query analytics
 */
export async function recordQueryAnalytics(data: AnalyticsData): Promise<void> {
  try {
    const key = getCacheKey('analytics:queries', new Date().toISOString().split('T')[0]);
    await pushToList(key, [data], 10000);

    // Update real-time metrics
    await updateRealTimeMetrics(data);
  } catch (error) {
    console.error('Failed to record query analytics:', error);
  }
}

/**
 * Update real-time metrics
 */
async function updateRealTimeMetrics(data: AnalyticsData): Promise<void> {
  try {
    const metricsKey = getCacheKey('metrics:realtime');
    const current = (await getCache<PerformanceMetrics>(metricsKey)) || {
      avgQueryTime: 0,
      p95QueryTime: 0,
      p99QueryTime: 0,
      cacheHitRate: 0,
      totalQueries: 0,
      queriesByMode: {},
    };

    // Update metrics
    current.totalQueries++;
    current.avgQueryTime = (current.avgQueryTime * (current.totalQueries - 1) + data.queryTime) / current.totalQueries;
    current.cacheHitRate = (current.cacheHitRate * (current.totalQueries - 1) + (data.cacheHit ? 1 : 0)) / current.totalQueries;

    // Track by mode
    if (!current.queriesByMode[data.queryMode]) {
      current.queriesByMode[data.queryMode] = 0;
    }
    current.queriesByMode[data.queryMode]++;

    await setCache(metricsKey, current, 3600);
  } catch (error) {
    console.error('Failed to update real-time metrics:', error);
  }
}

/**
 * Get performance metrics for dashboard
 */
export async function getPerformanceMetrics(hoursBack: number = 24): Promise<PerformanceMetrics> {
  try {
    const metricsKey = getCacheKey('metrics:realtime');
    const metrics = await getCache<PerformanceMetrics>(metricsKey);

    if (!metrics) {
      return {
        avgQueryTime: 0,
        p95QueryTime: 0,
        p99QueryTime: 0,
        cacheHitRate: 0,
        totalQueries: 0,
        queriesByMode: {},
      };
    }

    return metrics;
  } catch (error) {
    console.error('Failed to get performance metrics:', error);
    return {
      avgQueryTime: 0,
      p95QueryTime: 0,
      p99QueryTime: 0,
      cacheHitRate: 0,
      totalQueries: 0,
      queriesByMode: {},
    };
  }
}

/**
 * Get query time distribution for percentile calculation
 */
export async function getQueryTimeDistribution(hoursBack: number = 24): Promise<number[]> {
  try {
    const dates = [];
    for (let i = 0; i < hoursBack; i++) {
      const date = new Date();
      date.setHours(date.getHours() - i);
      dates.push(date.toISOString().split('T')[0]);
    }

    const allQueryTimes: number[] = [];

    for (const date of dates) {
      const key = getCacheKey('analytics:queries', date);
      const queries = await getList<AnalyticsData>(key, 0, -1);
      allQueryTimes.push(...queries.map((q) => q.queryTime));
    }

    return allQueryTimes.sort((a, b) => a - b);
  } catch (error) {
    console.error('Failed to get query time distribution:', error);
    return [];
  }
}

/**
 * Calculate percentile from sorted array
 */
export function calculatePercentile(sortedArray: number[], percentile: number): number {
  if (sortedArray.length === 0) return 0;
  const index = Math.ceil((percentile / 100) * sortedArray.length) - 1;
  return sortedArray[Math.max(0, index)];
}

/**
 * Get hourly query statistics
 */
export async function getHourlyQueryStats(hoursBack: number = 24): Promise<Array<{
  hour: string;
  queryCount: number;
  avgTime: number;
  cacheHitRate: number;
}>> {
  try {
    const stats = [];

    for (let i = 0; i < hoursBack; i++) {
      const date = new Date();
      date.setHours(date.getHours() - i);
      const dateStr = date.toISOString().split('T')[0];
      const hourStr = date.toISOString().substring(0, 13);

      const key = getCacheKey('analytics:queries', dateStr);
      const queries = await getList<AnalyticsData>(key, 0, -1);

      const hourQueries = queries.filter((q) => {
        const qTime = new Date(q.timestamp);
        return qTime.toISOString().substring(0, 13) === hourStr;
      });

      if (hourQueries.length > 0) {
        const avgTime = hourQueries.reduce((sum, q) => sum + q.queryTime, 0) / hourQueries.length;
        const cacheHits = hourQueries.filter((q) => q.cacheHit).length;
        const cacheHitRate = (cacheHits / hourQueries.length) * 100;

        stats.push({
          hour: hourStr,
          queryCount: hourQueries.length,
          avgTime,
          cacheHitRate,
        });
      }
    }

    return stats;
  } catch (error) {
    console.error('Failed to get hourly query stats:', error);
    return [];
  }
}

/**
 * Get query mode distribution
 */
export async function getQueryModeDistribution(): Promise<Record<string, number>> {
  try {
    const metrics = await getPerformanceMetrics();
    return metrics.queriesByMode;
  } catch (error) {
    console.error('Failed to get query mode distribution:', error);
    return {};
  }
}

/**
 * Get top slow queries
 */
export async function getTopSlowQueries(limit: number = 10): Promise<AnalyticsData[]> {
  try {
    const dates = [];
    for (let i = 0; i < 24; i++) {
      const date = new Date();
      date.setHours(date.getHours() - i);
      dates.push(date.toISOString().split('T')[0]);
    }

    const allQueries: AnalyticsData[] = [];

    for (const date of dates) {
      const key = getCacheKey('analytics:queries', date);
      const queries = await getList<AnalyticsData>(key, 0, -1);
      allQueries.push(...queries);
    }

    return allQueries.sort((a, b) => b.queryTime - a.queryTime).slice(0, limit);
  } catch (error) {
    console.error('Failed to get top slow queries:', error);
    return [];
  }
}

/**
 * Get user activity statistics
 */
export async function getUserActivityStats(): Promise<{
  totalUsers: number;
  activeUsers24h: number;
  averageQueriesPerUser: number;
}> {
  try {
    const metrics = await getPerformanceMetrics();

    return {
      totalUsers: 0, // Would need to query database
      activeUsers24h: 0, // Would need to query database
      averageQueriesPerUser: metrics.totalQueries > 0 ? metrics.totalQueries / Math.max(1, metrics.totalQueries) : 0,
    };
  } catch (error) {
    console.error('Failed to get user activity stats:', error);
    return {
      totalUsers: 0,
      activeUsers24h: 0,
      averageQueriesPerUser: 0,
    };
  }
}

/**
 * Record system metrics
 */
export async function recordSystemMetrics(metrics: SystemMetrics): Promise<void> {
  try {
    const key = getCacheKey('metrics:system', new Date().toISOString().split('T')[0]);
    await pushToList(key, [metrics], 1440); // Keep 24 hours of minute-level data
  } catch (error) {
    console.error('Failed to record system metrics:', error);
  }
}

/**
 * Get system metrics history
 */
export async function getSystemMetricsHistory(hoursBack: number = 24): Promise<SystemMetrics[]> {
  try {
    const dates = [];
    for (let i = 0; i < hoursBack; i++) {
      const date = new Date();
      date.setHours(date.getHours() - i);
      dates.push(date.toISOString().split('T')[0]);
    }

    const allMetrics: SystemMetrics[] = [];

    for (const date of dates) {
      const key = getCacheKey('metrics:system', date);
      const metrics = await getList<SystemMetrics>(key, 0, -1);
      allMetrics.push(...metrics);
    }

    return allMetrics;
  } catch (error) {
    console.error('Failed to get system metrics history:', error);
    return [];
  }
}

/**
 * Clear old analytics data
 */
export async function cleanupOldAnalytics(): Promise<void> {
  try {
    const cutoffDate = new Date();
    cutoffDate.setHours(cutoffDate.getHours() - ANALYTICS_RETENTION_HOURS);
    const cutoffDateStr = cutoffDate.toISOString().split('T')[0];

    // In a real implementation, would delete Redis keys for dates before cutoffDate
    console.log(`Analytics cleanup: removing data before ${cutoffDateStr}`);
  } catch (error) {
    console.error('Failed to cleanup old analytics:', error);
  }
}
