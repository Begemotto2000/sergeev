/**
 * Search Filters Tests
 */

import { describe, it, expect } from 'vitest';
import {
  buildQdrantFilter,
  optimizeQuery,
  calculateRelevanceScore,
  applyFilters,
  sortResults,
  paginateResults,
  processSearchResults,
  getAvailableFilterOptions,
  validateSearchFilters,
  type SearchFilters,
  type FilteredResult,
} from './searchFilters';

describe('Search Filters', () => {
  const mockResults: FilteredResult[] = [
    {
      id: '1',
      title: 'Result 1',
      content: 'Sample content',
      confidence: 0.95,
      language: 'en',
      sourceType: 'document',
      tags: ['tag1', 'tag2'],
      createdAt: new Date('2026-05-01'),
      relevanceScore: 95,
    },
    {
      id: '2',
      title: 'Result 2',
      content: 'Another content',
      confidence: 0.85,
      language: 'ru',
      sourceType: 'video',
      tags: ['tag2', 'tag3'],
      createdAt: new Date('2026-05-02'),
      relevanceScore: 85,
    },
    {
      id: '3',
      title: 'Result 3',
      content: 'More content',
      confidence: 0.75,
      language: 'en',
      sourceType: 'document',
      tags: ['tag1'],
      createdAt: new Date('2026-05-03'),
      relevanceScore: 75,
    },
  ];

  describe('Query Optimization', () => {
    it('should optimize query', () => {
      const optimized = optimizeQuery('  Hello   World  ');

      expect(optimized).toBe('hello world');
    });

    it('should remove stop words', () => {
      const optimized = optimizeQuery('the quick brown fox');

      expect(optimized).not.toContain('the');
    });

    it('should preserve short queries', () => {
      const optimized = optimizeQuery('a b');

      expect(optimized).toBe('a b');
    });
  });

  describe('Relevance Scoring', () => {
    it('should calculate relevance score', () => {
      const score = calculateRelevanceScore('test', 'test content', 0.9);

      expect(score).toBeGreaterThan(0);
      expect(score).toBeLessThanOrEqual(100);
    });

    it('should boost exact matches', () => {
      const scoreWithMatch = calculateRelevanceScore('test', 'test content', 0.8);
      const scoreWithoutMatch = calculateRelevanceScore('xyz', 'test content', 0.8);

      expect(scoreWithMatch).toBeGreaterThan(scoreWithoutMatch);
    });

    it('should boost high confidence', () => {
      const scoreHigh = calculateRelevanceScore('test', 'content', 0.9, { confidence: 0.95 });
      const scoreLow = calculateRelevanceScore('test', 'content', 0.9, { confidence: 0.5 });

      expect(scoreHigh).toBeGreaterThan(scoreLow);
    });
  });

  describe('Filter Application', () => {
    it('should apply language filter', () => {
      const filters: SearchFilters = {
        query: 'test',
        languages: ['en'],
      };

      const filtered = applyFilters(mockResults, filters);

      expect(filtered.every((r) => r.language === 'en')).toBe(true);
    });

    it('should apply source type filter', () => {
      const filters: SearchFilters = {
        query: 'test',
        sourceTypes: ['document'],
      };

      const filtered = applyFilters(mockResults, filters);

      expect(filtered.every((r) => r.sourceType === 'document')).toBe(true);
    });

    it('should apply confidence filter', () => {
      const filters: SearchFilters = {
        query: 'test',
        confidenceMin: 0.8,
      };

      const filtered = applyFilters(mockResults, filters);

      expect(filtered.every((r) => r.confidence >= 0.8)).toBe(true);
    });

    it('should apply multiple filters', () => {
      const filters: SearchFilters = {
        query: 'test',
        languages: ['en'],
        sourceTypes: ['document'],
        confidenceMin: 0.8,
      };

      const filtered = applyFilters(mockResults, filters);

      expect(filtered.length).toBeGreaterThan(0);
      expect(filtered.every((r) => r.language === 'en')).toBe(true);
      expect(filtered.every((r) => r.sourceType === 'document')).toBe(true);
    });
  });

  describe('Sorting', () => {
    it('should sort by relevance', () => {
      const filters: SearchFilters = {
        query: 'test',
        sortBy: 'relevance',
        sortOrder: 'desc',
      };

      const sorted = sortResults(mockResults, filters);

      expect(sorted[0].relevanceScore).toBeGreaterThanOrEqual(sorted[1].relevanceScore);
    });

    it('should sort by date', () => {
      const filters: SearchFilters = {
        query: 'test',
        sortBy: 'date',
        sortOrder: 'desc',
      };

      const sorted = sortResults(mockResults, filters);

      expect(sorted[0].createdAt.getTime()).toBeGreaterThanOrEqual(sorted[1].createdAt.getTime());
    });

    it('should sort ascending', () => {
      const filters: SearchFilters = {
        query: 'test',
        sortBy: 'confidence',
        sortOrder: 'asc',
      };

      const sorted = sortResults(mockResults, filters);

      expect(sorted[0].confidence).toBeLessThanOrEqual(sorted[1].confidence);
    });
  });

  describe('Pagination', () => {
    it('should paginate results', () => {
      const filters: SearchFilters = {
        query: 'test',
        limit: 2,
        offset: 0,
      };

      const paginated = paginateResults(mockResults, filters);

      expect(paginated.length).toBe(2);
    });

    it('should handle offset', () => {
      const filters: SearchFilters = {
        query: 'test',
        limit: 2,
        offset: 1,
      };

      const paginated = paginateResults(mockResults, filters);

      expect(paginated[0].id).toBe('2');
    });
  });

  describe('Complete Processing', () => {
    it('should process results with all operations', () => {
      const filters: SearchFilters = {
        query: 'test',
        languages: ['en'],
        sortBy: 'relevance',
        sortOrder: 'desc',
        limit: 2,
        offset: 0,
      };

      const result = processSearchResults(mockResults, filters);

      expect(result).toHaveProperty('results');
      expect(result).toHaveProperty('total');
      expect(result).toHaveProperty('hasMore');
      expect(result.results.length).toBeLessThanOrEqual(2);
    });

    it('should indicate if more results available', () => {
      const filters: SearchFilters = {
        query: 'test',
        limit: 2,
        offset: 0,
      };

      const result = processSearchResults(mockResults, filters);

      expect(result.hasMore).toBe(true);
    });
  });

  describe('Filter Options', () => {
    it('should get available filter options', () => {
      const options = getAvailableFilterOptions(mockResults);

      expect(options).toHaveProperty('languages');
      expect(options).toHaveProperty('sourceTypes');
      expect(options).toHaveProperty('tags');
      expect(options).toHaveProperty('dateRange');
      expect(options).toHaveProperty('confidenceRange');
    });

    it('should list all languages', () => {
      const options = getAvailableFilterOptions(mockResults);

      expect(options.languages).toContain('en');
      expect(options.languages).toContain('ru');
    });

    it('should list all source types', () => {
      const options = getAvailableFilterOptions(mockResults);

      expect(options.sourceTypes).toContain('document');
      expect(options.sourceTypes).toContain('video');
    });

    it('should list all tags', () => {
      const options = getAvailableFilterOptions(mockResults);

      expect(options.tags).toContain('tag1');
      expect(options.tags).toContain('tag2');
      expect(options.tags).toContain('tag3');
    });
  });

  describe('Validation', () => {
    it('should validate search filters', () => {
      const filters: SearchFilters = {
        query: 'test',
      };

      const validation = validateSearchFilters(filters);

      expect(validation.valid).toBe(true);
      expect(validation.errors.length).toBe(0);
    });

    it('should reject empty query', () => {
      const filters: SearchFilters = {
        query: '',
      };

      const validation = validateSearchFilters(filters);

      expect(validation.valid).toBe(false);
      expect(validation.errors).toContain('Query is required');
    });

    it('should reject invalid confidence range', () => {
      const filters: SearchFilters = {
        query: 'test',
        confidenceMin: 0.8,
        confidenceMax: 0.5,
      };

      const validation = validateSearchFilters(filters);

      expect(validation.valid).toBe(false);
    });

    it('should reject invalid limit', () => {
      const filters: SearchFilters = {
        query: 'test',
        limit: 2000,
      };

      const validation = validateSearchFilters(filters);

      expect(validation.valid).toBe(false);
    });
  });

  describe('Qdrant Filter Building', () => {
    it('should build Qdrant filter', () => {
      const filters: SearchFilters = {
        query: 'test',
        languages: ['en', 'ru'],
      };

      const qdrantFilter = buildQdrantFilter(filters);

      expect(qdrantFilter).toHaveProperty('language');
    });

    it('should include date range in filter', () => {
      const filters: SearchFilters = {
        query: 'test',
        dateRange: {
          start: new Date('2026-05-01'),
          end: new Date('2026-05-31'),
        },
      };

      const qdrantFilter = buildQdrantFilter(filters);

      expect(qdrantFilter).toHaveProperty('date_range');
    });
  });
});
