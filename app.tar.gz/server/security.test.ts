/**
 * Security Tests
 */

import { describe, it, expect } from 'vitest';
import {
  generateCSRFToken,
  validateCSRFToken,
  hashPassword,
  verifyPassword,
  sanitizeInput,
  validateEmail,
  validateURL,
  detectSQLInjection,
  detectXSSAttempt,
  generateAPIKey,
  hashAPIKey,
  validateAPIKeyFormat,
  getSecurityHeaders,
} from './security';

describe('Security & Hardening', () => {
  describe('CSRF Protection', () => {
    it('should generate CSRF token', () => {
      const token = generateCSRFToken();

      expect(token).toBeTruthy();
      expect(token.length).toBeGreaterThan(0);
    });

    it('should validate matching CSRF tokens', () => {
      const token = generateCSRFToken();
      const valid = validateCSRFToken(token, token);

      expect(valid).toBe(true);
    });

    it('should reject mismatched CSRF tokens', () => {
      const token1 = generateCSRFToken();
      const token2 = generateCSRFToken();
      const valid = validateCSRFToken(token1, token2);

      expect(valid).toBe(false);
    });
  });

  describe('Password Hashing', () => {
    it('should hash password', async () => {
      const password = 'SecurePassword123!';
      const hash = await hashPassword(password);

      expect(hash).toBeTruthy();
      expect(hash).toContain(':');
    });

    it('should verify correct password', async () => {
      const password = 'SecurePassword123!';
      const hash = await hashPassword(password);
      const valid = await verifyPassword(password, hash);

      expect(valid).toBe(true);
    });

    it('should reject incorrect password', async () => {
      const password = 'SecurePassword123!';
      const hash = await hashPassword(password);
      const valid = await verifyPassword('WrongPassword', hash);

      expect(valid).toBe(false);
    });

    it('should generate different hashes for same password', async () => {
      const password = 'SecurePassword123!';
      const hash1 = await hashPassword(password);
      const hash2 = await hashPassword(password);

      expect(hash1).not.toBe(hash2);
    });
  });

  describe('Input Sanitization', () => {
    it('should sanitize input', () => {
      const input = '<script>alert("xss")</script>';
      const sanitized = sanitizeInput(input);

      expect(sanitized).not.toContain('<');
      expect(sanitized).not.toContain('>');
    });

    it('should remove quotes', () => {
      const input = 'Test "quoted" \'text\'';
      const sanitized = sanitizeInput(input);

      expect(sanitized).not.toContain('"');
      expect(sanitized).not.toContain("'");
    });

    it('should trim whitespace', () => {
      const input = '   test   ';
      const sanitized = sanitizeInput(input);

      expect(sanitized).toBe('test');
    });

    it('should limit length', () => {
      const input = 'a'.repeat(2000);
      const sanitized = sanitizeInput(input);

      expect(sanitized.length).toBeLessThanOrEqual(1000);
    });
  });

  describe('Email Validation', () => {
    it('should validate valid email', () => {
      const valid = validateEmail('test@example.com');

      expect(valid).toBe(true);
    });

    it('should reject invalid email', () => {
      const valid = validateEmail('invalid-email');

      expect(valid).toBe(false);
    });

    it('should reject email without domain', () => {
      const valid = validateEmail('test@');

      expect(valid).toBe(false);
    });

    it('should reject email without @', () => {
      const valid = validateEmail('testexample.com');

      expect(valid).toBe(false);
    });
  });

  describe('URL Validation', () => {
    it('should validate valid URL', () => {
      const valid = validateURL('https://example.com');

      expect(valid).toBe(true);
    });

    it('should reject invalid URL', () => {
      const valid = validateURL('not a url');

      expect(valid).toBe(false);
    });

    it('should validate URL with path', () => {
      const valid = validateURL('https://example.com/path/to/resource');

      expect(valid).toBe(true);
    });
  });

  describe('SQL Injection Detection', () => {
    it('should detect SELECT injection', () => {
      const detected = detectSQLInjection("'; SELECT * FROM users; --");

      expect(detected).toBe(true);
    });

    it('should detect UNION injection', () => {
      const detected = detectSQLInjection("' UNION SELECT * FROM passwords --");

      expect(detected).toBe(true);
    });

    it('should reject normal input', () => {
      const detected = detectSQLInjection('normal user input');

      expect(detected).toBe(false);
    });

    it('should detect DROP injection', () => {
      const detected = detectSQLInjection("'; DROP TABLE users; --");

      expect(detected).toBe(true);
    });
  });

  describe('XSS Detection', () => {
    it('should detect script tag', () => {
      const detected = detectXSSAttempt('<script>alert("xss")</script>');

      expect(detected).toBe(true);
    });

    it('should detect event handler', () => {
      const detected = detectXSSAttempt('<img onerror="alert(1)">');

      expect(detected).toBe(true);
    });

    it('should detect iframe', () => {
      const detected = detectXSSAttempt('<iframe src="evil.com"></iframe>');

      expect(detected).toBe(true);
    });

    it('should detect javascript protocol', () => {
      const detected = detectXSSAttempt('<a href="javascript:alert(1)">Click</a>');

      expect(detected).toBe(true);
    });

    it('should reject normal input', () => {
      const detected = detectXSSAttempt('normal user input');

      expect(detected).toBe(false);
    });
  });

  describe('API Key Management', () => {
    it('should generate API key', () => {
      const key = generateAPIKey();

      expect(key).toBeTruthy();
      expect(key.length).toBe(64);
    });

    it('should hash API key', () => {
      const key = generateAPIKey();
      const hash = hashAPIKey(key);

      expect(hash).toBeTruthy();
      expect(hash).not.toBe(key);
    });

    it('should validate API key format', () => {
      const key = generateAPIKey();
      const valid = validateAPIKeyFormat(key);

      expect(valid).toBe(true);
    });

    it('should reject invalid API key format', () => {
      const valid = validateAPIKeyFormat('invalid-key');

      expect(valid).toBe(false);
    });

    it('should generate unique API keys', () => {
      const key1 = generateAPIKey();
      const key2 = generateAPIKey();

      expect(key1).not.toBe(key2);
    });
  });

  describe('Security Headers', () => {
    it('should get security headers', () => {
      const headers = getSecurityHeaders();

      expect(headers).toHaveProperty('Strict-Transport-Security');
      expect(headers).toHaveProperty('X-Content-Type-Options');
      expect(headers).toHaveProperty('X-Frame-Options');
      expect(headers).toHaveProperty('X-XSS-Protection');
      expect(headers).toHaveProperty('Content-Security-Policy');
    });

    it('should include HSTS header', () => {
      const headers = getSecurityHeaders();

      expect(headers['Strict-Transport-Security']).toContain('max-age');
    });

    it('should include CSP header', () => {
      const headers = getSecurityHeaders();

      expect(headers['Content-Security-Policy']).toBeTruthy();
    });

    it('should include X-Frame-Options', () => {
      const headers = getSecurityHeaders();

      expect(headers['X-Frame-Options']).toBe('DENY');
    });
  });

  describe('Data Encryption', () => {
    it('should encrypt and decrypt data', () => {
      const data = 'sensitive data';
      const key = '0'.repeat(64); // 32 bytes in hex

      const encrypted = encryptData(data, key);
      expect(encrypted).not.toBe(data);

      const decrypted = decryptData(encrypted, key);
      expect(decrypted).toBe(data);
    });

    it('should produce different ciphertexts for same plaintext', () => {
      const data = 'sensitive data';
      const key = '0'.repeat(64);

      const encrypted1 = encryptData(data, key);
      const encrypted2 = encryptData(data, key);

      expect(encrypted1).not.toBe(encrypted2);
    });
  });

  describe('Security Compliance', () => {
    it('should check security compliance', async () => {
      const compliance = await checkSecurityCompliance();

      expect(compliance).toHaveProperty('compliant');
      expect(compliance).toHaveProperty('issues');
      expect(compliance).toHaveProperty('score');
    });

    it('should provide compliance score', async () => {
      const compliance = await checkSecurityCompliance();

      expect(compliance.score).toBeGreaterThanOrEqual(0);
      expect(compliance.score).toBeLessThanOrEqual(100);
    });
  });

  describe('Security Report', () => {
    it('should generate security report', async () => {
      const report = await generateSecurityReport();

      expect(report).toHaveProperty('timestamp');
      expect(report).toHaveProperty('totalEvents');
      expect(report).toHaveProperty('criticalEvents');
      expect(report).toHaveProperty('topThreats');
      expect(report).toHaveProperty('recommendations');
    });

    it('should include recommendations', async () => {
      const report = await generateSecurityReport();

      expect(Array.isArray(report.recommendations)).toBe(true);
    });
  });
});

import { encryptData, decryptData, checkSecurityCompliance, generateSecurityReport } from './security';
