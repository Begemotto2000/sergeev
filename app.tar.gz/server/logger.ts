/**
 * Production-Grade Logger Service
 * File-based logging with rotation and metrics
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const logsDir = '/var/log/sergeev';
const maxLogSize = 10 * 1024 * 1024; // 10MB
const maxLogFiles = 10;

// Ensure logs directory exists
if (!fs.existsSync(logsDir)) {
  try {
    fs.mkdirSync(logsDir, { recursive: true, mode: 0o755 });
  } catch (err) {
    console.error('Failed to create logs directory:', err);
  }
}

export enum LogLevel {
  DEBUG = 'DEBUG',
  INFO = 'INFO',
  WARN = 'WARN',
  ERROR = 'ERROR',
  FATAL = 'FATAL'
}

interface LogEntry {
  timestamp: string;
  level: LogLevel;
  service: string;
  message: string;
  context?: Record<string, any>;
  error?: string;
}

class Logger {
  private service: string;
  private logFile: string;

  constructor(service: string) {
    this.service = service;
    this.logFile = path.join(logsDir, `${service}.log`);
  }

  private formatEntry(entry: LogEntry): string {
    const contextStr = entry.context ? ` | ${JSON.stringify(entry.context)}` : '';
    const errorStr = entry.error ? ` | ERROR: ${entry.error}` : '';
    return `[${entry.timestamp}] [${entry.level}] ${entry.message}${contextStr}${errorStr}\n`;
  }

  private rotateLogIfNeeded(): void {
    try {
      if (!fs.existsSync(this.logFile)) return;

      const stat = fs.statSync(this.logFile);
      if (stat.size < maxLogSize) return;

      // Rotate logs
      for (let i = maxLogFiles - 1; i > 0; i--) {
        const oldFile = `${this.logFile}.${i}`;
        const newFile = `${this.logFile}.${i + 1}`;
        if (fs.existsSync(oldFile)) {
          fs.renameSync(oldFile, newFile);
        }
      }

      fs.renameSync(this.logFile, `${this.logFile}.1`);
    } catch (err) {
      console.error('Log rotation error:', err);
    }
  }

  private write(level: LogLevel, message: string, context?: Record<string, any>, error?: Error): void {
    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      service: this.service,
      message,
      context,
      error: error?.stack || error?.message
    };

    const formatted = this.formatEntry(entry);

    // Console output
    const color = {
      [LogLevel.DEBUG]: '\x1b[36m', // Cyan
      [LogLevel.INFO]: '\x1b[32m',  // Green
      [LogLevel.WARN]: '\x1b[33m',  // Yellow
      [LogLevel.ERROR]: '\x1b[31m', // Red
      [LogLevel.FATAL]: '\x1b[35m'  // Magenta
    }[level];
    const reset = '\x1b[0m';

    console.log(`${color}${formatted}${reset}`);

    // File output
    try {
      this.rotateLogIfNeeded();
      fs.appendFileSync(this.logFile, formatted, { mode: 0o644 });
    } catch (err) {
      console.error('Failed to write log:', err);
    }
  }

  debug(message: string, context?: Record<string, any>): void {
    this.write(LogLevel.DEBUG, message, context);
  }

  info(message: string, context?: Record<string, any>): void {
    this.write(LogLevel.INFO, message, context);
  }

  warn(message: string, context?: Record<string, any>): void {
    this.write(LogLevel.WARN, message, context);
  }

  error(message: string, error?: Error, context?: Record<string, any>): void {
    this.write(LogLevel.ERROR, message, context, error);
  }

  fatal(message: string, error?: Error, context?: Record<string, any>): void {
    this.write(LogLevel.FATAL, message, context, error);
  }
}

// Metrics collector
export class Metrics {
  private static instance: Metrics;
  private metrics: Map<string, number> = new Map();
  private logger: Logger;

  private constructor() {
    this.logger = new Logger('metrics');
  }

  static getInstance(): Metrics {
    if (!Metrics.instance) {
      Metrics.instance = new Metrics();
    }
    return Metrics.instance;
  }

  increment(key: string, value: number = 1): void {
    const current = this.metrics.get(key) || 0;
    this.metrics.set(key, current + value);
  }

  set(key: string, value: number): void {
    this.metrics.set(key, value);
  }

  get(key: string): number {
    return this.metrics.get(key) || 0;
  }

  getAll(): Record<string, number> {
    const result: Record<string, number> = {};
    this.metrics.forEach((value, key) => {
      result[key] = value;
    });
    return result;
  }

  report(): void {
    this.logger.info('Metrics Report', this.getAll());
  }
}

export function createLogger(service: string): Logger {
  return new Logger(service);
}

// Global logger instance
export const logger = createLogger('app');
