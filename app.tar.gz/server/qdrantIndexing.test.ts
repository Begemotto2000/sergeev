import { describe, it, expect, vi } from 'vitest';
import {
  normalizeVector,
  cosineSimilarity,
  validateEmbedding,
  createIndexingJob,
  updateIndexingJob,
  calculateIndexingStats,
} from './qdrantIndexing';

describe('Qdrant Indexing Pipeline', () => {
  describe('Vector Operations', () => {
    it('should normalize vector to unit length', () => {
      const vector = [3, 4]; // magnitude = 5
      const normalized = normalizeVector(vector);

      expect(normalized).toHaveLength(2);
      expect(normalized[0]).toBeCloseTo(0.6, 5);
      expect(normalized[1]).toBeCloseTo(0.8, 5);
    });

    it('should handle zero vector', () => {
      const vector = [0, 0, 0];
      const normalized = normalizeVector(vector);

      expect(normalized).toEqual([0, 0, 0]);
    });

    it('should calculate cosine similarity', () => {
      const vec1 = [1, 0, 0];
      const vec2 = [1, 0, 0];
      const similarity = cosineSimilarity(vec1, vec2);

      expect(similarity).toBeCloseTo(1, 5); // Same vectors = similarity 1
    });

    it('should calculate orthogonal vectors similarity', () => {
      const vec1 = [1, 0, 0];
      const vec2 = [0, 1, 0];
      const similarity = cosineSimilarity(vec1, vec2);

      expect(similarity).toBeCloseTo(0, 5); // Orthogonal = similarity 0
    });

    it('should throw error for mismatched dimensions', () => {
      const vec1 = [1, 0];
      const vec2 = [1, 0, 0];

      expect(() => cosineSimilarity(vec1, vec2)).toThrow();
    });

    it('should find identical vectors as most similar', () => {
      const vec = [0.5, 0.3, 0.2];
      const similarity = cosineSimilarity(vec, vec);

      expect(similarity).toBeCloseTo(1, 5);
    });

    it('should find opposite vectors as least similar', () => {
      const vec1 = [1, 0, 0];
      const vec2 = [-1, 0, 0];
      const similarity = cosineSimilarity(vec1, vec2);

      expect(similarity).toBeCloseTo(-1, 5);
    });

    it('should rank similarities correctly', () => {
      const vec1 = [1, 0, 0];
      const vec2 = [0.9, 0.1, 0]; // More similar
      const vec3 = [0.5, 0.5, 0]; // Less similar

      const sim12 = cosineSimilarity(vec1, vec2);
      const sim13 = cosineSimilarity(vec1, vec3);

      expect(sim12).toBeGreaterThan(sim13);
    });

    it('should normalize very small vectors', () => {
      const vector = [0.0001, 0.0001, 0.0001];
      const normalized = normalizeVector(vector);

      expect(normalized).toHaveLength(3);
      const magnitude = Math.sqrt(
        normalized.reduce((sum, val) => sum + val * val, 0)
      );
      expect(magnitude).toBeCloseTo(1, 5);
    });
  });

  describe('Embedding Validation', () => {
    it('should validate correct embedding', () => {
      const embedding = {
        chunkId: 'chunk_1',
        vector: [0.5, -0.3, 0.8],
        metadata: {
          videoId: 'video_1',
          startTime: '00:00:00',
          endTime: '00:00:05',
          text: 'Test text',
          tokenCount: 10,
          characterCount: 50,
          formatType: 'ОТВЕТ',
        },
      };

      const result = validateEmbedding(embedding);

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('should reject embedding with missing chunkId', () => {
      const embedding = {
        chunkId: '',
        vector: [0.5],
        metadata: {
          videoId: 'video_1',
          startTime: '00:00:00',
          endTime: '00:00:05',
          text: 'Test',
          tokenCount: 10,
          characterCount: 50,
          formatType: 'ОТВЕТ',
        },
      };

      const result = validateEmbedding(embedding);

      expect(result.valid).toBe(false);
    });

    it('should reject embedding with out-of-range values', () => {
      const embedding = {
        chunkId: 'chunk_1',
        vector: [0.5, 1.5, 0.8], // 1.5 is out of range
        metadata: {
          videoId: 'video_1',
          startTime: '00:00:00',
          endTime: '00:00:05',
          text: 'Test',
          tokenCount: 10,
          characterCount: 50,
          formatType: 'ОТВЕТ',
        },
      };

      const result = validateEmbedding(embedding);

      expect(result.valid).toBe(false);
      expect(result.errors.some((e) => e.includes('out of range'))).toBe(true);
    });

    it('should reject embedding with non-numeric vector values', () => {
      const embedding = {
        chunkId: 'chunk_1',
        vector: [0.5, 'invalid', 0.8] as any,
        metadata: {
          videoId: 'video_1',
          startTime: '00:00:00',
          endTime: '00:00:05',
          text: 'Test',
          tokenCount: 10,
          characterCount: 50,
          formatType: 'ОТВЕТ',
        },
      };

      const result = validateEmbedding(embedding);

      expect(result.valid).toBe(false);
    });

    it('should reject embedding with missing metadata', () => {
      const embedding = {
        chunkId: 'chunk_1',
        vector: [0.5, 0.3, 0.8],
        metadata: undefined,
      } as any;

      const result = validateEmbedding(embedding);

      expect(result.valid).toBe(false);
    });

    it('should reject embedding with empty vector', () => {
      const embedding = {
        chunkId: 'chunk_1',
        vector: [],
        metadata: {
          videoId: 'video_1',
          startTime: '00:00:00',
          endTime: '00:00:05',
          text: 'Test',
          tokenCount: 10,
          characterCount: 50,
          formatType: 'ОТВЕТ',
        },
      };

      const result = validateEmbedding(embedding);

      expect(result.valid).toBe(false);
    });
  });

  describe('Indexing Job Management', () => {
    it('should create indexing job', () => {
      const job = createIndexingJob('video_1', 100);

      expect(job.videoId).toBe('video_1');
      expect(job.chunkCount).toBe(100);
      expect(job.status).toBe('pending');
      expect(job.processedCount).toBe(0);
    });

    it('should have unique job IDs', async () => {
      const job1 = createIndexingJob('video_1', 100);
      await new Promise((resolve) => setTimeout(resolve, 1)); // Small delay
      const job2 = createIndexingJob('video_1', 100);

      expect(job1.jobId).not.toBe(job2.jobId);
    });

    it('should update job progress', () => {
      const job = createIndexingJob('video_1', 100);
      const updated = updateIndexingJob(job, 50);

      expect(updated.processedCount).toBe(50);
      expect(updated.status).toBe('processing');
    });

    it('should mark job as completed', () => {
      const job = createIndexingJob('video_1', 100);
      const updated = updateIndexingJob(job, 100);

      expect(updated.status).toBe('completed');
      expect(updated.endTime).toBeDefined();
    });

    it('should track failed chunks', () => {
      const job = createIndexingJob('video_1', 100);
      const updated = updateIndexingJob(job, 90, 10);

      expect(updated.processedCount).toBe(90);
      expect(updated.failedCount).toBe(10);
    });

    it('should preserve original job when updating', () => {
      const job = createIndexingJob('video_1', 100);
      const originalProcessed = job.processedCount;
      const updated = updateIndexingJob(job, 50);

      expect(job.processedCount).toBe(originalProcessed); // Original unchanged
      expect(updated.processedCount).toBe(50);
    });
  });

  describe('Indexing Statistics', () => {
    it('should calculate indexing statistics', () => {
      const job = createIndexingJob('video_1', 100);
      const updated = updateIndexingJob(job, 100, 0);

      const stats = calculateIndexingStats(updated);

      expect(stats.totalChunks).toBe(100);
      expect(stats.processedChunks).toBe(100);
      expect(stats.failedChunks).toBe(0);
      expect(stats.successRate).toBe(100);
    });

    it('should calculate success rate with failures', () => {
      const job = createIndexingJob('video_1', 100);
      const updated = updateIndexingJob(job, 90, 10);

      const stats = calculateIndexingStats(updated);

      expect(stats.successRate).toBeCloseTo(88.89, 1); // 80/90 = 88.89%
    });

    it('should calculate chunks per second', () => {
      const job = createIndexingJob('video_1', 100);
      job.startTime = new Date(Date.now() - 10000); // 10 seconds ago
      const updated = updateIndexingJob(job, 100, 0);
      updated.endTime = new Date();

      const stats = calculateIndexingStats(updated);

      expect(stats.chunksPerSecond).toBeGreaterThan(0);
    });

    it('should handle zero processed chunks', () => {
      const job = createIndexingJob('video_1', 100);

      const stats = calculateIndexingStats(job);

      expect(stats.successRate).toBe(0);
      expect(stats.processedChunks).toBe(0);
    });

    it('should calculate duration correctly', () => {
      const job = createIndexingJob('video_1', 100);
      job.startTime = new Date(Date.now() - 5000); // 5 seconds ago
      const updated = updateIndexingJob(job, 50);
      updated.endTime = new Date();

      const stats = calculateIndexingStats(updated);

      expect(stats.duration).toBeGreaterThan(0);
    });
  });

  describe('Edge Cases', () => {
    it('should handle very large vectors', () => {
      const largeVector = Array(1000).fill(0.5);
      const normalized = normalizeVector(largeVector);

      expect(normalized).toHaveLength(1000);
      const magnitude = Math.sqrt(
        normalized.reduce((sum, val) => sum + val * val, 0)
      );
      expect(magnitude).toBeCloseTo(1, 4);
    });

    it('should handle single element vectors', () => {
      const vec1 = [1];
      const vec2 = [1];
      const similarity = cosineSimilarity(vec1, vec2);

      expect(similarity).toBeCloseTo(1, 5);
    });

    it('should handle negative values in vectors', () => {
      const vector = [-0.5, -0.3, -0.2];
      const normalized = normalizeVector(vector);

      expect(normalized).toHaveLength(3);
      const magnitude = Math.sqrt(
        normalized.reduce((sum, val) => sum + val * val, 0)
      );
      expect(magnitude).toBeCloseTo(1, 5);
    });

    it('should handle job with zero chunks', () => {
      const job = createIndexingJob('video_1', 0);

      expect(job.chunkCount).toBe(0);
      expect(job.status).toBe('pending');
    });

    it('should handle very large job', () => {
      const job = createIndexingJob('video_1', 1000000);
      const updated = updateIndexingJob(job, 500000);

      expect(updated.processedCount).toBe(500000);
      expect(updated.status).toBe('processing');
    });
  });

  describe('Similarity Search Ranking', () => {
    it('should correctly rank multiple similarities', () => {
      const query = [1, 0, 0];
      const candidates = [
        [0.95, 0.05, 0], // Very similar
        [0.5, 0.5, 0], // Moderately similar
        [0, 1, 0], // Orthogonal
        [-1, 0, 0], // Opposite
      ];

      const similarities = candidates.map((c) => cosineSimilarity(query, c));

      // Check ordering
      expect(similarities[0]).toBeGreaterThan(similarities[1]);
      expect(similarities[1]).toBeGreaterThan(similarities[2]);
      expect(similarities[2]).toBeGreaterThan(similarities[3]);
    });
  });
});
