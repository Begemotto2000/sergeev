/**
 * Transcription Processing Module
 * Handles transcription import, parsing, and chunking
 */

export interface TranscriptionSegment {
  id: string;
  startTime: string; // HH:MM:SS
  endTime: string; // HH:MM:SS
  text: string;
  speaker?: string;
}

export interface ChunkedSegment {
  videoId: string;
  chunkId: string;
  startTime: string;
  endTime: string;
  text: string;
  tokenCount: number;
  characterCount: number;
  formatType: 'ОТВЕТ' | 'ТАЙМКОД' | 'DEEP RESEARCH' | 'ИМИГО';
}

/**
 * Parse transcription from JSON format
 */
export function parseTranscriptionJSON(jsonData: string): TranscriptionSegment[] {
  try {
    const data = JSON.parse(jsonData);

    // Handle array of segments
    if (Array.isArray(data)) {
      return data.map((segment, index) => ({
        id: segment.id || `seg_${index}`,
        startTime: segment.startTime || segment.start_time || '00:00:00',
        endTime: segment.endTime || segment.end_time || '00:00:00',
        text: segment.text || segment.content || '',
        speaker: segment.speaker || undefined,
      }));
    }

    // Handle object with segments property
    if (data.segments && Array.isArray(data.segments)) {
      return data.segments.map((segment: any, index: number) => ({
        id: segment.id || `seg_${index}`,
        startTime: segment.startTime || segment.start_time || '00:00:00',
        endTime: segment.endTime || segment.end_time || '00:00:00',
        text: segment.text || segment.content || '',
        speaker: segment.speaker || undefined,
      }));
    }

    return [];
  } catch (error) {
    console.error('JSON parsing error:', error);
    return [];
  }
}

/**
 * Parse transcription from SRT format
 */
export function parseTranscriptionSRT(srtData: string): TranscriptionSegment[] {
  const segments: TranscriptionSegment[] = [];
  const blocks = srtData.split('\n\n').filter((block) => block.trim());

  blocks.forEach((block, index) => {
    const lines = block.trim().split('\n');
    if (lines.length >= 3) {
      const timeLine = lines[1];
      const timeMatch = timeLine.match(/(\d{2}:\d{2}:\d{2}),\d{3}\s*-->\s*(\d{2}:\d{2}:\d{2}),\d{3}/);

      if (timeMatch) {
        const text = lines.slice(2).join('\n');
        segments.push({
          id: `seg_${index}`,
          startTime: timeMatch[1],
          endTime: timeMatch[2],
          text: text.trim(),
        });
      }
    }
  });

  return segments;
}

/**
 * Estimate token count (rough approximation)
 * 1 token ≈ 4 characters on average
 */
export function estimateTokenCount(text: string): number {
  return Math.ceil(text.length / 4);
}

/**
 * Split text into chunks of approximately 512 tokens (~1,536 characters)
 */
export function chunkTranscription(
  segments: TranscriptionSegment[],
  videoId: string,
  targetTokens: number = 512
): ChunkedSegment[] {
  const chunks: ChunkedSegment[] = [];
  let currentChunk: TranscriptionSegment[] = [];
  let currentTokenCount = 0;
  let chunkIndex = 0;

  const targetCharacters = targetTokens * 4; // Approximate conversion

  for (const segment of segments) {
    const segmentTokens = estimateTokenCount(segment.text);

    // If adding this segment would exceed the target, save current chunk
    if (currentTokenCount + segmentTokens > targetTokens && currentChunk.length > 0) {
      chunks.push(createChunk(currentChunk, videoId, chunkIndex++));
      currentChunk = [];
      currentTokenCount = 0;
    }

    currentChunk.push(segment);
    currentTokenCount += segmentTokens;
  }

  // Add remaining chunk
  if (currentChunk.length > 0) {
    chunks.push(createChunk(currentChunk, videoId, chunkIndex));
  }

  return chunks;
}

/**
 * Create a chunk from segments
 */
function createChunk(
  segments: TranscriptionSegment[],
  videoId: string,
  chunkIndex: number
): ChunkedSegment {
  const startTime = segments[0].startTime;
  const endTime = segments[segments.length - 1].endTime;
  const text = segments.map((s) => s.text).join(' ');
  const tokenCount = estimateTokenCount(text);
  const characterCount = text.length;

  return {
    videoId,
    chunkId: `${videoId}_chunk_${chunkIndex}`,
    startTime,
    endTime,
    text,
    tokenCount,
    characterCount,
    formatType: 'ОТВЕТ', // Default format type
  };
}

/**
 * Validate transcription data
 */
export function validateTranscription(segments: TranscriptionSegment[]): {
  valid: boolean;
  errors: string[];
} {
  const errors: string[] = [];

  if (!segments || segments.length === 0) {
    errors.push('No segments found in transcription');
    return { valid: false, errors };
  }

  segments.forEach((segment, index) => {
    if (!segment.text || segment.text.trim().length === 0) {
      errors.push(`Segment ${index} has empty text`);
    }

    if (!isValidTimeFormat(segment.startTime)) {
      errors.push(`Segment ${index} has invalid startTime: ${segment.startTime}`);
    }

    if (!isValidTimeFormat(segment.endTime)) {
      errors.push(`Segment ${index} has invalid endTime: ${segment.endTime}`);
    }

    if (compareTime(segment.startTime, segment.endTime) > 0) {
      errors.push(`Segment ${index} has startTime after endTime`);
    }
  });

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Check if time format is valid (HH:MM:SS)
 */
function isValidTimeFormat(time: string): boolean {
  const timeRegex = /^\d{2}:\d{2}:\d{2}$/;
  return timeRegex.test(time);
}

/**
 * Compare two times (HH:MM:SS format)
 * Returns: -1 if time1 < time2, 0 if equal, 1 if time1 > time2
 */
function compareTime(time1: string, time2: string): number {
  const [h1, m1, s1] = time1.split(':').map(Number);
  const [h2, m2, s2] = time2.split(':').map(Number);

  const seconds1 = h1 * 3600 + m1 * 60 + s1;
  const seconds2 = h2 * 3600 + m2 * 60 + s2;

  if (seconds1 < seconds2) return -1;
  if (seconds1 > seconds2) return 1;
  return 0;
}

/**
 * Convert seconds to HH:MM:SS format
 */
export function secondsToTimeFormat(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);

  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

/**
 * Convert HH:MM:SS to seconds
 */
export function timeFormatToSeconds(time: string): number {
  const [hours, minutes, seconds] = time.split(':').map(Number);
  return hours * 3600 + minutes * 60 + seconds;
}

/**
 * Process complete transcription workflow
 */
export async function processTranscription(
  videoId: string,
  transcriptionData: string,
  format: 'json' | 'srt' = 'json'
): Promise<{
  success: boolean;
  chunks?: ChunkedSegment[];
  errors?: string[];
  stats?: {
    segmentCount: number;
    chunkCount: number;
    totalTokens: number;
    totalCharacters: number;
  };
}> {
  try {
    // Parse transcription
    let segments: TranscriptionSegment[];
    if (format === 'srt') {
      segments = parseTranscriptionSRT(transcriptionData);
    } else {
      segments = parseTranscriptionJSON(transcriptionData);
    }

    // Validate
    const validation = validateTranscription(segments);
    if (!validation.valid) {
      return {
        success: false,
        errors: validation.errors,
      };
    }

    // Chunk
    const chunks = chunkTranscription(segments, videoId);

    // Calculate stats
    const stats = {
      segmentCount: segments.length,
      chunkCount: chunks.length,
      totalTokens: chunks.reduce((sum, chunk) => sum + chunk.tokenCount, 0),
      totalCharacters: chunks.reduce((sum, chunk) => sum + chunk.characterCount, 0),
    };

    return {
      success: true,
      chunks,
      stats,
    };
  } catch (error) {
    console.error('Transcription processing error:', error);
    return {
      success: false,
      errors: [error instanceof Error ? error.message : 'Unknown error'],
    };
  }
}
