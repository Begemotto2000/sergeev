/**
 * Transcription Intake Router Tests
 */

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import * as fs from 'fs';
import * as path from 'path';
import { convertTextToSegments, extractTimecodes, validateFileSize, getFileType } from '../fileParser';
import { chunkTranscription, parseTranscriptionJSON, parseTranscriptionSRT } from '../transcription';

describe('File Parser Module', () => {
  describe('convertTextToSegments', () => {
    it('should convert plain text to segments', () => {
      const text = 'This is the first paragraph.\n\nThis is the second paragraph.';
      const segments = convertTextToSegments(text);

      expect(segments.length).toBeGreaterThan(0);
      expect(segments[0].text).toBeTruthy();
      expect(segments[0].startTime).toBe('00:00:00');
    });

    it('should handle empty text', () => {
      const segments = convertTextToSegments('');
      expect(segments.length).toBe(0);
    });

    it('should split long paragraphs into multiple segments', () => {
      const longText = 'A'.repeat(500) + '\n\n' + 'B'.repeat(500);
      const segments = convertTextToSegments(longText);

      expect(segments.length).toBeGreaterThanOrEqual(2);
    });
  });

  describe('extractTimecodes', () => {
    it('should extract HH:MM:SS timecodes', () => {
      const text = 'At 01:23:45 the speaker said something important.';
      const timecodes = extractTimecodes(text);

      expect(timecodes.length).toBeGreaterThan(0);
      expect(timecodes[0].timecode).toBe('01:23:45');
    });

    it('should extract MM:SS timecodes', () => {
      const text = 'Around 05:30 we discussed the topic.';
      const timecodes = extractTimecodes(text);

      expect(timecodes.length).toBeGreaterThan(0);
      expect(timecodes[0].timecode).toBe('05:30');
    });

    it('should return empty array for text without timecodes', () => {
      const text = 'This text has no timecodes.';
      const timecodes = extractTimecodes(text);

      expect(timecodes.length).toBe(0);
    });
  });

  describe('getFileType', () => {
    it('should extract file type from filename', () => {
      expect(getFileType('document.pdf')).toBe('pdf');
      expect(getFileType('file.docx')).toBe('docx');
      expect(getFileType('transcript.txt')).toBe('txt');
      expect(getFileType('data.json')).toBe('json');
      expect(getFileType('subtitles.srt')).toBe('srt');
    });

    it('should handle uppercase extensions', () => {
      expect(getFileType('DOCUMENT.PDF')).toBe('pdf');
      expect(getFileType('FILE.DOCX')).toBe('docx');
    });
  });
});

describe('Transcription Processing', () => {
  describe('parseTranscriptionJSON', () => {
    it('should parse JSON array format', () => {
      const json = JSON.stringify([
        { id: '1', startTime: '00:00:00', endTime: '00:00:10', text: 'First segment' },
        { id: '2', startTime: '00:00:10', endTime: '00:00:20', text: 'Second segment' },
      ]);

      const segments = parseTranscriptionJSON(json);

      expect(segments.length).toBe(2);
      expect(segments[0].text).toBe('First segment');
      expect(segments[1].text).toBe('Second segment');
    });

    it('should parse JSON object with segments property', () => {
      const json = JSON.stringify({
        segments: [
          { text: 'Content 1', start_time: '00:00:00', end_time: '00:00:05' },
          { text: 'Content 2', start_time: '00:00:05', end_time: '00:00:10' },
        ],
      });

      const segments = parseTranscriptionJSON(json);

      expect(segments.length).toBe(2);
      expect(segments[0].text).toBe('Content 1');
    });

    it('should handle invalid JSON gracefully', () => {
      const segments = parseTranscriptionJSON('invalid json');
      expect(segments.length).toBe(0);
    });
  });

  describe('parseTranscriptionSRT', () => {
    it('should parse SRT format correctly', () => {
      const srt = `1
00:00:00,000 --> 00:00:05,000
First subtitle

2
00:00:05,000 --> 00:00:10,000
Second subtitle`;

      const segments = parseTranscriptionSRT(srt);

      expect(segments.length).toBe(2);
      expect(segments[0].text).toBe('First subtitle');
      expect(segments[0].startTime).toBe('00:00:00');
      expect(segments[0].endTime).toBe('00:00:05');
    });

    it('should handle multiline subtitles', () => {
      const srt = `1
00:00:00,000 --> 00:00:05,000
Line 1
Line 2
Line 3`;

      const segments = parseTranscriptionSRT(srt);

      expect(segments.length).toBe(1);
      expect(segments[0].text).toContain('Line 1');
      expect(segments[0].text).toContain('Line 3');
    });
  });

  describe('chunkTranscription', () => {
    it('should chunk transcription into segments', () => {
      const segments = [
        { id: '1', startTime: '00:00:00', endTime: '00:00:10', text: 'A'.repeat(100) },
        { id: '2', startTime: '00:00:10', endTime: '00:00:20', text: 'B'.repeat(100) },
        { id: '3', startTime: '00:00:20', endTime: '00:00:30', text: 'C'.repeat(100) },
      ];

      const chunks = chunkTranscription(segments, 'video_1', 512);

      expect(chunks.length).toBeGreaterThan(0);
      expect(chunks[0].videoId).toBe('video_1');
      expect(chunks[0].tokenCount).toBeGreaterThan(0);
    });

    it('should respect target token count', () => {
      const segments = Array.from({ length: 10 }, (_, i) => ({
        id: `seg_${i}`,
        startTime: '00:00:00',
        endTime: '00:00:10',
        text: 'A'.repeat(200),
      }));

      const chunks = chunkTranscription(segments, 'video_1', 256);

      // Each chunk should be roughly 256 tokens
      for (const chunk of chunks) {
        expect(chunk.tokenCount).toBeLessThanOrEqual(300); // Allow some margin
      }
    });
  });
});

describe('File Size Validation', () => {
  let tempFile: string;

  beforeEach(() => {
    tempFile = path.join('/tmp', `test_${Date.now()}.txt`);
  });

  afterEach(() => {
    if (fs.existsSync(tempFile)) {
      fs.unlinkSync(tempFile);
    }
  });

  it('should validate file size for TXT files', () => {
    // Create a 5MB file
    const buffer = Buffer.alloc(5 * 1024 * 1024);
    fs.writeFileSync(tempFile, buffer);

    expect(validateFileSize(tempFile, 'txt')).toBe(true);
  });

  it('should reject oversized TXT files', () => {
    // Create an 11MB file
    const buffer = Buffer.alloc(11 * 1024 * 1024);
    fs.writeFileSync(tempFile, buffer);

    expect(validateFileSize(tempFile, 'txt')).toBe(false);
  });

  it('should validate file size for PDF files', () => {
    // Create a 30MB file
    const buffer = Buffer.alloc(30 * 1024 * 1024);
    fs.writeFileSync(tempFile, buffer);

    expect(validateFileSize(tempFile, 'pdf')).toBe(true);
  });

  it('should reject oversized PDF files', () => {
    // Create a 51MB file
    const buffer = Buffer.alloc(51 * 1024 * 1024);
    fs.writeFileSync(tempFile, buffer);

    expect(validateFileSize(tempFile, 'pdf')).toBe(false);
  });
});
