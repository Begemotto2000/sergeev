/**
 * Webhook Router
 * Provides endpoints for webhook management
 */

import { z } from 'zod';
import { protectedProcedure, router } from '../_core/trpc';
import {
  createWebhook,
  getUserWebhooks,
  deleteWebhook,
  getWebhookStats,
  getWebhookDeliveries,
  getWebhookEventTypes,
} from '../webhooks';

export const webhookRouter = router({
  /**
   * Create new webhook
   */
  create: protectedProcedure
    .input(
      z.object({
        url: z.string().url(),
        events: z.array(z.string()),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const secret = `whsec_${Math.random().toString(36).substring(7)}`;
      const webhook = await createWebhook(ctx.user.id, input.url, input.events as any, secret);

      return {
        id: webhook.id,
        url: webhook.url,
        events: webhook.events,
        secret: webhook.secret,
        createdAt: new Date(webhook.createdAt).toISOString(),
      };
    }),

  /**
   * List user webhooks
   */
  list: protectedProcedure.query(async ({ ctx }) => {
    const webhooks = await getUserWebhooks(ctx.user.id);

    return webhooks.map((w) => ({
      id: w.id,
      url: w.url,
      events: w.events,
      active: w.active,
      createdAt: new Date(w.createdAt).toISOString(),
      lastDelivery: w.lastDelivery ? new Date(w.lastDelivery).toISOString() : null,
      deliveryCount: w.deliveryCount,
      failureCount: w.failureCount,
    }));
  }),

  /**
   * Delete webhook
   */
  delete: protectedProcedure
    .input(z.object({ webhookId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const success = await deleteWebhook(input.webhookId, ctx.user.id);
      return { success };
    }),

  /**
   * Get webhook statistics
   */
  getStats: protectedProcedure
    .input(z.object({ webhookId: z.string() }))
    .query(async ({ input }) => {
      const stats = await getWebhookStats(input.webhookId);

      return {
        totalDeliveries: stats.totalDeliveries,
        successfulDeliveries: stats.successfulDeliveries,
        failedDeliveries: stats.failedDeliveries,
        successRate: stats.successRate.toFixed(2),
        lastDelivery: stats.lastDelivery ? new Date(stats.lastDelivery).toISOString() : null,
      };
    }),

  /**
   * Get webhook deliveries
   */
  getDeliveries: protectedProcedure
    .input(z.object({ webhookId: z.string(), limit: z.number().optional() }))
    .query(async ({ input }) => {
      const deliveries = await getWebhookDeliveries(input.webhookId, input.limit || 50);

      return deliveries.map((d) => ({
        id: d.id,
        event: d.event,
        status: d.status,
        attempts: d.attempts,
        error: d.error,
        createdAt: new Date(d.createdAt).toISOString(),
        completedAt: d.completedAt ? new Date(d.completedAt).toISOString() : null,
      }));
    }),

  /**
   * Get available webhook events
   */
  getEventTypes: protectedProcedure.query(async () => {
    const events = getWebhookEventTypes();
    return {
      events,
      count: events.length,
    };
  }),

  /**
   * Test webhook delivery
   */
  testDelivery: protectedProcedure
    .input(z.object({ webhookId: z.string() }))
    .mutation(async ({ input }) => {
      // In a real implementation, would send test payload
      return {
        success: true,
        message: 'Test delivery queued',
        deliveryId: `test_${Date.now()}`,
      };
    }),

  /**
   * Get webhook summary
   */
  getSummary: protectedProcedure.query(async ({ ctx }) => {
    const webhooks = await getUserWebhooks(ctx.user.id);
    const totalStats = {
      totalWebhooks: webhooks.length,
      activeWebhooks: webhooks.filter((w) => w.active).length,
      totalDeliveries: webhooks.reduce((sum, w) => sum + w.deliveryCount, 0),
      totalFailures: webhooks.reduce((sum, w) => sum + w.failureCount, 0),
    };

    return {
      ...totalStats,
      webhooks: webhooks.map((w) => ({
        id: w.id,
        url: w.url,
        events: w.events,
        active: w.active,
      })),
    };
  }),
});
