/**
 * Transcription Intake Router
 * Handles file uploads and automatic processing pipeline
 */

import { z } from 'zod';
import { protectedProcedure, router } from '../_core/trpc';
import { TRPCError } from '@trpc/server';
import * as fs from 'fs';
import * as path from 'path';
import { storagePut } from '../storage';
import { parseFile, convertTextToSegments, validateFileSize, getFileType } from '../fileParser';
import { chunkTranscription, parseTranscriptionJSON, parseTranscriptionSRT } from '../transcription';
import { getDb } from '../db';
import { eq } from 'drizzle-orm';
import { transcriptionUploads } from '../../drizzle/schema';

/**
 * Process transcription file: parse -> validate -> chunk -> embed -> index
 */
async function processTranscriptionFile(
  filePath: string,
  fileType: string,
  uploadId: number,
  userId: number
): Promise<{ segmentCount: number; chunkCount: number; totalTokens: number }> {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  try {
    let text = '';
    let segments = [];

    // Parse file based on type
    if (fileType === 'json') {
      text = fs.readFileSync(filePath, 'utf-8');
      segments = parseTranscriptionJSON(text);
    } else if (fileType === 'srt') {
      text = fs.readFileSync(filePath, 'utf-8');
      segments = parseTranscriptionSRT(text);
    } else {
      // Parse PDF/DOCX/TXT
      text = await parseFile(filePath);
      segments = convertTextToSegments(text);
    }

    if (segments.length === 0) {
      throw new Error('No valid segments found in transcription');
    }

    // Chunk transcription
    const videoId = `upload_${uploadId}`;
    const chunks = chunkTranscription(segments, videoId, 512);

    if (chunks.length === 0) {
      throw new Error('Failed to create chunks from transcription');
    }

    // Index chunks in database
    let totalTokens = 0;
    for (const chunk of chunks) {
      totalTokens += chunk.tokenCount;
      // TODO: Insert chunks into indexed_transcriptions table
    }

    // Update upload status
    await db
      .update(transcriptionUploads)
      .set({
        status: 'indexed',
        segmentCount: segments.length,
        chunkCount: chunks.length,
        totalTokens,
      })
      .where(eq(transcriptionUploads.id, uploadId));

    return {
      segmentCount: segments.length,
      chunkCount: chunks.length,
      totalTokens,
    };
  } catch (error) {
    // Update upload status to failed
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    await db
      .update(transcriptionUploads)
      .set({
        status: 'failed',
        errorMessage,
      })
      .where(eq(transcriptionUploads.id, uploadId));

    throw error;
  }
}

export const transcriptionIntakeRouter = router({
  /**
   * Upload and process transcription file
   */
  uploadTranscription: protectedProcedure
    .input(
      z.object({
        filename: z.string().min(1),
        fileBuffer: z.instanceof(Buffer),
        fileType: z.enum(['pdf', 'docx', 'txt', 'json', 'srt']),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database not available',
        });
      }

      try {
        // Validate file size
        const tempPath = path.join('/tmp', `upload_${Date.now()}_${input.filename}`);
        fs.writeFileSync(tempPath, input.fileBuffer);

        if (!validateFileSize(tempPath, input.fileType)) {
          fs.unlinkSync(tempPath);
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message: `File size exceeds limit for ${input.fileType} files`,
          });
        }

        // Upload to S3
        const fileKey = `transcriptions/${ctx.user.id}/${Date.now()}_${input.filename}`;
        const { url: fileUrl } = await storagePut(fileKey, input.fileBuffer, 'application/octet-stream');

        // Create upload record
        const uploadResult = await db.insert(transcriptionUploads).values({
          userId: ctx.user.id,
          filename: input.filename,
          fileType: input.fileType,
          fileUrl,
          fileKey,
          status: 'processing',
        });

        const uploadId = (uploadResult as any)[0];

        // Process transcription asynchronously
        processTranscriptionFile(tempPath, input.fileType, uploadId, ctx.user.id)
          .then(() => {
            // Clean up temp file
            try {
              fs.unlinkSync(tempPath);
            } catch (e) {
              console.error('Failed to clean up temp file:', e);
            }
          })
          .catch((error) => {
            console.error('Transcription processing error:', error);
            // Temp file cleanup happens in processTranscriptionFile error handler
            try {
              fs.unlinkSync(tempPath);
            } catch (e) {
              console.error('Failed to clean up temp file:', e);
            }
          });

        return {
          uploadId,
          status: 'processing',
          message: 'File uploaded successfully. Processing in background...',
        };
      } catch (error) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: error instanceof Error ? error.message : 'Failed to upload transcription',
        });
      }
    }),

  /**
   * Get upload status
   */
  getUploadStatus: protectedProcedure
    .input(z.object({ uploadId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database not available',
        });
      }

      const uploads = await db
        .select()
        .from(transcriptionUploads)
        .where(eq(transcriptionUploads.id, input.uploadId))
        .limit(1);

      if (uploads.length === 0 || uploads[0].userId !== ctx.user.id) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Upload not found',
        });
      }

      return uploads[0];
    }),

  /**
   * List user's transcription uploads
   */
  listUploads: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) {
      throw new TRPCError({
        code: 'INTERNAL_SERVER_ERROR',
        message: 'Database not available',
      });
    }

    const uploads = await db
      .select()
      .from(transcriptionUploads)
      .where(eq(transcriptionUploads.userId, ctx.user.id))
      .orderBy((t) => t.createdAt);

    return uploads;
  }),

  /**
   * Get indexed chunks for an upload
   */
  getIndexedChunks: protectedProcedure
    .input(z.object({ uploadId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database not available',
        });
      }

      // Verify upload belongs to user
      const uploads = await db
        .select()
        .from(transcriptionUploads)
        .where(eq(transcriptionUploads.id, input.uploadId))
        .limit(1);

      if (uploads.length === 0 || uploads[0].userId !== ctx.user.id) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Upload not found',
        });
      }

      // TODO: Return indexed chunks
      return [];
    }),

  /**
   * Delete transcription upload
   */
  deleteUpload: protectedProcedure
    .input(z.object({ uploadId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Database not available',
        });
      }

      // Verify upload belongs to user
      const uploads = await db
        .select()
        .from(transcriptionUploads)
        .where(eq(transcriptionUploads.id, input.uploadId))
        .limit(1);

      if (uploads.length === 0 || uploads[0].userId !== ctx.user.id) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'Upload not found',
        });
      }

      // Delete indexed chunks
      // TODO: Delete chunks from indexed_transcriptions table

      // Delete upload record
      await db.delete(transcriptionUploads).where(eq(transcriptionUploads.id, input.uploadId));

      return { success: true };
    }),
});
