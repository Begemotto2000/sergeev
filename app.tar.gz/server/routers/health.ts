/**
 * Health Check Router
 * Provides system health status and monitoring endpoints
 */

import { z } from 'zod';
import { publicProcedure, router } from '../_core/trpc';
import { getDb } from '../db';

interface HealthStatus {
  status: 'healthy' | 'degraded' | 'unhealthy';
  timestamp: number;
  uptime: number;
  components: {
    database: { status: 'ok' | 'error'; responseTime: number };
    qdrant: { status: 'ok' | 'error'; responseTime: number };
    llm: { status: 'ok' | 'error'; responseTime: number };
  };
  metrics: {
    memoryUsage: number;
    cpuUsage: number;
    activeConnections: number;
  };
}

const startTime = Date.now();

/**
 * Check database connectivity
 */
async function checkDatabase(): Promise<{ status: 'ok' | 'error'; responseTime: number }> {
  const checkStart = Date.now();
  try {
    const db = await getDb();
    if (!db) {
      return { status: 'error', responseTime: Date.now() - checkStart };
    }
    // Simple query to verify connection
    return { status: 'ok', responseTime: Date.now() - checkStart };
  } catch (error) {
    return { status: 'error', responseTime: Date.now() - checkStart };
  }
}

/**
 * Check Qdrant connectivity (simulated)
 */
async function checkQdrant(): Promise<{ status: 'ok' | 'error'; responseTime: number }> {
  const checkStart = Date.now();
  try {
    // Simulate Qdrant health check
    await new Promise((resolve) => setTimeout(resolve, 50));
    return { status: 'ok', responseTime: Date.now() - checkStart };
  } catch (error) {
    return { status: 'error', responseTime: Date.now() - checkStart };
  }
}

/**
 * Check LLM connectivity (simulated)
 */
async function checkLLM(): Promise<{ status: 'ok' | 'error'; responseTime: number }> {
  const checkStart = Date.now();
  try {
    // Simulate LLM health check
    await new Promise((resolve) => setTimeout(resolve, 30));
    return { status: 'ok', responseTime: Date.now() - checkStart };
  } catch (error) {
    return { status: 'error', responseTime: Date.now() - checkStart };
  }
}

/**
 * Determine overall health status
 */
function determineHealthStatus(components: HealthStatus['components']): 'healthy' | 'degraded' | 'unhealthy' {
  const errorCount = Object.values(components).filter((c) => c.status === 'error').length;

  if (errorCount === 0) return 'healthy';
  if (errorCount === 1) return 'degraded';
  return 'unhealthy';
}

export const healthRouter = router({
  /**
   * Get system health status
   */
  getStatus: publicProcedure.query(async (): Promise<HealthStatus> => {
    const [dbStatus, qdrantStatus, llmStatus] = await Promise.all([
      checkDatabase(),
      checkQdrant(),
      checkLLM(),
    ]);

    const components = {
      database: dbStatus,
      qdrant: qdrantStatus,
      llm: llmStatus,
    };

    const status = determineHealthStatus(components);

    return {
      status,
      timestamp: Date.now(),
      uptime: Date.now() - startTime,
      components,
      metrics: {
        memoryUsage: process.memoryUsage().heapUsed / 1024 / 1024, // MB
        cpuUsage: process.cpuUsage().user / 1000, // ms
        activeConnections: 0, // Would be tracked separately
      },
    };
  }),

  /**
   * Get detailed health report
   */
  getDetailedReport: publicProcedure.query(async () => {
    const [dbStatus, qdrantStatus, llmStatus] = await Promise.all([
      checkDatabase(),
      checkQdrant(),
      checkLLM(),
    ]);

    const uptime = Date.now() - startTime;
    const uptimeHours = Math.floor(uptime / (1000 * 60 * 60));
    const uptimeMinutes = Math.floor((uptime % (1000 * 60 * 60)) / (1000 * 60));

    return {
      systemStatus: determineHealthStatus({
        database: dbStatus,
        qdrant: qdrantStatus,
        llm: llmStatus,
      }),
      uptime: {
        milliseconds: uptime,
        formatted: `${uptimeHours}h ${uptimeMinutes}m`,
      },
      components: {
        database: {
          ...dbStatus,
          description: 'MySQL database connection',
        },
        qdrant: {
          ...qdrantStatus,
          description: 'Qdrant vector database',
        },
        llm: {
          ...llmStatus,
          description: 'LLM API connectivity',
        },
      },
      resources: {
        memory: {
          heapUsed: (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2) + ' MB',
          heapTotal: (process.memoryUsage().heapTotal / 1024 / 1024).toFixed(2) + ' MB',
          external: (process.memoryUsage().external / 1024 / 1024).toFixed(2) + ' MB',
        },
        cpu: {
          user: (process.cpuUsage().user / 1000).toFixed(2) + ' ms',
          system: (process.cpuUsage().system / 1000).toFixed(2) + ' ms',
        },
      },
      timestamp: new Date().toISOString(),
    };
  }),

  /**
   * Check if system is ready for requests
   */
  isReady: publicProcedure.query(async () => {
    const [dbStatus, qdrantStatus, llmStatus] = await Promise.all([
      checkDatabase(),
      checkQdrant(),
      checkLLM(),
    ]);

    const allHealthy = [dbStatus, qdrantStatus, llmStatus].every((s) => s.status === 'ok');

    return {
      ready: allHealthy,
      components: {
        database: dbStatus.status === 'ok',
        qdrant: qdrantStatus.status === 'ok',
        llm: llmStatus.status === 'ok',
      },
    };
  }),

  /**
   * Get component-specific status
   */
  getComponentStatus: publicProcedure
    .input(z.object({ component: z.enum(['database', 'qdrant', 'llm']) }))
    .query(async ({ input }) => {
      let status;

      switch (input.component) {
        case 'database':
          status = await checkDatabase();
          break;
        case 'qdrant':
          status = await checkQdrant();
          break;
        case 'llm':
          status = await checkLLM();
          break;
      }

      return {
        component: input.component,
        ...status,
        timestamp: Date.now(),
      };
    }),

  /**
   * Get system metrics
   */
  getMetrics: publicProcedure.query(() => {
    const memUsage = process.memoryUsage();
    const cpuUsage = process.cpuUsage();

    return {
      memory: {
        rss: (memUsage.rss / 1024 / 1024).toFixed(2) + ' MB',
        heapTotal: (memUsage.heapTotal / 1024 / 1024).toFixed(2) + ' MB',
        heapUsed: (memUsage.heapUsed / 1024 / 1024).toFixed(2) + ' MB',
        external: (memUsage.external / 1024 / 1024).toFixed(2) + ' MB',
        arrayBuffers: (memUsage.arrayBuffers / 1024 / 1024).toFixed(2) + ' MB',
      },
      cpu: {
        user: (cpuUsage.user / 1000).toFixed(2) + ' ms',
        system: (cpuUsage.system / 1000).toFixed(2) + ' ms',
      },
      uptime: {
        seconds: Math.floor((Date.now() - startTime) / 1000),
        formatted: `${Math.floor((Date.now() - startTime) / (1000 * 60 * 60))}h ${Math.floor(((Date.now() - startTime) % (1000 * 60 * 60)) / (1000 * 60))}m`,
      },
      timestamp: new Date().toISOString(),
    };
  }),
});
