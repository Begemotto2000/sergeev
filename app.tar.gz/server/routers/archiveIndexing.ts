/**
 * Роутер для индексирования архивов в Qdrant
 * ЧЕСТНО: Все embeddings генерируются через реальный OpenAI API
 */

import { protectedProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { ArchiveIndexingService } from "../services/archiveIndexingService";

const indexingService = new ArchiveIndexingService();

export const archiveIndexingRouter = router({
  /**
   * Индексировать архив из JSON файла
   * ЧЕСТНО: Требуется реальный userId от пользователя
   */
  indexFromJson: protectedProcedure
    .input(
      z.object({
        archiveId: z.string().min(1, "Archive ID required"),
        jsonData: z.string().min(1, "JSON data required"),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        console.log(`📦 Начало индексирования архива: ${input.archiveId} для пользователя: ${ctx.user.id}`);

        // Парсить JSON
        const data = JSON.parse(input.jsonData);

        if (!data.chunks || !Array.isArray(data.chunks)) {
          throw new Error("Invalid JSON format: chunks array not found");
        }

        // ЧЕСТНО: Использовать реальный ID пользователя из контекста
        const result = await indexingService.indexArchive({
          archiveId: input.archiveId,
          chunks: data.chunks,
          userId: ctx.user.id, // ЧЕСТНО: Реальный ID пользователя
          batchSize: 50,
        });

        console.log(`✓ Индексирование завершено: ${result.message}`);

        return {
          success: result.success,
          chunksIndexed: result.chunksIndexed,
          executionTime: result.executionTime,
          message: result.message,
        };
      } catch (error) {
        console.error("❌ Ошибка при индексировании архива:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
        };
      }
    }),

  /**
   * Очистить кэш эмбеддингов
   */
  clearCache: protectedProcedure.mutation(async ({ ctx }) => {
    try {
      console.log(`🧹 Очистка кэша для пользователя: ${ctx.user.id}`);
      indexingService.clearCache();
      return {
        success: true,
        message: "Кэш очищен",
      };
    } catch (error) {
      console.error("❌ Ошибка при очистке кэша:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  }),
});
