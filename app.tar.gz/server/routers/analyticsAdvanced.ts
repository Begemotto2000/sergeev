/**
 * Advanced Analytics Router
 * Provides endpoints for dashboard visualization and analytics
 */

import { z } from 'zod';
import { protectedProcedure, router } from '../_core/trpc';
import {
  getPerformanceMetrics,
  getQueryTimeDistribution,
  calculatePercentile,
  getHourlyQueryStats,
  getQueryModeDistribution,
  getTopSlowQueries,
  getUserActivityStats,
  getSystemMetricsHistory,
} from '../analyticsCollector';

export const analyticsAdvancedRouter = router({
  /**
   * Get performance metrics for dashboard
   */
  getPerformanceMetrics: protectedProcedure
    .input(z.object({ hoursBack: z.number().min(1).max(168).default(24) }))
    .query(async ({ input }) => {
      const metrics = await getPerformanceMetrics(input.hoursBack);
      const distribution = await getQueryTimeDistribution(input.hoursBack);

      return {
        ...metrics,
        p95QueryTime: calculatePercentile(distribution, 95),
        p99QueryTime: calculatePercentile(distribution, 99),
      };
    }),

  /**
   * Get hourly query statistics
   */
  getHourlyStats: protectedProcedure
    .input(z.object({ hoursBack: z.number().min(1).max(168).default(24) }))
    .query(async ({ input }) => {
      return await getHourlyQueryStats(input.hoursBack);
    }),

  /**
   * Get query mode distribution
   */
  getQueryModeDistribution: protectedProcedure.query(async () => {
    const distribution = await getQueryModeDistribution();
    return Object.entries(distribution).map(([mode, count]) => ({
      mode,
      count,
      percentage: 0, // Will be calculated on frontend
    }));
  }),

  /**
   * Get top slow queries
   */
  getTopSlowQueries: protectedProcedure
    .input(z.object({ limit: z.number().min(1).max(50).default(10) }))
    .query(async ({ input }) => {
      const queries = await getTopSlowQueries(input.limit);
      return queries.map((q) => ({
        timestamp: new Date(q.timestamp).toISOString(),
        queryTime: q.queryTime,
        mode: q.queryMode,
        cached: q.cacheHit,
        resultCount: q.resultCount,
      }));
    }),

  /**
   * Get user activity statistics
   */
  getUserActivityStats: protectedProcedure.query(async () => {
    return await getUserActivityStats();
  }),

  /**
   * Get system metrics history
   */
  getSystemMetricsHistory: protectedProcedure
    .input(z.object({ hoursBack: z.number().min(1).max(168).default(24) }))
    .query(async ({ input }) => {
      const metrics = await getSystemMetricsHistory(input.hoursBack);
      return metrics.map((m) => ({
        timestamp: new Date(Date.now()).toISOString(),
        memoryUsage: m.memoryUsage,
        cpuUsage: m.cpuUsage,
        activeConnections: m.activeConnections,
        uptime: m.uptime,
      }));
    }),

  /**
   * Get dashboard summary
   */
  getDashboardSummary: protectedProcedure.query(async () => {
    const [metrics, hourlyStats, modeDistribution, slowQueries, userActivity, systemMetrics] = await Promise.all([
      getPerformanceMetrics(24),
      getHourlyQueryStats(24),
      getQueryModeDistribution(),
      getTopSlowQueries(5),
      getUserActivityStats(),
      getSystemMetricsHistory(24),
    ]);

    const distribution = await getQueryTimeDistribution(24);

    return {
      performance: {
        avgQueryTime: metrics.avgQueryTime,
        p95QueryTime: calculatePercentile(distribution, 95),
        p99QueryTime: calculatePercentile(distribution, 99),
        cacheHitRate: metrics.cacheHitRate,
        totalQueries: metrics.totalQueries,
      },
      queryModes: Object.entries(modeDistribution).map(([mode, count]) => ({
        mode,
        count,
      })),
      topSlowQueries: slowQueries.slice(0, 5).map((q) => ({
        time: q.queryTime,
        mode: q.queryMode,
      })),
      userActivity,
      systemHealth: {
        avgMemory: systemMetrics.length > 0 
          ? systemMetrics.reduce((sum, m) => sum + m.memoryUsage, 0) / systemMetrics.length 
          : 0,
        avgCpu: systemMetrics.length > 0 
          ? systemMetrics.reduce((sum, m) => sum + m.cpuUsage, 0) / systemMetrics.length 
          : 0,
        peakConnections: systemMetrics.length > 0 ? Math.max(...systemMetrics.map((m) => m.activeConnections)) : 0,
      },
    };
  }),

  /**
   * Get cache performance trends
   */
  getCacheTrends: protectedProcedure
    .input(z.object({ hoursBack: z.number().min(1).max(168).default(24) }))
    .query(async ({ input }) => {
      const hourlyStats = await getHourlyQueryStats(input.hoursBack);
      return hourlyStats.map((stat) => ({
        hour: stat.hour,
        cacheHitRate: stat.cacheHitRate,
        queryCount: stat.queryCount,
        avgTime: stat.avgTime,
      }));
    }),

  /**
   * Get query latency distribution
   */
  getLatencyDistribution: protectedProcedure
    .input(z.object({ hoursBack: z.number().min(1).max(168).default(24) }))
    .query(async ({ input }) => {
      const distribution = await getQueryTimeDistribution(input.hoursBack);

      // Create buckets for histogram
      const buckets = [50, 100, 200, 500, 1000, 2000, 5000];
      const histogram: Record<string, number> = {};

      buckets.forEach((bucket) => {
        histogram[`${bucket}ms`] = distribution.filter((t) => t <= bucket).length;
      });

      return {
        total: distribution.length,
        min: distribution.length > 0 ? distribution[0] : 0,
        max: distribution.length > 0 ? distribution[distribution.length - 1] : 0,
        median: calculatePercentile(distribution, 50),
        p95: calculatePercentile(distribution, 95),
        p99: calculatePercentile(distribution, 99),
        histogram,
      };
    }),
});
