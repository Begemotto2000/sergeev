import { router, publicProcedure } from '../_core/trpc';
import { z } from 'zod';
import { TelegramBotManager } from '../telegramBot';

// Initialize bot manager (in production, would use environment variable)
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZA';
let botManager: TelegramBotManager;

try {
  botManager = new TelegramBotManager(BOT_TOKEN);
} catch (error) {
  console.error('Failed to initialize Telegram bot:', error);
}

export const telegramRouter = router({
  /**
   * Handle webhook updates from Telegram
   */
  webhook: publicProcedure
    .input(
      z.object({
        update_id: z.number(),
        message: z
          .object({
            message_id: z.number(),
            date: z.number(),
            chat: z.object({
              id: z.number(),
              type: z.string(),
            }),
            from: z.object({
              id: z.number(),
              is_bot: z.boolean(),
              first_name: z.string(),
              last_name: z.string().optional(),
              username: z.string().optional(),
            }),
            text: z.string().optional(),
          })
          .optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        if (!input.message) {
          return { ok: true, result: null };
        }

        // Process the message through bot manager
        await botManager.handleWebhookUpdate(input);

        return { ok: true, result: 'Message processed' };
      } catch (error) {
        console.error('Error processing webhook:', error);
        return { ok: false, error: 'Failed to process webhook' };
      }
    }),

  /**
   * Get bot commands
   */
  getCommands: publicProcedure.query(async () => {
    try {
      const commands = botManager.getCommands();
      return {
        ok: true,
        commands: commands.map((cmd) => ({
          command: cmd.command,
          description: cmd.description,
        })),
      };
    } catch (error) {
      console.error('Error getting commands:', error);
      return { ok: false, error: 'Failed to get commands' };
    }
  }),

  /**
   * Get bot info
   */
  getInfo: publicProcedure.query(async () => {
    try {
      const info = await botManager.getBotInfo();
      return { ok: true, info };
    } catch (error) {
      console.error('Error getting bot info:', error);
      return { ok: false, error: 'Failed to get bot info' };
    }
  }),

  /**
   * Send test message
   */
  sendTestMessage: publicProcedure
    .input(
      z.object({
        chatId: z.number(),
        text: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const result = await botManager.sendMessage({
          chatId: input.chatId,
          text: input.text,
        });

        return { ok: result, message: 'Test message sent' };
      } catch (error) {
        console.error('Error sending test message:', error);
        return { ok: false, error: 'Failed to send test message' };
      }
    }),

  /**
   * Get user session
   */
  getUserSession: publicProcedure
    .input(z.object({ userId: z.number() }))
    .query(({ input }) => {
      try {
        const session = botManager.getUserSession(input.userId);
        return { ok: true, session };
      } catch (error) {
        console.error('Error getting user session:', error);
        return { ok: false, error: 'Failed to get user session' };
      }
    }),

  /**
   * Clear user session
   */
  clearUserSession: publicProcedure
    .input(z.object({ userId: z.number() }))
    .mutation(({ input }) => {
      try {
        botManager.clearUserSession(input.userId);
        return { ok: true, message: 'Session cleared' };
      } catch (error) {
        console.error('Error clearing user session:', error);
        return { ok: false, error: 'Failed to clear user session' };
      }
    }),

  /**
   * Health check
   */
  health: publicProcedure.query(async () => {
    try {
      const info = await botManager.getBotInfo();
      return {
        ok: true,
        status: 'healthy',
        bot: info?.result?.username || 'unknown',
      };
    } catch (error) {
      return {
        ok: false,
        status: 'unhealthy',
        error: 'Bot not responding',
      };
    }
  }),
});
