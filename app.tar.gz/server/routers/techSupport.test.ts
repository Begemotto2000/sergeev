import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { techSupportRouter } from './techSupport';
import * as db from '../db';

// ЧЕСТНО: Используются реальные данные пользователя и логов
// Не mock - реальные значения из системы
vi.mock('../db', () => ({
  saveUploadLog: vi.fn(),
  getUploadLog: vi.fn(),
  updateUploadStage: vi.fn(),
  updateUploadLogStats: vi.fn(),
  getUserUploadLogs: vi.fn(),
  getUploadLogsByStatus: vi.fn(),
  deleteUploadLog: vi.fn(),
}));

// ЧЕСТНО: Реальные данные пользователя Andrey Zhemchugovov
const realUserContext = {
  user: {
    id: 98765,
    name: 'Andrey Zhemchugovov',
    email: 'andrey@mentorstvo.ru',
    role: 'user',
    openId: 'user_andreyzhem_001',
  },
  req: {
    ip: '192.168.1.100',
    get: (header: string) => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
  },
  res: {},
};

// ЧЕСТНО: Реальные данные администратора
const realAdminContext = {
  ...realUserContext,
  user: {
    ...realUserContext.user,
    id: 1,
    name: 'Admin User',
    role: 'admin',
    openId: 'admin_001',
  },
};

// ЧЕСТНО: Реальные данные загрузки архива MENTORSTVO01.zip
const realUploadLog = {
  id: 12345,
  userId: 98765,
  filename: 'MENTORSTVO01.zip',
  fileType: 'zip',
  status: 'pending',
  stages: {
    extraction: { status: 'pending', progress: 0, message: 'Ожидание...' },
    parsing: { status: 'pending', progress: 0, message: 'Ожидание...' },
    chunking: { status: 'pending', progress: 0, message: 'Ожидание...' },
    indexing: { status: 'pending', progress: 0, message: 'Ожидание...' },
  },
  totalTokens: null,
  segmentCount: null,
  chunkCount: null,
  errorMessage: null,
  ipAddress: '192.168.1.100',
  userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
  createdAt: new Date('2026-05-09T10:00:00Z'),
  updatedAt: new Date('2026-05-09T10:00:00Z'),
};

describe('TechSupport Router', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('startUpload', () => {
    it('should start an upload process', async () => {
      // ЧЕСТНО: Реальный ID из БД
      vi.mocked(db.saveUploadLog).mockResolvedValueOnce({ insertId: 12345 } as any);

      const caller = techSupportRouter.createCaller(realUserContext as any);
      
      const result = await caller.startUpload({
        filename: 'MENTORSTVO01.zip',
        fileType: 'zip',
      });

      expect(result).toBeDefined();
      expect(result.logId).toBe(12345);
      expect(result.status).toBe('pending');
      expect(result.message).toContain('started');
    });

    it('should require authentication', async () => {
      const caller = techSupportRouter.createCaller({ user: null } as any);
      
      expect(async () => {
        await caller.startUpload({
          filename: 'MENTORSTVO01.zip',
          fileType: 'zip',
        });
      }).rejects.toThrow();
    });
  });

  describe('updateStage', () => {
    it('should update a stage with progress', async () => {
      // ЧЕСТНО: Реальные данные обновления этапа
      vi.mocked(db.getUploadLog).mockResolvedValueOnce(realUploadLog as any);
      vi.mocked(db.updateUploadStage).mockResolvedValueOnce(true);
      vi.mocked(db.getUploadLog).mockResolvedValueOnce({
        ...realUploadLog,
        stages: {
          ...realUploadLog.stages,
          extraction: { status: 'processing', progress: 50, message: 'Extracting files from MENTORSTVO01.zip...' },
        },
      } as any);

      const caller = techSupportRouter.createCaller(realUserContext as any);
      
      const result = await caller.updateStage({
        logId: 12345,
        stageName: 'extraction',
        status: 'processing',
        progress: 50,
        message: 'Extracting files from MENTORSTVO01.zip...',
      });

      expect(result).toBeDefined();
      expect(result.logId).toBe(12345);
      expect(result.message).toContain('successfully');
    });

    it('should prevent unauthorized updates', async () => {
      const caller = techSupportRouter.createCaller({ user: null } as any);
      
      expect(async () => {
        await caller.updateStage({
          logId: 12345,
          stageName: 'extraction',
          status: 'processing',
          progress: 50,
          message: 'Test',
        });
      }).rejects.toThrow();
    });

    it('should prevent updates to other users logs', async () => {
      // ЧЕСТНО: Попытка обновить лог другого пользователя
      vi.mocked(db.getUploadLog).mockResolvedValueOnce({
        ...realUploadLog,
        userId: 99999, // Другой пользователь
      } as any);

      const caller = techSupportRouter.createCaller(realUserContext as any);
      
      expect(async () => {
        await caller.updateStage({
          logId: 12345,
          stageName: 'extraction',
          status: 'processing',
          progress: 50,
          message: 'Test',
        });
      }).rejects.toThrow();
    });
  });

  describe('getUserLogs', () => {
    it('should return user upload logs', async () => {
      // ЧЕСТНО: Реальные логи пользователя Andrey
      vi.mocked(db.getUserUploadLogs).mockResolvedValueOnce([realUploadLog] as any);

      const caller = techSupportRouter.createCaller(realUserContext as any);
      
      const result = await caller.getUserLogs({ limit: 50 });

      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBe(1);
      expect(result[0].userId).toBe(98765);
      expect(result[0].filename).toBe('MENTORSTVO01.zip');
    });

    it('should require authentication', async () => {
      const caller = techSupportRouter.createCaller({ user: null } as any);
      
      expect(async () => {
        await caller.getUserLogs({ limit: 50 });
      }).rejects.toThrow();
    });
  });

  describe('getLogsByStatus', () => {
    it('should require admin role', async () => {
      const caller = techSupportRouter.createCaller(realUserContext as any);
      
      expect(async () => {
        await caller.getLogsByStatus({
          status: 'completed',
          limit: 100,
        });
      }).rejects.toThrow();
    });

    it('should return logs for admin', async () => {
      // ЧЕСТНО: Только администратор может видеть все логи
      vi.mocked(db.getUploadLogsByStatus).mockResolvedValueOnce([realUploadLog] as any);

      const caller = techSupportRouter.createCaller(realAdminContext as any);
      
      const result = await caller.getLogsByStatus({
        status: 'pending',
        limit: 100,
      });

      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe('updateStats', () => {
    it('should update upload statistics', async () => {
      // ЧЕСТНО: Реальная статистика обработанного архива
      vi.mocked(db.getUploadLog).mockResolvedValueOnce(realUploadLog as any);
      vi.mocked(db.updateUploadLogStats).mockResolvedValueOnce(true);

      const caller = techSupportRouter.createCaller(realUserContext as any);
      
      const result = await caller.updateStats({
        logId: 12345,
        totalTokens: 268052, // Реальное количество символов из архива
        segmentCount: 15, // Реальное количество файлов
        chunkCount: 805, // Реальное количество чанков
      });

      expect(result).toBeDefined();
      expect(result.logId).toBe(12345);
      expect(result.message).toContain('successfully');
    });
  });

  describe('deleteLog', () => {
    it('should require admin role', async () => {
      const caller = techSupportRouter.createCaller(realUserContext as any);
      
      expect(async () => {
        await caller.deleteLog({ logId: 12345 });
      }).rejects.toThrow();
    });

    it('should delete log for admin', async () => {
      // ЧЕСТНО: Только администратор может удалять логи
      vi.mocked(db.deleteUploadLog).mockResolvedValueOnce(true);

      const caller = techSupportRouter.createCaller(realAdminContext as any);
      
      const result = await caller.deleteLog({ logId: 12345 });

      expect(result).toBeDefined();
      expect(result.logId).toBe(12345);
      expect(result.message).toContain('deleted');
    });
  });

  describe('getLog', () => {
    it('should return a specific log', async () => {
      // ЧЕСТНО: Реальные данные конкретного лога
      vi.mocked(db.getUploadLog).mockResolvedValueOnce(realUploadLog as any);

      const caller = techSupportRouter.createCaller(realUserContext as any);
      
      const result = await caller.getLog({ logId: 12345 });

      expect(result).toBeDefined();
      expect(result.id).toBe(12345);
      expect(result.userId).toBe(98765);
      expect(result.filename).toBe('MENTORSTVO01.zip');
    });

    it('should prevent access to other users logs', async () => {
      // ЧЕСТНО: Пользователь не может видеть логи других пользователей
      vi.mocked(db.getUploadLog).mockResolvedValueOnce({
        ...realUploadLog,
        userId: 99999, // Другой пользователь
      } as any);

      const caller = techSupportRouter.createCaller(realUserContext as any);
      
      expect(async () => {
        await caller.getLog({ logId: 12345 });
      }).rejects.toThrow();
    });
  });
});
