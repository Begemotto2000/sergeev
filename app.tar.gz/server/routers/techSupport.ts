import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import * as db from "../db";
import { TRPCError } from "@trpc/server";
import * as schema from "../../drizzle/schema";

export const techSupportRouter = router({
  /**
   * Upload a file and save it to S3 and database
   */
  uploadFile: protectedProcedure
    .input(z.object({
      filename: z.string().min(1).max(255),
      fileType: z.enum(["json", "srt", "pdf", "docx", "txt", "zip"]),
      fileBuffer: z.instanceof(Buffer),
    }))
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }

      try {
        const { storagePut } = await import("../storage");
        
        // Upload to S3
        const fileKey = `uploads/${ctx.user.id}/${Date.now()}_${input.filename}`;
        const { url: fileUrl } = await storagePut(fileKey, input.fileBuffer, "application/octet-stream");

        // Save to database
        const dbInstance = await db.getDb();
        if (!dbInstance) {
          throw new Error("Database not available");
        }

        const result = await dbInstance.insert(schema.transcriptionUploads).values({
          userId: ctx.user.id,
          filename: input.filename,
          fileType: input.fileType,
          fileUrl,
          fileKey,
          status: "processing",
        });

        const uploadId = (result as any)?.insertId || (result as any)?.[0]?.id || (result as any)?.[0];

        return {
          uploadId,
          fileUrl,
          status: "processing",
          message: "File uploaded successfully",
        };
      } catch (error) {
        console.error("[TechSupport] Failed to upload file:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to upload file",
        });
      }
    }),

  /**
   * Start a new upload process and return a log ID for tracking
   */
  startUpload: protectedProcedure
    .input(z.object({
      filename: z.string().min(1).max(255),
      fileType: z.enum(["json", "srt", "pdf", "docx", "txt", "zip"]),
    }))
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }

      try {
        const result = await db.saveUploadLog({
          userId: ctx.user.id,
          filename: input.filename,
          fileType: input.fileType,
          ipAddress: ctx.req.ip,
          userAgent: ctx.req.get("user-agent"),
        });

        // Get the inserted ID from the result
        // Drizzle returns { insertId: number } for MySQL inserts
        const logId = (result as any)?.insertId || (result as any)?.id;
        
        if (!logId) {
          throw new Error('Failed to get insert ID from database result');
        }
        
        return {
          logId,
          status: "pending",
          message: "Upload process started",
        };
      } catch (error) {
        console.error("[TechSupport] Failed to start upload:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to start upload process",
        });
      }
    }),

  /**
   * Update a specific stage of the upload process
   */
  updateStage: protectedProcedure
    .input(z.object({
      logId: z.number().int().positive(),
      stageName: z.enum(["extraction", "parsing", "chunking", "indexing"]),
      status: z.enum(["pending", "processing", "completed", "failed"]),
      progress: z.number().int().min(0).max(100),
      message: z.string(),
      error: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }

      try {
        // Verify that the log belongs to the current user
        const log = await db.getUploadLog(input.logId);
        if (!log || log.userId !== ctx.user.id) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "You don't have permission to update this log",
          });
        }

        await db.updateUploadStage(input.logId, input.stageName, {
          status: input.status,
          progress: input.progress,
          message: input.message,
          error: input.error,
        });

        // Get updated log
        const updatedLog = await db.getUploadLog(input.logId);
        
        return {
          logId: input.logId,
          status: updatedLog?.status,
          stages: updatedLog?.stages,
          message: "Stage updated successfully",
        };
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        console.error("[TechSupport] Failed to update stage:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to update stage",
        });
      }
    }),

  /**
   * Update upload statistics after processing
   */
  updateStats: protectedProcedure
    .input(z.object({
      logId: z.number().int().positive(),
      totalTokens: z.number().int().optional(),
      segmentCount: z.number().int().optional(),
      chunkCount: z.number().int().optional(),
      errorMessage: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }

      try {
        // Verify that the log belongs to the current user
        const log = await db.getUploadLog(input.logId);
        if (!log || log.userId !== ctx.user.id) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "You don't have permission to update this log",
          });
        }

        await db.updateUploadLogStats(input.logId, {
          totalTokens: input.totalTokens,
          segmentCount: input.segmentCount,
          chunkCount: input.chunkCount,
          errorMessage: input.errorMessage,
        });

        return {
          logId: input.logId,
          message: "Statistics updated successfully",
        };
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        console.error("[TechSupport] Failed to update stats:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to update statistics",
        });
      }
    }),

  /**
   * Get upload log details
   */
  getLog: protectedProcedure
    .input(z.object({
      logId: z.number().int().positive(),
    }))
    .query(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }

      try {
        const log = await db.getUploadLog(input.logId);
        if (!log || log.userId !== ctx.user.id) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Upload log not found",
          });
        }

        return log;
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        console.error("[TechSupport] Failed to get log:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to retrieve log",
        });
      }
    }),

  /**
   * Get dashboard statistics (public, for single-user mode)
   */
  getDashboardStats: publicProcedure
    .query(async () => {
      try {
        const logs = await db.getUserUploadLogs(1, 100);
        
        const totalUploads = logs.length;
        const successfulUploads = logs.filter(log => log.status === 'completed').length;
        const failedUploads = logs.filter(log => log.status === 'failed').length;
        const pendingUploads = logs.filter(log => log.status === 'processing' || log.status === 'pending').length;
        
        const successRate = totalUploads > 0 ? Math.round((successfulUploads / totalUploads) * 100) : 0;
        
        return {
          totalUploads,
          successfulUploads,
          failedUploads,
          pendingUploads,
          successRate,
          recentUploads: logs.slice(0, 10),
        };
      } catch (error) {
        console.error('[TechSupport] Failed to get dashboard stats:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Failed to retrieve dashboard stats',
        });
      }
    }),

  /**
   * Get all upload logs for the current user
   */
  getUserLogs: protectedProcedure
    .input(z.object({
      limit: z.number().int().min(1).max(100).default(50),
    }))
    .query(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }

      try {
        const logs = await db.getUserUploadLogs(ctx.user.id, input.limit);
        return logs;
      } catch (error) {
        console.error("[TechSupport] Failed to get user logs:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to retrieve upload logs",
        });
      }
    }),

  /**
   * Get all logs with a specific status (admin only)
   */
  getLogsByStatus: protectedProcedure
    .input(z.object({
      status: z.enum(["pending", "processing", "completed", "failed"]),
      limit: z.number().int().min(1).max(100).default(100),
    }))
    .query(async ({ input, ctx }) => {
      if (!ctx.user || ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }

      try {
        const logs = await db.getUploadLogsByStatus(input.status, input.limit);
        return logs;
      } catch (error) {
        console.error("[TechSupport] Failed to get logs by status:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to retrieve logs",
        });
      }
    }),

  /**
   * Delete an upload log (admin only)
   */
  deleteLog: protectedProcedure
    .input(z.object({
      logId: z.number().int().positive(),
    }))
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user || ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }

      try {
        await db.deleteUploadLog(input.logId);
        return {
          logId: input.logId,
          message: "Log deleted successfully",
        };
      } catch (error) {
        console.error("[TechSupport] Failed to delete log:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to delete log",
        });
      }
    }),

  /**
   * Submit an error report
   */
  submitErrorReport: protectedProcedure
    .input(z.object({
      title: z.string().min(1).max(255),
      description: z.string().min(1),
      email: z.string().email().optional(),
      screenshotUrl: z.string().url().optional(),
      screenshotKey: z.string().optional(),
      priority: z.enum(["low", "medium", "high", "critical"]).default("medium"),
    }))
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }

      try {
        const result = await db.createErrorReport({
          userId: ctx.user.id,
          title: input.title,
          description: input.description,
          email: input.email || ctx.user.email,
          screenshotUrl: input.screenshotUrl,
          screenshotKey: input.screenshotKey,
          priority: input.priority,
        });

        return {
          success: true,
          message: "Error report submitted successfully",
          reportId: (result as any)?.insertId || (result as any)?.id,
        };
      } catch (error) {
        console.error("[TechSupport] Failed to submit error report:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to submit error report",
        });
      }
    }),

  /**
   * Get user's error reports
   */
  getMyErrorReports: protectedProcedure
    .query(async ({ ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }

      try {
        const reports = await db.getErrorReports(ctx.user.id);
        return reports;
      } catch (error) {
        console.error("[TechSupport] Failed to get error reports:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to retrieve error reports",
        });
      }
    }),

  /**
   * Get all error reports (admin only)
   */
  getAllErrorReports: protectedProcedure
    .query(async ({ ctx }) => {
      if (!ctx.user || ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }

      try {
        const reports = await db.getAllErrorReports();
        return reports;
      } catch (error) {
        console.error("[TechSupport] Failed to get all error reports:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to retrieve error reports",
        });
      }
    }),

  /**
   * Update error report status (admin only)
   */
  updateErrorReportStatus: protectedProcedure
    .input(z.object({
      reportId: z.number().int().positive(),
      status: z.enum(["new", "acknowledged", "in-progress", "resolved", "closed"]),
    }))
    .mutation(async ({ input, ctx }) => {
      if (!ctx.user || ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }

      try {
        await db.updateErrorReportStatus(input.reportId, input.status);
        return {
          success: true,
          message: "Error report status updated",
        };
      } catch (error) {
        console.error("[TechSupport] Failed to update error report:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to update error report",
        });
      }
    }),

});
