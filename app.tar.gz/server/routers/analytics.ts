/**
 * Analytics tRPC Router
 * Provides analytics endpoints for tracking and insights
 */

import { z } from 'zod';
import { protectedProcedure, router } from '../_core/trpc';
import * as db from '../db';
import {
  getModeStatistics,
  getTrendingQueries,
  getModeEffectivenessScore,
  compareModesEffectiveness,
  generateAnalyticsInsights,
  generateRecommendations,
} from '../analytics';
import type { QueryAnalytics } from '../analytics';

/**
 * Get analytics data from database
 * ЧЕСТНО: Используются только реальные данные из БД, без mock
 */
async function getAnalyticsData(): Promise<QueryAnalytics[]> {
  const startTime = Date.now();
  
  try {
    console.log('[ANALYTICS] Получение реальных данных из БД');
    
    // Получаем реальные данные из searchHistory таблицы
    const searchHistory = await db.getUserSearchHistory(1, 100); // userId=1 для admin
    
    if (!searchHistory || searchHistory.length === 0) {
      console.warn('[ANALYTICS] ⚠️ В БД нет данных поиска');
      return [];
    }

    const duration = Date.now() - startTime;
    console.log(`[ANALYTICS] ✅ Получено ${searchHistory?.length || 0} реальных записей (${duration}ms)`);
    
    return (searchHistory || []).map((record: any) => ({
      queryId: record.id?.toString() || '',
      query: record.query || '',
      mode: record.mode || 'ОТВЕТ',
      resultCount: record.resultCount || 0,
      responseTime: record.responseTime || 0,
      confidence: record.confidence || 0,
      timestamp: record.createdAt || new Date(),
    }));
  } catch (error) {
    const duration = Date.now() - startTime;
    console.error(`[ANALYTICS] ❌ ОШИБКА (${duration}ms):`, error);
    throw error;
  }
}

/**
 * Analytics Router
 * STANDARD: ЧеЧиЧе (Четко, Чисто, Честно) - только реальные данные из БД
 */
export const analyticsRouter = router({
  /**
   * Get mode statistics
   */
  getModeStats: protectedProcedure.query(async () => {
    const startTime = Date.now();
    
    try {
      console.log('[ANALYTICS] Получение статистики по режимам');
      
      const data = await getAnalyticsData();
      const stats = getModeStatistics(data);

      const duration = Date.now() - startTime;
      console.log(`[ANALYTICS] ✅ Статистика получена (${duration}ms)`);

      return {
        ok: true,
        stats,
        totalQueries: data.length,
      };
    } catch (error) {
      const duration = Date.now() - startTime;
      console.error(`[ANALYTICS] ❌ ОШИБКА (${duration}ms):`, error);
      return {
        ok: false,
        error: 'Failed to get statistics',
        stats: [],
        totalQueries: 0,
      };
    }
  }),

  /**
   * Get trending queries
   */
  getTrendingQueries: protectedProcedure
    .input(z.object({ limit: z.number().int().min(1).max(20).optional().default(10) }))
    .query(async ({ input }) => {
      const startTime = Date.now();
      
      try {
        console.log(`[ANALYTICS] Получение топ ${input.limit} трендовых запросов`);
        
        const data = await getAnalyticsData();
        const trending = getTrendingQueries(data, input.limit);

        const duration = Date.now() - startTime;
        console.log(`[ANALYTICS] ✅ Тренды получены (${duration}ms)`);

        return {
          ok: true,
          trending,
        };
      } catch (error) {
        const duration = Date.now() - startTime;
        console.error(`[ANALYTICS] ❌ ОШИБКА (${duration}ms):`, error);
        return {
          ok: false,
          error: 'Failed to get trending queries',
          trending: [],
        };
      }
    }),

  /**
   * Get mode effectiveness comparison
   */
  getModeEffectiveness: protectedProcedure.query(async () => {
    const startTime = Date.now();
    
    try {
      console.log('[ANALYTICS] Сравнение эффективности режимов');
      
      const data = await getAnalyticsData();
      const stats = getModeStatistics(data);
      const comparison = compareModesEffectiveness(stats);

      const effectiveness = Array.from(comparison.entries()).map(([mode, score]) => ({
        mode,
        score: Math.round(score),
      }));

      const duration = Date.now() - startTime;
      console.log(`[ANALYTICS] ✅ Сравнение завершено (${duration}ms)`);

      return {
        ok: true,
        effectiveness,
      };
    } catch (error) {
      const duration = Date.now() - startTime;
      console.error(`[ANALYTICS] ❌ ОШИБКА (${duration}ms):`, error);
      return {
        ok: false,
        error: 'Failed to get effectiveness',
        effectiveness: [],
      };
    }
  }),

  /**
   * Get analytics insights
   */
  getInsights: protectedProcedure.query(async () => {
    const startTime = Date.now();
    
    try {
      console.log('[ANALYTICS] Генерация инсайтов');
      
      const data = await getAnalyticsData();
      const insights = await generateAnalyticsInsights(data);

      const duration = Date.now() - startTime;
      console.log(`[ANALYTICS] ✅ Инсайты сгенерированы (${duration}ms)`);

      return {
        ok: true,
        insights,
      };
    } catch (error) {
      const duration = Date.now() - startTime;
      console.error(`[ANALYTICS] ❌ ОШИБКА (${duration}ms):`, error);
      return {
        ok: false,
        error: 'Failed to generate insights',
        insights: [],
      };
    }
  }),

  /**
   * Get recommendations
   */
  getRecommendations: protectedProcedure.query(async () => {
    const startTime = Date.now();
    
    try {
      console.log('[ANALYTICS] Генерация рекомендаций');
      
      const data = await getAnalyticsData();
      const recommendations = await generateRecommendations(data);

      const duration = Date.now() - startTime;
      console.log(`[ANALYTICS] ✅ Рекомендации сгенерированы (${duration}ms)`);

      return {
        ok: true,
        recommendations,
      };
    } catch (error) {
      const duration = Date.now() - startTime;
      console.error(`[ANALYTICS] ❌ ОШИБКА (${duration}ms):`, error);
      return {
        ok: false,
        error: 'Failed to generate recommendations',
        recommendations: [],
      };
    }
  }),

  /**
   * Get dashboard summary
   */
  getDashboardSummary: protectedProcedure.query(async () => {
    const startTime = Date.now();
    
    try {
      console.log('[ANALYTICS] Получение summary для dashboard');
      
      const data = await getAnalyticsData();
      
      if (data.length === 0) {
        console.warn('[ANALYTICS] ⚠️ Нет данных для summary');
        return {
          ok: true,
          summary: {
            totalQueries: 0,
            mostUsedMode: 'N/A',
            bestPerformingMode: 'N/A',
            avgResponseTime: 0,
            avgConfidence: 0,
            trendingQueries: [],
            topInsight: null,
          },
        };
      }
      
      const stats = getModeStatistics(data);
      const trending = getTrendingQueries(data, 5);
      const comparison = compareModesEffectiveness(stats);
      const insights = await generateAnalyticsInsights(data);

      const mostUsedMode = stats[0];
      const bestPerformingMode = Array.from(comparison.entries()).sort(
        (a, b) => b[1] - a[1]
      )[0];

      const duration = Date.now() - startTime;
      console.log(`[ANALYTICS] ✅ Summary получен (${duration}ms)`);

      return {
        ok: true,
        summary: {
          totalQueries: data.length,
          mostUsedMode: mostUsedMode?.mode || 'N/A',
          bestPerformingMode: bestPerformingMode?.[0] || 'N/A',
          avgResponseTime:
            data.length > 0 ? data.reduce((sum, q) => sum + q.responseTime, 0) / data.length : 0,
          avgConfidence:
            data.length > 0 ? data.reduce((sum, q) => sum + q.confidence, 0) / data.length : 0,
          trendingQueries: trending,
          topInsight: insights[0],
        },
      };
    } catch (error) {
      const duration = Date.now() - startTime;
      console.error(`[ANALYTICS] ❌ ОШИБКА (${duration}ms):`, error);
      return {
        ok: false,
        error: 'Failed to get dashboard summary',
        summary: null,
      };
    }
  }),
});
