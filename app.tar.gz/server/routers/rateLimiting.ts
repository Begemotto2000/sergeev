/**
 * Rate Limiting Router
 * Provides endpoints for rate limit management and monitoring
 */

import { z } from 'zod';
import { protectedProcedure, router, adminProcedure } from '../_core/trpc';
import {
  checkRateLimit,
  checkGlobalRateLimit,
  getAdaptiveRateLimit,
  getRateLimitStats,
  resetRateLimit,
  resetGlobalRateLimit,
  recordRateLimitEvent,
  getRateLimitHeaders,
} from '../rateLimiter';

export const rateLimitingRouter = router({
  /**
   * Check user rate limit status
   */
  checkUserLimit: protectedProcedure
    .input(z.object({ endpoint: z.string().optional() }))
    .query(async ({ ctx, input }) => {
      const status = await checkRateLimit(ctx.user.id);
      return {
        ...status,
        headers: getRateLimitHeaders(status),
      };
    }),

  /**
   * Check global rate limit status
   */
  checkGlobalLimit: protectedProcedure.query(async () => {
    const status = await checkGlobalRateLimit();
    return {
      ...status,
      headers: getRateLimitHeaders(status),
    };
  }),

  /**
   * Get adaptive rate limit based on system load
   */
  getAdaptiveLimit: protectedProcedure
    .input(z.object({ systemLoad: z.number().min(0).max(100).optional() }))
    .query(async ({ ctx, input }) => {
      const adaptiveLimit = await getAdaptiveRateLimit(ctx.user.id, input.systemLoad || 50);
      return {
        adaptiveLimit,
        baseLimit: 100,
        systemLoad: input.systemLoad || 50,
      };
    }),

  /**
   * Get user rate limit statistics
   */
  getUserStats: protectedProcedure.query(async ({ ctx }) => {
    const stats = await getRateLimitStats(ctx.user.id);
    return {
      ...stats,
      userId: ctx.user.id,
      timestamp: new Date().toISOString(),
    };
  }),

  /**
   * Record rate limit event (called by middleware)
   */
  recordEvent: protectedProcedure
    .input(
      z.object({
        endpoint: z.string(),
        status: z.enum(['allowed', 'limited']),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await recordRateLimitEvent(ctx.user.id, input.endpoint, input.status);
      return { success: true };
    }),

  /**
   * Get rate limit summary
   */
  getSummary: protectedProcedure.query(async ({ ctx }) => {
    const [userStatus, globalStatus, userStats] = await Promise.all([
      checkRateLimit(ctx.user.id),
      checkGlobalRateLimit(),
      getRateLimitStats(ctx.user.id),
    ]);

    return {
      user: {
        current: userStatus.current,
        limit: userStatus.limit,
        remaining: userStatus.remaining,
        isLimited: userStatus.isLimited,
        resetTime: new Date(userStatus.resetTime).toISOString(),
      },
      global: {
        current: globalStatus.current,
        limit: globalStatus.limit,
        remaining: globalStatus.remaining,
        isLimited: globalStatus.isLimited,
      },
      statistics: {
        allowedRequests: userStats.allowedCount,
        limitedRequests: userStats.limitedCount,
        totalRequests: userStats.totalEvents,
        limitPercentage: userStats.limitPercentage.toFixed(2),
      },
    };
  }),

  /**
   * Admin: Reset user rate limit
   */
  adminResetUserLimit: adminProcedure
    .input(z.object({ userId: z.number() }))
    .mutation(async ({ input }) => {
      await resetRateLimit(input.userId);
      return { success: true, message: `Rate limit reset for user ${input.userId}` };
    }),

  /**
   * Admin: Reset global rate limit
   */
  adminResetGlobalLimit: adminProcedure.mutation(async () => {
    await resetGlobalRateLimit();
    return { success: true, message: 'Global rate limit reset' };
  }),

  /**
   * Admin: Get global rate limit statistics
   */
  adminGetGlobalStats: adminProcedure.query(async () => {
    const globalStatus = await checkGlobalRateLimit();
    return {
      current: globalStatus.current,
      limit: globalStatus.limit,
      remaining: globalStatus.remaining,
      isLimited: globalStatus.isLimited,
      resetTime: new Date(globalStatus.resetTime).toISOString(),
      utilizationPercentage: ((globalStatus.current / globalStatus.limit) * 100).toFixed(2),
    };
  }),

  /**
   * Get rate limit configuration info
   */
  getConfigInfo: protectedProcedure.query(async () => {
    return {
      limits: {
        answerQuery: {
          windowMs: 60000,
          maxRequests: 30,
          description: 'Answer queries per minute',
        },
        uploadTranscription: {
          windowMs: 3600000,
          maxRequests: 10,
          description: 'Transcription uploads per hour',
        },
        deepResearch: {
          windowMs: 60000,
          maxRequests: 5,
          description: 'Deep research queries per minute',
        },
        global: {
          windowMs: 60000,
          maxRequests: 1000,
          description: 'Global requests per minute',
        },
      },
      features: {
        adaptiveLimits: true,
        priorityBased: true,
        burstAllowance: true,
        alerting: true,
      },
    };
  }),
});
