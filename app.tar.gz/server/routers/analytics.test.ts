import { describe, it, expect } from 'vitest';
import { analyticsRouter } from './analytics';

describe('Analytics Router', () => {
  describe('getModeStats', () => {
    it('should return mode statistics', async () => {
      const caller = analyticsRouter.createCaller({
        user: { id: 'test', role: 'user' },
      } as any);

      const result = await caller.getModeStats();

      expect(result.ok).toBe(true);
      expect(result.stats).toBeDefined();
      expect(Array.isArray(result.stats)).toBe(true);
      expect(result.totalQueries).toBeGreaterThan(0);
    });
  });

  describe('getTrendingQueries', () => {
    it('should return trending queries', async () => {
      const caller = analyticsRouter.createCaller({
        user: { id: 'test', role: 'user' },
      } as any);

      const result = await caller.getTrendingQueries({ limit: 5 });

      expect(result.ok).toBe(true);
      expect(Array.isArray(result.trending)).toBe(true);
      expect(result.trending.length).toBeLessThanOrEqual(5);
    });
  });

  describe('getModeEffectiveness', () => {
    it('should return mode effectiveness scores', async () => {
      const caller = analyticsRouter.createCaller({
        user: { id: 'test', role: 'user' },
      } as any);

      const result = await caller.getModeEffectiveness();

      expect(result.ok).toBe(true);
      expect(Array.isArray(result.effectiveness)).toBe(true);

      for (const item of result.effectiveness) {
        expect(item.mode).toBeDefined();
        expect(item.score).toBeGreaterThanOrEqual(0);
        expect(item.score).toBeLessThanOrEqual(100);
      }
    });
  });

  describe('getInsights', () => {
    it('should return analytics insights', async () => {
      const caller = analyticsRouter.createCaller({
        user: { id: 'test', role: 'user' },
      } as any);

      const result = await caller.getInsights();

      expect(result.ok).toBe(true);
      expect(Array.isArray(result.insights)).toBe(true);

      for (const insight of result.insights) {
        expect(insight.title).toBeDefined();
        expect(insight.description).toBeDefined();
        expect(insight.recommendation).toBeDefined();
        expect(['high', 'medium', 'low']).toContain(insight.priority);
      }
    });
  });

  describe('getRecommendations', () => {
    it('should return recommendations', async () => {
      const caller = analyticsRouter.createCaller({
        user: { id: 'test', role: 'user' },
      } as any);

      const result = await caller.getRecommendations();

      expect(result.ok).toBe(true);
      expect(Array.isArray(result.recommendations)).toBe(true);
    });
  });

  describe('getDashboardSummary', () => {
    it('should return dashboard summary', async () => {
      const caller = analyticsRouter.createCaller({
        user: { id: 'test', role: 'user' },
      } as any);

      const result = await caller.getDashboardSummary();

      expect(result.ok).toBe(true);
      expect(result.summary).toBeDefined();
      expect(result.summary?.totalQueries).toBeGreaterThan(0);
      expect(result.summary?.mostUsedMode).toBeDefined();
      expect(result.summary?.bestPerformingMode).toBeDefined();
      expect(result.summary?.avgResponseTime).toBeGreaterThan(0);
      expect(result.summary?.avgConfidence).toBeGreaterThan(0);
      expect(Array.isArray(result.summary?.trendingQueries)).toBe(true);
    });
  });
});
