/**
 * Advanced Search Filters
 * Provides filtering, sorting, and query optimization
 */

export interface SearchFilters {
  query: string;
  dateRange?: {
    start: Date;
    end: Date;
  };
  languages?: string[];
  sourceTypes?: string[];
  confidenceMin?: number;
  confidenceMax?: number;
  tags?: string[];
  sortBy?: 'relevance' | 'date' | 'confidence';
  sortOrder?: 'asc' | 'desc';
  limit?: number;
  offset?: number;
}

export interface FilteredResult {
  id: string;
  title: string;
  content: string;
  confidence: number;
  language: string;
  sourceType: string;
  tags: string[];
  createdAt: Date;
  relevanceScore: number;
}

/**
 * Build Qdrant filter from search filters
 */
export function buildQdrantFilter(filters: SearchFilters): Record<string, any> {
  const qdrantFilter: Record<string, any> = {};

  // Date range filter
  if (filters.dateRange) {
    qdrantFilter.date_range = {
      gte: filters.dateRange.start.getTime(),
      lte: filters.dateRange.end.getTime(),
    };
  }

  // Language filter
  if (filters.languages && filters.languages.length > 0) {
    qdrantFilter.language = {
      $in: filters.languages,
    };
  }

  // Source type filter
  if (filters.sourceTypes && filters.sourceTypes.length > 0) {
    qdrantFilter.source_type = {
      $in: filters.sourceTypes,
    };
  }

  // Confidence range filter
  if (filters.confidenceMin !== undefined || filters.confidenceMax !== undefined) {
    qdrantFilter.confidence = {};
    if (filters.confidenceMin !== undefined) {
      qdrantFilter.confidence.gte = filters.confidenceMin;
    }
    if (filters.confidenceMax !== undefined) {
      qdrantFilter.confidence.lte = filters.confidenceMax;
    }
  }

  // Tags filter
  if (filters.tags && filters.tags.length > 0) {
    qdrantFilter.tags = {
      $in: filters.tags,
    };
  }

  return qdrantFilter;
}

/**
 * Optimize query for better search results
 */
export function optimizeQuery(query: string): string {
  // Remove extra whitespace
  let optimized = query.trim().replace(/\s+/g, ' ');

  // Convert to lowercase for consistency
  optimized = optimized.toLowerCase();

  // Remove common stop words (optional)
  const stopWords = ['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for'];
  const words = optimized.split(' ');
  const filtered = words.filter(word => !stopWords.includes(word) || words.length <= 2);

  return filtered.join(' ');
}

/**
 * Calculate relevance score
 */
export function calculateRelevanceScore(
  query: string,
  content: string,
  vectorSimilarity: number,
  metadata?: { language?: string; sourceType?: string; confidence?: number }
): number {
  let score = vectorSimilarity * 100;

  // Boost score for exact matches
  if (content.toLowerCase().includes(query.toLowerCase())) {
    score *= 1.2;
  }

  // Boost score for high confidence
  if (metadata?.confidence && metadata.confidence > 0.9) {
    score *= 1.1;
  }

  // Normalize to 0-100
  return Math.min(100, Math.max(0, score));
}

/**
 * Apply filters to results
 */
export function applyFilters(results: FilteredResult[], filters: SearchFilters): FilteredResult[] {
  let filtered = [...results];

  // Date range filter
  if (filters.dateRange) {
    filtered = filtered.filter(
      (r) => r.createdAt >= filters.dateRange!.start && r.createdAt <= filters.dateRange!.end
    );
  }

  // Language filter
  if (filters.languages && filters.languages.length > 0) {
    filtered = filtered.filter((r) => filters.languages!.includes(r.language));
  }

  // Source type filter
  if (filters.sourceTypes && filters.sourceTypes.length > 0) {
    filtered = filtered.filter((r) => filters.sourceTypes!.includes(r.sourceType));
  }

  // Confidence filter
  if (filters.confidenceMin !== undefined) {
    filtered = filtered.filter((r) => r.confidence >= filters.confidenceMin!);
  }
  if (filters.confidenceMax !== undefined) {
    filtered = filtered.filter((r) => r.confidence <= filters.confidenceMax!);
  }

  // Tags filter
  if (filters.tags && filters.tags.length > 0) {
    filtered = filtered.filter((r) =>
      filters.tags!.some((tag) => r.tags.includes(tag))
    );
  }

  return filtered;
}

/**
 * Sort results
 */
export function sortResults(results: FilteredResult[], filters: SearchFilters): FilteredResult[] {
  const sorted = [...results];
  const sortBy = filters.sortBy || 'relevance';
  const sortOrder = filters.sortOrder || 'desc';

  sorted.sort((a, b) => {
    let comparison = 0;

    switch (sortBy) {
      case 'relevance':
        comparison = a.relevanceScore - b.relevanceScore;
        break;
      case 'date':
        comparison = a.createdAt.getTime() - b.createdAt.getTime();
        break;
      case 'confidence':
        comparison = a.confidence - b.confidence;
        break;
    }

    return sortOrder === 'asc' ? comparison : -comparison;
  });

  return sorted;
}

/**
 * Paginate results
 */
export function paginateResults(results: FilteredResult[], filters: SearchFilters): FilteredResult[] {
  const limit = filters.limit || 20;
  const offset = filters.offset || 0;

  return results.slice(offset, offset + limit);
}

/**
 * Apply all filters, sort, and paginate
 */
export function processSearchResults(
  results: FilteredResult[],
  filters: SearchFilters
): {
  results: FilteredResult[];
  total: number;
  hasMore: boolean;
} {
  let processed = applyFilters(results, filters);
  const total = processed.length;

  processed = sortResults(processed, filters);
  processed = paginateResults(processed, filters);

  const limit = filters.limit || 20;
  const offset = filters.offset || 0;

  return {
    results: processed,
    total,
    hasMore: offset + limit < total,
  };
}

/**
 * Get available filter options
 */
export function getAvailableFilterOptions(results: FilteredResult[]): {
  languages: string[];
  sourceTypes: string[];
  tags: string[];
  dateRange: { min: Date; max: Date };
  confidenceRange: { min: number; max: number };
} {
  const languages = new Set<string>();
  const sourceTypes = new Set<string>();
  const tags = new Set<string>();
  let minDate = new Date();
  let maxDate = new Date();
  let minConfidence = 1;
  let maxConfidence = 0;

  for (const result of results) {
    languages.add(result.language);
    sourceTypes.add(result.sourceType);
    result.tags.forEach((tag) => tags.add(tag));

    if (result.createdAt < minDate) minDate = result.createdAt;
    if (result.createdAt > maxDate) maxDate = result.createdAt;

    if (result.confidence < minConfidence) minConfidence = result.confidence;
    if (result.confidence > maxConfidence) maxConfidence = result.confidence;
  }

  return {
    languages: Array.from(languages),
    sourceTypes: Array.from(sourceTypes),
    tags: Array.from(tags),
    dateRange: { min: minDate, max: maxDate },
    confidenceRange: { min: minConfidence, max: maxConfidence },
  };
}

/**
 * Validate search filters
 */
export function validateSearchFilters(filters: SearchFilters): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!filters.query || filters.query.trim().length === 0) {
    errors.push('Query is required');
  }

  if (filters.query && filters.query.length > 1000) {
    errors.push('Query is too long (max 1000 characters)');
  }

  if (filters.confidenceMin !== undefined && (filters.confidenceMin < 0 || filters.confidenceMin > 1)) {
    errors.push('Confidence min must be between 0 and 1');
  }

  if (filters.confidenceMax !== undefined && (filters.confidenceMax < 0 || filters.confidenceMax > 1)) {
    errors.push('Confidence max must be between 0 and 1');
  }

  if (
    filters.confidenceMin !== undefined &&
    filters.confidenceMax !== undefined &&
    filters.confidenceMin > filters.confidenceMax
  ) {
    errors.push('Confidence min must be less than or equal to confidence max');
  }

  if (filters.limit && (filters.limit < 1 || filters.limit > 1000)) {
    errors.push('Limit must be between 1 and 1000');
  }

  if (filters.offset && filters.offset < 0) {
    errors.push('Offset must be non-negative');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}
