/**
 * Answer Composition Module
 * Composes coherent answers from multiple relevant sources using LLM
 */

import { invokeLLM } from './_core/llm';

export interface SourceChunk {
  id: string;
  content: string;
  videoId: string;
  timecode: string;
  score: number;
  moduleNumber?: number;
}

export interface ComposedAnswer {
  answer: string;
  sources: SourceChunk[];
  confidence: number;
  synthesisMethod: 'direct' | 'synthesis' | 'expansion';
  keyThemes: string[];
}

/**
 * Compose answer from multiple relevant sources
 */
export async function composeAnswer(
  query: string,
  sources: SourceChunk[],
  mode: 'ОТВЕТ' | 'ТАЙМКОД' | 'DEEP RESEARCH' | 'ИМИГО' = 'ОТВЕТ'
): Promise<ComposedAnswer> {
  if (!sources || sources.length === 0) {
    return {
      answer: 'No relevant sources found for your query.',
      sources: [],
      confidence: 0,
      synthesisMethod: 'direct',
      keyThemes: [],
    };
  }

  try {
    // Group sources by relevance and content similarity
    const groupedSources = groupSourcesByTheme(sources);
    const sourceContext = formatSourcesForLLM(groupedSources);

    // Determine synthesis method based on source count and relevance
    const synthesisMethod = determineSynthesisMethod(sources);

    // Generate system prompt based on mode
    const systemPrompt = getCompositionSystemPrompt(mode);

    // Call LLM to compose answer
    const response = await invokeLLM({
      messages: [
        {
          role: 'system',
          content: systemPrompt,
        },
        {
          role: 'user',
          content: `Вопрос: ${query}

Источники из базы знаний:
${sourceContext}

Пожалуйста, составьте полный, логичный и объемный ответ на основе этих источников. Убедитесь, что ответ:
1. Охватывает все релевантные аспекты
2. Логично связывает информацию из разных источников
3. Четко объясняет концепции
4. Предоставляет практические примеры где возможно`,
        },
      ],
    });

    const answerText = typeof response.choices[0].message.content === 'string'
      ? response.choices[0].message.content
      : '';

    // Extract key themes from the answer
    const keyThemes = extractKeyThemes(answerText);

    // Calculate confidence based on source scores
    const confidence = calculateConfidence(sources);

    return {
      answer: answerText,
      sources,
      confidence,
      synthesisMethod,
      keyThemes,
    };
  } catch (error) {
    console.error('Answer composition error:', error);
    throw error;
  }
}

/**
 * Group sources by theme/topic
 */
function groupSourcesByTheme(sources: SourceChunk[]): Map<string, SourceChunk[]> {
  const grouped = new Map<string, SourceChunk[]>();

  for (const source of sources) {
    // Extract theme from content (first 50 chars)
    const theme = source.content.substring(0, 50).toLowerCase();
    
    if (!grouped.has(theme)) {
      grouped.set(theme, []);
    }
    grouped.get(theme)!.push(source);
  }

  return grouped;
}

/**
 * Format sources for LLM context
 */
function formatSourcesForLLM(groupedSources: Map<string, SourceChunk[]>): string {
  const formatted: string[] = [];
  let sourceIndex = 1;

  groupedSources.forEach((sources, theme) => {
    formatted.push(`\n**Тема: ${theme}**\n`);
    
    for (const source of sources) {
      formatted.push(
        `[Источник ${sourceIndex}] (Видео: ${source.videoId}, Время: ${source.timecode}, Релевантность: ${(source.score * 100).toFixed(0)}%)\n` +
        `${source.content}\n`
      );
      sourceIndex++;
    }
  });

  return formatted.join('\n');
}

/**
 * Determine synthesis method based on sources
 */
function determineSynthesisMethod(sources: SourceChunk[]): 'direct' | 'synthesis' | 'expansion' {
  if (sources.length === 1) {
    return 'direct'; // Single source, direct answer
  } else if (sources.length <= 3) {
    return 'synthesis'; // Few sources, synthesize
  } else {
    return 'expansion'; // Many sources, comprehensive expansion
  }
}

/**
 * Get system prompt based on mode
 */
function getCompositionSystemPrompt(mode: string): string {
  const basePrompt = `Вы - эксперт по материалам Ивана Сергеева. Ваша задача - составлять полные, логичные и объемные ответы на основе предоставленных источников.`;

  const modePrompts: Record<string, string> = {
    'ОТВЕТ': `${basePrompt} Сосредоточьтесь на прямых ответах с четкими объяснениями.`,
    'ТАЙМКОД': `${basePrompt} Указывайте точные таймкоды и видеоссылки для каждого пункта.`,
    'DEEP RESEARCH': `${basePrompt} Предоставьте глубокий анализ с множеством деталей и контекста.`,
    'ИМИГО': `${basePrompt} Генерируйте творческие идеи, инсайты и озарения на основе источников.`,
  };

  return modePrompts[mode] || basePrompt;
}

/**
 * Extract key themes from answer
 */
function extractKeyThemes(answer: string): string[] {
  const themes: string[] = [];
  
  // Extract text between ** markers (bold text)
  const boldMatches = answer.match(/\*\*([^*]+)\*\*/g);
  if (boldMatches) {
    themes.push(...boldMatches.map(m => m.replace(/\*\*/g, '')));
  }

  // Extract numbered items
  const numberedMatches = answer.match(/\d+\.\s+([^.\n]+)/g);
  if (numberedMatches) {
    themes.push(...numberedMatches.map(m => m.replace(/\d+\.\s+/, '')));
  }

  return themes.slice(0, 5); // Return top 5 themes
}

/**
 * Calculate confidence score
 */
function calculateConfidence(sources: SourceChunk[]): number {
  if (sources.length === 0) return 0;

  // Average score of top sources
  const topScores = sources
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .map(s => s.score);

  const avgScore = topScores.reduce((a, b) => a + b, 0) / topScores.length;
  
  // Adjust confidence based on source diversity
  const uniqueVideos = new Set(sources.map(s => s.videoId)).size;
  const diversityBonus = Math.min(0.1, uniqueVideos * 0.02);

  return Math.min(1, avgScore + diversityBonus);
}

/**
 * Generate follow-up questions based on answer
 */
export function generateFollowUpQuestions(
  answer: string,
  originalQuery: string
): string[] {
  const questions: string[] = [];

  // Extract key concepts from answer
  const concepts = extractKeyThemes(answer);

  // Generate follow-up questions
  if (concepts.length > 0) {
    questions.push(`Как ${concepts[0]} связано с ${originalQuery}?`);
  }
  if (concepts.length > 1) {
    questions.push(`Какова разница между ${concepts[0]} и ${concepts[1]}?`);
  }
  if (concepts.length > 2) {
    questions.push(`Как применить ${concepts[2]} на практике?`);
  }

  return questions.slice(0, 3);
}

/**
 * Validate answer quality
 */
export function validateAnswerQuality(answer: ComposedAnswer): {
  isValid: boolean;
  issues: string[];
} {
  const issues: string[] = [];

  // Check answer length
  if (answer.answer.length < 100) {
    issues.push('Answer is too short');
  }

  // Check confidence
  if (answer.confidence < 0.5) {
    issues.push('Low confidence score');
  }

  // Check sources
  if (answer.sources.length === 0) {
    issues.push('No sources provided');
  }

  // Check key themes
  if (answer.keyThemes.length === 0) {
    issues.push('No key themes extracted');
  }

  return {
    isValid: issues.length === 0,
    issues,
  };
}
