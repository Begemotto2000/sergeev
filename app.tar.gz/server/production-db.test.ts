import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import mysql from 'mysql2/promise';

describe('Production Database Connection', () => {
  let connection: mysql.Connection | null = null;

  beforeAll(async () => {
    try {
      const connectionString = process.env.PRODUCTION_DATABASE_URL;
      if (!connectionString) {
        throw new Error('PRODUCTION_DATABASE_URL not set');
      }

      // Parse connection string
      const url = new URL(connectionString);
      connection = await mysql.createConnection({
        host: url.hostname,
        user: url.username,
        password: url.password,
        database: url.pathname.slice(1),
        port: parseInt(url.port) || 3306,
      });

      console.log('✅ Connected to production database');
    } catch (error) {
      console.error('❌ Failed to connect to production database:', error);
      throw error;
    }
  });

  it('should connect to production database', async () => {
    expect(connection).toBeDefined();
  });

  it('should have upload_logs table', async () => {
    if (!connection) throw new Error('No connection');
    
    const [tables] = await connection.query(
      "SELECT COUNT(*) as count FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'upload_logs'"
    );
    
    expect((tables as any)[0].count).toBeGreaterThan(0);
  });

  it('should have indexed_transcriptions table', async () => {
    if (!connection) throw new Error('No connection');
    
    const [tables] = await connection.query(
      "SELECT COUNT(*) as count FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'indexed_transcriptions'"
    );
    
    expect((tables as any)[0].count).toBeGreaterThan(0);
  });

  it('should have upload logs data', async () => {
    if (!connection) throw new Error('No connection');
    
    const [result] = await connection.query(
      'SELECT COUNT(*) as count FROM upload_logs'
    );
    
    expect((result as any)[0].count).toBeGreaterThanOrEqual(0);
    console.log(`✅ Found ${(result as any)[0].count} upload logs`);
  });

  afterAll(async () => {
    if (connection) {
      await connection.end();
    }
  });
});
