/**
 * Webhook Delivery Service
 * Handles webhook delivery with retry logic and tracking
 */

import { Webhook, WebhookPayload, WebhookDelivery, calculateNextRetry, generateSignature } from './webhooks';

export interface DeliveryOptions {
  maxRetries: number;
  timeout: number;
  backoffMultiplier: number;
}

const DEFAULT_OPTIONS: DeliveryOptions = {
  maxRetries: 5,
  timeout: 30000, // 30 seconds
  backoffMultiplier: 2,
};

/**
 * Send webhook delivery
 */
export async function sendWebhookDelivery(
  webhook: Webhook,
  payload: WebhookPayload,
  options: Partial<DeliveryOptions> = {}
): Promise<{ success: boolean; statusCode?: number; error?: string }> {
  const finalOptions = { ...DEFAULT_OPTIONS, ...options };

  try {
    const payloadJson = JSON.stringify(payload);
    const signature = generateSignature(payloadJson, webhook.secret);

    const response = await fetch(webhook.url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Webhook-Signature': signature,
        'X-Webhook-ID': webhook.id,
        'X-Webhook-Event': payload.event,
        'User-Agent': 'Sergeev-Webhook-Delivery/1.0',
      },
      body: payloadJson,
      signal: AbortSignal.timeout(finalOptions.timeout),
    });

    if (response.ok) {
      return { success: true, statusCode: response.status };
    } else {
      return {
        success: false,
        statusCode: response.status,
        error: `HTTP ${response.status}`,
      };
    }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return {
      success: false,
      error: errorMessage,
    };
  }
}

/**
 * Process webhook delivery with retries
 */
export async function processWebhookDeliveryWithRetries(
  webhook: Webhook,
  payload: WebhookPayload,
  delivery: WebhookDelivery,
  options: Partial<DeliveryOptions> = {}
): Promise<WebhookDelivery> {
  const finalOptions = { ...DEFAULT_OPTIONS, ...options };
  let currentDelivery = { ...delivery };

  while (currentDelivery.attempts < finalOptions.maxRetries) {
    currentDelivery.attempts++;

    const result = await sendWebhookDelivery(webhook, payload, options);

    if (result.success) {
      return {
        ...currentDelivery,
        status: 'success',
        completedAt: Date.now(),
      };
    }

    if (currentDelivery.attempts < finalOptions.maxRetries) {
      currentDelivery.status = 'retrying';
      currentDelivery.nextRetry = calculateNextRetry(currentDelivery.attempts - 1);
      currentDelivery.error = result.error;

      // Wait before retrying
      await new Promise((resolve) =>
        setTimeout(resolve, Math.min(1000 * Math.pow(2, currentDelivery.attempts - 1), 60000))
      );
    } else {
      currentDelivery.status = 'failed';
      currentDelivery.error = result.error;
      currentDelivery.completedAt = Date.now();
    }
  }

  return currentDelivery;
}

/**
 * Batch process webhook deliveries
 */
export async function batchProcessWebhookDeliveries(
  deliveries: Array<{ webhook: Webhook; payload: WebhookPayload; delivery: WebhookDelivery }>,
  options: Partial<DeliveryOptions> = {}
): Promise<WebhookDelivery[]> {
  const results: WebhookDelivery[] = [];

  for (const { webhook, payload, delivery } of deliveries) {
    const result = await processWebhookDeliveryWithRetries(webhook, payload, delivery, options);
    results.push(result);

    // Add small delay between deliveries to avoid overwhelming the system
    await new Promise((resolve) => setTimeout(resolve, 100));
  }

  return results;
}

/**
 * Get retry information
 */
export function getRetryInfo(delivery: WebhookDelivery): {
  attempts: number;
  maxAttempts: number;
  nextRetry?: Date;
  canRetry: boolean;
} {
  return {
    attempts: delivery.attempts,
    maxAttempts: delivery.maxAttempts,
    nextRetry: delivery.nextRetry ? new Date(delivery.nextRetry) : undefined,
    canRetry: delivery.attempts < delivery.maxAttempts && delivery.status === 'retrying',
  };
}

/**
 * Calculate backoff delay
 */
export function calculateBackoffDelay(attempt: number, baseDelay: number = 1000): number {
  const maxDelay = 3600000; // 1 hour
  const delay = baseDelay * Math.pow(2, attempt);
  return Math.min(delay, maxDelay);
}

/**
 * Add jitter to backoff delay
 */
export function addJitterToDelay(delay: number, jitterPercentage: number = 10): number {
  const jitter = (Math.random() - 0.5) * 2 * (delay * (jitterPercentage / 100));
  return Math.max(delay + jitter, 0);
}

/**
 * Format delivery status for display
 */
export function formatDeliveryStatus(delivery: WebhookDelivery): string {
  switch (delivery.status) {
    case 'success':
      return `✓ Delivered (${delivery.attempts} attempt${delivery.attempts > 1 ? 's' : ''})`;
    case 'failed':
      return `✗ Failed after ${delivery.attempts} attempts: ${delivery.error}`;
    case 'pending':
      return 'Pending delivery';
    case 'retrying':
      return `Retrying (attempt ${delivery.attempts}/${delivery.maxAttempts})`;
    default:
      return 'Unknown status';
  }
}

/**
 * Check if delivery should be retried
 */
export function shouldRetryDelivery(delivery: WebhookDelivery, maxAge: number = 86400000): boolean {
  if (delivery.status === 'success' || delivery.status === 'failed') {
    return false;
  }

  if (delivery.attempts >= delivery.maxAttempts) {
    return false;
  }

  if (delivery.nextRetry && delivery.nextRetry > Date.now()) {
    return false;
  }

  const age = Date.now() - delivery.createdAt;
  return age < maxAge;
}

/**
 * Get delivery statistics
 */
export function getDeliveryStats(deliveries: WebhookDelivery[]): {
  total: number;
  successful: number;
  failed: number;
  retrying: number;
  pending: number;
  successRate: number;
  averageAttempts: number;
} {
  const stats = {
    total: deliveries.length,
    successful: deliveries.filter((d) => d.status === 'success').length,
    failed: deliveries.filter((d) => d.status === 'failed').length,
    retrying: deliveries.filter((d) => d.status === 'retrying').length,
    pending: deliveries.filter((d) => d.status === 'pending').length,
    successRate: 0,
    averageAttempts: 0,
  };

  if (stats.total > 0) {
    stats.successRate = (stats.successful / stats.total) * 100;
    stats.averageAttempts = deliveries.reduce((sum, d) => sum + d.attempts, 0) / stats.total;
  }

  return stats;
}

/**
 * Create webhook payload from event
 */
export function createWebhookPayload(
  event: string,
  data: Record<string, any>
): WebhookPayload {
  return {
    id: `evt_${Date.now()}_${Math.random().toString(36).substring(7)}`,
    event: event as any,
    timestamp: Date.now(),
    data,
  };
}

/**
 * Validate webhook delivery response
 */
export function isValidWebhookResponse(statusCode: number): boolean {
  return statusCode >= 200 && statusCode < 300;
}

/**
 * Check if error is retryable
 */
export function isRetryableError(error: string): boolean {
  const retryableErrors = [
    'ECONNREFUSED',
    'ECONNRESET',
    'ETIMEDOUT',
    'EHOSTUNREACH',
    'ENETUNREACH',
    'timeout',
    '429', // Too Many Requests
    '503', // Service Unavailable
    '504', // Gateway Timeout
  ];

  return retryableErrors.some((e) => error.includes(e));
}
