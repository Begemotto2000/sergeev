/**
 * Webhook Infrastructure
 * Manages webhook registration, delivery, and tracking
 */

import { createHmac } from 'crypto';
import { getCacheKey, pushToList, getList, setCounter, getCounter } from './redis';

export type WebhookEvent = 
  | 'transcription.completed'
  | 'transcription.failed'
  | 'search.completed'
  | 'search.failed'
  | 'rate_limit.warning'
  | 'rate_limit.critical'
  | 'user.created'
  | 'user.deleted';

export interface Webhook {
  id: string;
  userId: number;
  url: string;
  events: WebhookEvent[];
  active: boolean;
  secret: string;
  createdAt: number;
  lastDelivery?: number;
  deliveryCount: number;
  failureCount: number;
}

export interface WebhookPayload {
  id: string;
  event: WebhookEvent;
  timestamp: number;
  data: Record<string, any>;
}

export interface WebhookDelivery {
  id: string;
  webhookId: string;
  event: WebhookEvent;
  status: 'pending' | 'success' | 'failed' | 'retrying';
  attempts: number;
  maxAttempts: number;
  nextRetry?: number;
  error?: string;
  createdAt: number;
  completedAt?: number;
}

/**
 * Create webhook
 */
export async function createWebhook(
  userId: number,
  url: string,
  events: WebhookEvent[],
  secret: string
): Promise<Webhook> {
  const webhook: Webhook = {
    id: `webhook_${Date.now()}_${Math.random().toString(36).substring(7)}`,
    userId,
    url,
    events,
    active: true,
    secret,
    createdAt: Date.now(),
    deliveryCount: 0,
    failureCount: 0,
  };

  const key = getCacheKey('webhooks', userId.toString());
  await pushToList(key, [webhook], 1000);

  return webhook;
}

/**
 * Get user webhooks
 */
export async function getUserWebhooks(userId: number): Promise<Webhook[]> {
  try {
    const key = getCacheKey('webhooks', userId.toString());
    const webhooks = await getList<Webhook>(key, 0, -1);
    return webhooks.filter((w) => w.active);
  } catch (error) {
    console.error('Failed to get user webhooks:', error);
    return [];
  }
}

/**
 * Get webhook by ID
 */
export async function getWebhook(webhookId: string): Promise<Webhook | null> {
  try {
    // In a real implementation, would query Redis
    return null;
  } catch (error) {
    console.error('Failed to get webhook:', error);
    return null;
  }
}

/**
 * Update webhook
 */
export async function updateWebhook(
  webhookId: string,
  updates: Partial<Webhook>
): Promise<Webhook | null> {
  try {
    // In a real implementation, would update in Redis
    return null;
  } catch (error) {
    console.error('Failed to update webhook:', error);
    return null;
  }
}

/**
 * Delete webhook
 */
export async function deleteWebhook(webhookId: string, userId: number): Promise<boolean> {
  try {
    const key = getCacheKey('webhooks', userId.toString());
    const webhooks = await getList<Webhook>(key, 0, -1);
    const updated = webhooks.map((w) => (w.id === webhookId ? { ...w, active: false } : w));

    // In a real implementation, would update in Redis
    return true;
  } catch (error) {
    console.error('Failed to delete webhook:', error);
    return false;
  }
}

/**
 * Queue webhook delivery
 */
export async function queueWebhookDelivery(
  webhook: Webhook,
  event: WebhookEvent,
  data: Record<string, any>
): Promise<WebhookDelivery> {
  const delivery: WebhookDelivery = {
    id: `delivery_${Date.now()}_${Math.random().toString(36).substring(7)}`,
    webhookId: webhook.id,
    event,
    status: 'pending',
    attempts: 0,
    maxAttempts: 5,
    createdAt: Date.now(),
  };

  const key = getCacheKey('webhook_deliveries', webhook.id);
  await pushToList(key, [delivery], 10000);

  return delivery;
}

/**
 * Get webhook deliveries
 */
export async function getWebhookDeliveries(
  webhookId: string,
  limit: number = 100
): Promise<WebhookDelivery[]> {
  try {
    const key = getCacheKey('webhook_deliveries', webhookId);
    return await getList<WebhookDelivery>(key, -limit, -1);
  } catch (error) {
    console.error('Failed to get webhook deliveries:', error);
    return [];
  }
}

/**
 * Update delivery status
 */
export async function updateDeliveryStatus(
  delivery: WebhookDelivery,
  status: WebhookDelivery['status'],
  error?: string
): Promise<void> {
  try {
    const updated: WebhookDelivery = {
      ...delivery,
      status,
      error,
      completedAt: status === 'success' || status === 'failed' ? Date.now() : undefined,
    };

    // In a real implementation, would update in Redis
  } catch (error) {
    console.error('Failed to update delivery status:', error);
  }
}

/**
 * Get pending deliveries
 */
export async function getPendingDeliveries(): Promise<WebhookDelivery[]> {
  try {
    // In a real implementation, would query all pending deliveries
    return [];
  } catch (error) {
    console.error('Failed to get pending deliveries:', error);
    return [];
  }
}

/**
 * Get retrying deliveries
 */
export async function getRetryingDeliveries(): Promise<WebhookDelivery[]> {
  try {
    // In a real implementation, would query all retrying deliveries
    return [];
  } catch (error) {
    console.error('Failed to get retrying deliveries:', error);
    return [];
  }
}

/**
 * Calculate next retry time (exponential backoff)
 */
export function calculateNextRetry(attempts: number): number {
  const baseDelay = 5000; // 5 seconds
  const maxDelay = 3600000; // 1 hour
  const delay = Math.min(baseDelay * Math.pow(2, attempts), maxDelay);
  return Date.now() + delay;
}

/**
 * Get webhook statistics
 */
export async function getWebhookStats(webhookId: string): Promise<{
  totalDeliveries: number;
  successfulDeliveries: number;
  failedDeliveries: number;
  successRate: number;
  lastDelivery?: number;
}> {
  try {
    const deliveries = await getWebhookDeliveries(webhookId);
    const successful = deliveries.filter((d) => d.status === 'success').length;
    const failed = deliveries.filter((d) => d.status === 'failed').length;

    return {
      totalDeliveries: deliveries.length,
      successfulDeliveries: successful,
      failedDeliveries: failed,
      successRate: deliveries.length > 0 ? (successful / deliveries.length) * 100 : 0,
      lastDelivery: deliveries[0]?.createdAt,
    };
  } catch (error) {
    console.error('Failed to get webhook stats:', error);
    return {
      totalDeliveries: 0,
      successfulDeliveries: 0,
      failedDeliveries: 0,
      successRate: 0,
    };
  }
}

/**
 * Generate webhook signature
 */
export function generateSignature(payload: string, secret: string): string {
  return createHmac('sha256', secret).update(payload).digest('hex');
}

/**
 * Verify webhook signature
 */
export function verifySignature(payload: string, signature: string, secret: string): boolean {
  const expectedSignature = generateSignature(payload, secret);
  return signature === expectedSignature;
}

/**
 * Get webhook event types
 */
export function getWebhookEventTypes(): WebhookEvent[] {
  return [
    'transcription.completed',
    'transcription.failed',
    'search.completed',
    'search.failed',
    'rate_limit.warning',
    'rate_limit.critical',
    'user.created',
    'user.deleted',
  ];
}

/**
 * Check if webhook should receive event
 */
export function shouldWebhookReceiveEvent(webhook: Webhook, event: WebhookEvent): boolean {
  return webhook.active && webhook.events.includes(event);
}

/**
 * Track webhook delivery attempt
 */
export async function trackDeliveryAttempt(webhookId: string, success: boolean): Promise<void> {
  try {
    const countKey = getCacheKey('webhook:delivery_attempts', webhookId);
    const successKey = getCacheKey('webhook:successful_deliveries', webhookId);

    const attempts = await getCounter(countKey);
    await setCounter(countKey, attempts + 1, 86400);

    if (success) {
      const successes = await getCounter(successKey);
      await setCounter(successKey, successes + 1, 86400);
    }
  } catch (error) {
    console.error('Failed to track delivery attempt:', error);
  }
}
