/**
 * Qdrant Service Tests
 */

import { describe, it, expect } from 'vitest';
import { generateEmbedding } from './qdrantService.js';

describe('Qdrant Service', () => {
  describe('generateEmbedding', () => {
    it('should generate embedding of correct dimension', () => {
      const embedding = generateEmbedding('test text');
      
      expect(Array.isArray(embedding)).toBe(true);
      expect(embedding.length).toBe(384);
    });

    it('should generate deterministic embeddings', () => {
      const text = 'hello world';
      const emb1 = generateEmbedding(text);
      const emb2 = generateEmbedding(text);
      
      expect(emb1).toEqual(emb2);
    });

    it('should generate different embeddings for different texts', () => {
      const emb1 = generateEmbedding('hello world');
      const emb2 = generateEmbedding('goodbye world');
      
      expect(emb1).not.toEqual(emb2);
    });

    it('should normalize embeddings to [-1, 1] range', () => {
      const embedding = generateEmbedding('test text');
      
      embedding.forEach(value => {
        expect(value).toBeGreaterThanOrEqual(-1);
        expect(value).toBeLessThanOrEqual(1);
      });
    });

    it('should handle empty string', () => {
      const embedding = generateEmbedding('');
      
      expect(Array.isArray(embedding)).toBe(true);
      expect(embedding.length).toBe(384);
    });

    it('should handle very long text', () => {
      const longText = 'word '.repeat(10000);
      const embedding = generateEmbedding(longText);
      
      expect(embedding.length).toBe(384);
    });

    it('should handle special characters', () => {
      const text = '!@#$%^&*()_+-=[]{}|;:,.<>?';
      const embedding = generateEmbedding(text);
      
      expect(embedding.length).toBe(384);
    });

    it('should handle unicode characters', () => {
      const text = 'Привет мир 你好世界 مرحبا بالعالم';
      const embedding = generateEmbedding(text);
      
      expect(embedding.length).toBe(384);
    });
  });

  describe('Embedding similarity', () => {
    it('should generate similar embeddings for similar texts', () => {
      const emb1 = generateEmbedding('The quick brown fox');
      const emb2 = generateEmbedding('The quick brown fox jumps');
      
      // Calculate cosine similarity
      let dotProduct = 0;
      for (let i = 0; i < emb1.length; i++) {
        dotProduct += emb1[i] * emb2[i];
      }
      
      // Similarity should be relatively high for similar texts
      expect(dotProduct).toBeGreaterThan(0);
    });

    it('should generate different embeddings for completely different texts', () => {
      const emb1 = generateEmbedding('apple orange banana');
      const emb2 = generateEmbedding('car truck bus');
      
      let dotProduct = 0;
      for (let i = 0; i < emb1.length; i++) {
        dotProduct += emb1[i] * emb2[i];
      }
      
      // Similarity should be lower for different texts
      // (but not necessarily negative due to random nature of hash)
      expect(typeof dotProduct).toBe('number');
    });
  });
});
