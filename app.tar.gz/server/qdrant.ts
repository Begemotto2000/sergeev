/**
 * Qdrant Vector Database Integration
 * Handles semantic search in video transcriptions
 * STANDARD: ЧеЧиЧе (Четко, Чисто, Честно) - только реальные данные от ИИ
 */

import { invokeLLM } from './_core/llm';

// Qdrant configuration
const QDRANT_HOST = process.env.QDRANT_HOST || '46.8.255.137';
const QDRANT_PORT = process.env.QDRANT_PORT || '6333';
const QDRANT_COLLECTION = 'video_chunks';

// OpenAI embedding model - text-embedding-3-large для максимальной точности
const EMBEDDING_MODEL = 'text-embedding-3-large';
const EMBEDDING_DIMENSION = 3072; // text-embedding-3-large использует 3072 измерения

/**
 * Generate embedding for text using OpenAI API
 * ЧЕСТНО: Используется реальный OpenAI API, без fallback на случайные векторы
 * Если API недоступен - выбрасывается ошибка, а не подставляется фейк
 */
export async function generateEmbedding(text: string): Promise<number[]> {
  const startTime = Date.now();
  
  try {
    // Логирование: начало запроса
    console.log(`[EMBEDDING] Начало генерации embeddings для текста (${text.length} символов)`);
    
    // Валидация входных данных
    if (!text || text.trim().length === 0) {
      throw new Error('Текст для embedding не может быть пустым');
    }

    if (!process.env.OPENAI_API_KEY) {
      throw new Error('OPENAI_API_KEY не установлен в переменных окружения');
    }

    // Реальный вызов к OpenAI API
    const response = await fetch('https://api.openai.com/v1/embeddings', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: EMBEDDING_MODEL,
        input: text.substring(0, 8000), // OpenAI лимит: 8000 токенов
        encoding_format: 'float',
      }),
    });

    // Проверка ответа
    if (!response.ok) {
      const errorText = await response.text();
      const duration = Date.now() - startTime;
      console.error(`[EMBEDDING] ❌ ОШИБКА (${duration}ms): ${response.status} ${response.statusText}`);
      console.error(`[EMBEDDING] Ответ сервера: ${errorText}`);
      throw new Error(`OpenAI API ошибка: ${response.status} ${response.statusText} - ${errorText}`);
    }

    const data = await response.json();
    
    // Валидация ответа
    if (!data.data || !Array.isArray(data.data) || data.data.length === 0) {
      throw new Error('OpenAI API вернул пустой ответ');
    }

    const embedding = data.data[0].embedding;
    
    // Валидация embedding
    if (!Array.isArray(embedding) || embedding.length === 0) {
      throw new Error('OpenAI API вернул пустой embedding');
    }

    const duration = Date.now() - startTime;
    console.log(`[EMBEDDING] ✅ Успешно (${duration}ms): ${embedding.length} измерений`);
    
    return embedding;
  } catch (error) {
    const duration = Date.now() - startTime;
    console.error(`[EMBEDDING] ❌ КРИТИЧЕСКАЯ ОШИБКА (${duration}ms):`, error);
    
    // ЧЕСТНО: Не подставляем фейк, выбрасываем ошибку
    throw error;
  }
}

/**
 * Search in Qdrant vector database
 * ЧЕСТНО: Используется реальный поиск, все ошибки логируются
 */
export async function searchQdrant(
  query: string,
  topK: number = 5,
  filters?: Record<string, any>
) {
  const startTime = Date.now();
  
  try {
    console.log(`[QDRANT_SEARCH] Начало поиска: "${query}" (topK=${topK})`);

    // Валидация входных данных
    if (!query || query.trim().length === 0) {
      throw new Error('Поисковый запрос не может быть пустым');
    }

    if (topK < 1 || topK > 100) {
      throw new Error('topK должен быть между 1 и 100');
    }

    // Генерируем embedding для запроса
    const queryEmbedding = await generateEmbedding(query);

    // Вызываем Qdrant API
    const qdrantUrl = `http://${QDRANT_HOST}:${QDRANT_PORT}/collections/${QDRANT_COLLECTION}/points/search`;
    console.log(`[QDRANT_SEARCH] Запрос к Qdrant: ${qdrantUrl}`);

    const response = await fetch(qdrantUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        vector: queryEmbedding,
        limit: topK,
        with_payload: true,
        with_vectors: false,
        filter: filters,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      const duration = Date.now() - startTime;
      console.error(`[QDRANT_SEARCH] ❌ ОШИБКА (${duration}ms): ${response.status} ${response.statusText}`);
      console.error(`[QDRANT_SEARCH] Ответ: ${errorText}`);
      throw new Error(`Qdrant API ошибка: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    const results = data.result || [];
    const duration = Date.now() - startTime;
    
    console.log(`[QDRANT_SEARCH] ✅ Успешно (${duration}ms): найдено ${results.length} результатов`);
    
    return results;
  } catch (error) {
    const duration = Date.now() - startTime;
    console.error(`[QDRANT_SEARCH] ❌ КРИТИЧЕСКАЯ ОШИБКА (${duration}ms):`, error);
    throw error;
  }
}

/**
 * Format search results with metadata
 * ЧЕСТНО: Возвращает только реальные данные из Qdrant
 */
export function formatSearchResults(
  results: any[],
  mode: string
) {
  if (!Array.isArray(results)) {
    console.warn('[FORMAT_RESULTS] Результаты не являются массивом, возвращаю пустой массив');
    return [];
  }

  return results.map((result) => ({
    id: result.id,
    score: result.score,
    videoId: result.payload?.video_id,
    videoTitle: result.payload?.video_title,
    moduleNumber: result.payload?.module_number,
    startTime: result.payload?.start_formatted,
    endTime: result.payload?.end_formatted,
    startMs: result.payload?.start_ms,
    endMs: result.payload?.end_ms,
    text: result.payload?.text,
    mode,
  }));
}

/**
 * Generate answer using LLM with context from search results
 * ЧЕСТНО: Используется реальный GPT-4o, все вызовы логируются
 */
export async function generateAnswer(
  query: string,
  context: string,
  mode: string = 'ОТВЕТ'
): Promise<string> {
  const startTime = Date.now();
  
  try {
    console.log(`[LLM_ANSWER] Начало генерации ответа (режим: ${mode})`);
    
    const systemPrompt = getSystemPrompt(mode);

    const response = await invokeLLM({
      messages: [
        {
          role: 'system',
          content: systemPrompt,
        },
        {
          role: 'user',
          content: `Контекст из базы знаний Ивана Сергеева:\n\n${context}\n\nВопрос: ${query}`,
        },
      ],
    });

    const content = response.choices[0].message.content;
    if (typeof content !== 'string') {
      throw new Error('LLM вернул непредвиденный формат ответа');
    }

    const duration = Date.now() - startTime;
    console.log(`[LLM_ANSWER] ✅ Успешно (${duration}ms): ${content.length} символов`);
    
    return content;
  } catch (error) {
    const duration = Date.now() - startTime;
    console.error(`[LLM_ANSWER] ❌ КРИТИЧЕСКАЯ ОШИБКА (${duration}ms):`, error);
    throw error;
  }
}

/**
 * Get system prompt based on search mode
 */
function getSystemPrompt(mode: string): string {
  const prompts: Record<string, string> = {
    ОТВЕТ: `Ты помощник, который отвечает на вопросы на основе базы знаний о менторстве Ивана Сергеева.
    Давай прямые, полезные и практические ответы.
    Если информация не найдена в контексте, скажи об этом честно.
    Структурируй ответ понятно, используй примеры когда возможно.`,

    ТАЙМКОД: `Ты специалист по поиску информации в видео.
    На основе предоставленного контекста, найди и выдели все релевантные таймкоды и видео.
    Структурируй результаты по видео и времени.
    Для каждого результата указывай точное время начала и конца.`,

    'DEEP RESEARCH': `Ты эксперт по менторству и бизнесу.
    Проведи глубокое исследование по теме, используя предоставленный контекст.
    Структурируй ответ с подзаголовками, примерами, выводами и рекомендациями.
    Будь аналитичен и креативен.`,

    ИМИГО: `Ты творческий мыслитель и аналитик.
    На основе предоставленного контекста, сгенерируй оригинальные идеи, инсайты, гипотезы и озарения.
    Структурируй ответ с подзаголовками:
    - ИДЕИ (новые концепции и подходы)
    - ИНСАЙТЫ (глубокие наблюдения)
    - ГИПОТЕЗЫ (предположения для проверки)
    - ОЗАРЕНИЯ (неожиданные связи и открытия)
    Будь оригинален и креативен!`,
  };

  return prompts[mode] || prompts.ОТВЕТ;
}

/**
 * Batch search for multiple queries
 * ЧЕСТНО: Все ошибки логируются, нет подстановок фейк-данных
 */
export async function batchSearch(
  queries: string[],
  topK: number = 5
): Promise<Map<string, any>> {
  const results = new Map();
  const startTime = Date.now();

  console.log(`[BATCH_SEARCH] Начало пакетного поиска (${queries.length} запросов)`);

  for (const query of queries) {
    try {
      const searchResults = await searchQdrant(query, topK);
      results.set(query, searchResults);
    } catch (error) {
      console.error(`[BATCH_SEARCH] ❌ Ошибка для запроса "${query}":`, error);
      // ЧЕСТНО: Возвращаем ошибку, а не пустой массив
      results.set(query, { error: String(error) });
    }
  }

  const duration = Date.now() - startTime;
  console.log(`[BATCH_SEARCH] ✅ Завершено (${duration}ms)`);

  return results;
}
