# HTTPS/SSL Setup Guide

Полное руководство по настройке HTTPS и SSL для production сервера 46.8.255.137

## 📋 Обзор

Система использует:
- **Nginx** - reverse proxy для HTTPS/SSL
- **Let's Encrypt** - бесплатные SSL сертификаты
- **Certbot** - автоматическое управление сертификатами
- **Production Server** - Node.js Express на порту 4000

## 🚀 Быстрая установка (на production сервере)

### Шаг 1: SSH на production сервер

```bash
ssh root@46.8.255.137
# Пароль: k8hSaZ2XL37x
```

### Шаг 2: Установить Nginx и Certbot

```bash
apt-get update
apt-get install -y nginx certbot python3-certbot-nginx
```

### Шаг 3: Скопировать конфигурацию

```bash
# Скопировать nginx.conf
cp /home/ubuntu/sergeev_digitization_system/nginx.conf /etc/nginx/nginx.conf

# Создать директорию для сертификатов
mkdir -p /etc/nginx/ssl
```

### Шаг 4: Получить SSL сертификат от Let's Encrypt

```bash
# Замените example.com на ваш домен
DOMAIN="your-domain.com"
EMAIL="your-email@example.com"

certbot certonly --standalone \
    -d $DOMAIN \
    --email $EMAIL \
    --agree-tos \
    --non-interactive

# Скопировать сертификаты в Nginx
cp /etc/letsencrypt/live/$DOMAIN/fullchain.pem /etc/nginx/ssl/
cp /etc/letsencrypt/live/$DOMAIN/privkey.pem /etc/nginx/ssl/
```

### Шаг 5: Запустить Nginx

```bash
# Проверить конфигурацию
nginx -t

# Запустить Nginx
systemctl start nginx
systemctl enable nginx

# Проверить статус
systemctl status nginx
```

### Шаг 6: Запустить Production Server

```bash
cd /opt/sergeev/app
export OPENAI_API_KEY="sk-proj-..."
export API_KEY_REQUIRED="true"
nohup node production-server.mjs > /tmp/prod-server.log 2>&1 &
```

## 🔐 Проверка HTTPS

```bash
# Проверить HTTPS доступ
curl -k https://your-domain.com/api/status

# Проверить редирект HTTP -> HTTPS
curl -i http://your-domain.com/

# Проверить SSL сертификат
openssl s_client -connect your-domain.com:443
```

## ⏰ Автоматическое обновление сертификата

Let's Encrypt сертификаты действуют 90 дней. Certbot автоматически обновляет их.

```bash
# Проверить статус автообновления
systemctl status certbot.timer

# Или добавить cron job вручную
crontab -e

# Добавить строку:
0 3 * * * certbot renew --quiet && systemctl reload nginx
```

## 📊 Мониторинг

### Логи Nginx

```bash
# Access logs
tail -f /var/log/nginx/access.log

# Error logs
tail -f /var/log/nginx/error.log
```

### Логи Production Server

```bash
tail -f /tmp/prod-server.log
```

### Проверить слушающие порты

```bash
netstat -tlnp | grep -E ':(80|443|4000)'
```

## 🔧 Troubleshooting

### Проблема: "Port 80 already in use"

```bash
# Найти процесс на порту 80
lsof -i :80

# Убить процесс
kill -9 <PID>
```

### Проблема: "Certificate not found"

```bash
# Проверить наличие сертификатов
ls -la /etc/letsencrypt/live/

# Переполучить сертификат
certbot certonly --standalone -d your-domain.com
```

### Проблема: "Nginx configuration error"

```bash
# Проверить конфигурацию
nginx -t

# Посмотреть ошибку
nginx -T
```

### Проблема: "Connection refused"

```bash
# Проверить, запущен ли Nginx
systemctl status nginx

# Перезагрузить Nginx
systemctl reload nginx

# Перезагрузить Production Server
pkill -f production-server
nohup node production-server.mjs > /tmp/prod-server.log 2>&1 &
```

## 🔒 Безопасность

### Firewall правила

```bash
# Разрешить HTTP и HTTPS
ufw allow 80/tcp
ufw allow 443/tcp

# Разрешить SSH
ufw allow 22/tcp

# Включить firewall
ufw enable
```

### SSL/TLS конфигурация

Nginx использует:
- **TLS 1.2** и **TLS 1.3**
- **HIGH** и **!aNULL** шифры
- **HSTS** заголовок (max-age=31536000)

### Security Headers

```
Strict-Transport-Security: max-age=31536000; includeSubDomains
X-Frame-Options: SAMEORIGIN
X-Content-Type-Options: nosniff
X-XSS-Protection: 1; mode=block
Referrer-Policy: strict-origin-when-cross-origin
```

## 📈 Performance

### Gzip compression

Включена для всех текстовых типов контента:
- text/plain, text/css, text/xml, text/javascript
- application/json, application/javascript
- font/truetype, font/opentype, image/svg+xml

### Rate limiting

- **General endpoints**: 10 req/s
- **API endpoints**: 100 req/s

### Caching

- Static files (js, css, images): 30 дней
- Cache-Control: public, immutable

## 🐳 Docker Compose с HTTPS

Используйте `docker-compose-https.yml`:

```bash
docker compose -f docker-compose-https.yml up -d
```

Это запустит:
- Node.js Production Server (порт 4000)
- Nginx с SSL (порты 80, 443)
- PostgreSQL (порт 5432)
- Redis (порт 6379)
- Qdrant (порт 6333)

## 📝 Примеры использования

### Загрузка архива через HTTPS

```bash
curl -X POST \
  -H "X-API-Key: your-api-key" \
  -H "X-Filename: lessons.zip" \
  --data-binary @lessons.zip \
  https://your-domain.com/api/upload
```

### Поиск через HTTPS

```bash
curl -k "https://your-domain.com/api/search?q=Python&limit=10"
```

### Проверка статуса

```bash
curl -k https://your-domain.com/api/status
```

## 🎯 Checklist

- [ ] Nginx установлен и запущен
- [ ] SSL сертификат получен от Let's Encrypt
- [ ] Nginx конфигурация обновлена
- [ ] Production Server запущен
- [ ] HTTPS доступ проверен (curl -k https://...)
- [ ] HTTP редирект на HTTPS работает
- [ ] Firewall правила настроены
- [ ] Автообновление сертификата включено
- [ ] Логирование настроено
- [ ] Мониторинг настроен

## 📞 Поддержка

Для проблем с SSL:
- https://letsencrypt.org/docs/
- https://certbot.eff.org/docs/

Для проблем с Nginx:
- https://nginx.org/en/docs/
