/**
 * Production Frontend - React Dashboard
 * Serves React UI for tech-support dashboard
 * Integrates with production-server.mjs API
 */

import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5001;
const API_BASE = process.env.API_BASE || 'http://localhost:5000';

app.use(express.static('public'));
app.use(express.json());

// Serve React app
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/tech-support', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Proxy API requests to backend
app.get('/api/*', async (req, res) => {
  try {
    const apiUrl = `${API_BASE}${req.path}${req.url.split(req.path)[1] || ''}`;
    const response = await fetch(apiUrl, {
      headers: {
        'X-API-Key': req.headers['x-api-key'] || 'frontend-key'
      }
    });
    const data = await response.json();
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/*', async (req, res) => {
  try {
    const apiUrl = `${API_BASE}${req.path}`;
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': req.headers['x-api-key'] || 'frontend-key'
      },
      body: JSON.stringify(req.body)
    });
    const data = await response.json();
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`🎨 Frontend running on http://localhost:${PORT}`);
  console.log(`📊 Dashboard: http://localhost:${PORT}/tech-support`);
});
